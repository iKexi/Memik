# MeMik

Privacy, media, automation, temp mail, and proxy tools for Chromium.

## Project structure

See **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** for the full folder layout, the
internal message-passing API, the state-management pattern, and naming conventions —
`shared/` (cross-cutting infrastructure), `popup/state`, `popup/services` and
`popup/components/detective` are the newest and best-documented parts, used as the
reference implementation for how new features should be structured.

## Themes

Click the sun / moon button to cycle:

1. **Light**
2. **Dark**
3. **Glass** (Liquid Glass / translucent)

## Detective

Safety checks for sites you own. Everything is passive unless you start the port test yourself.

- **Safety score and plain-language verdict.** A 0–100 score, a grade, and "Fix these first" with one-line fixes. Switch to **Detailed** for why it matters, how to fix it, the evidence, a confidence label (Confirmed / Likely / Needs your review) and a learn-more link.
- **Real headers.** Response headers are captured from the browser itself (HSTS, CSP, framing, nosniff, Referrer-Policy, CORS, Set-Cookie flags). If unavailable, a safe HEAD request is used and the report says so.
- **Checks that cannot break each other.** Each check runs in isolation; if one fails the rest still complete and the report tells you which one could not run.
- **Reports.** Copy as text or download JSON. Cookie and secret values are never included.
- **This site & its IP.** The IP your browser connected to, DNS records (DNS-over-HTTPS), CDN hint, and every server the page contacted with its IP.
- **Visited sites & IPs.** Off by default. When enabled, stores host + IP locally (max 500, private windows never recorded). Clear any time.
- **Open ports test.** Needs an ownership tick-box. Combines a passive public view (Shodan InternetDB) with a live browser test. A browser can only fully test web ports; blocked or untestable ports are labelled, never guessed. Results behind a CDN or while a proxy is on carry a warning.
- **Result display.** Colour-blind-safe result colours and compact spacing, scoped to Detective. Theme (Light / Dark / Glass) and accent colour are shared across the whole app — change them from the app menu's Appearance page; Detective links there rather than duplicating the controls.

Run the Detective tests with `node tests/detective-test.js`.

## Free Self-Hosted Auto Updates

MeMik can check for updates from **any free HTTPS host** (GitHub is recommended).

### How it works

1. You upload a new ZIP to a free host (GitHub Releases is perfect).
2. You publish a tiny `updates.json` file that points to that ZIP.
3. The extension checks the JSON every few hours.
4. When a newer version is found, a banner appears in the popup with a **Download** button.

### Setup (one-time, completely free)

#### 1. Create a public GitHub repository
Example: `https://github.com/yourname/memik-updates`

#### 2. Create a release and upload the ZIP
- Go to **Releases → Create a new release**
- Tag it e.g. `v1.7.0`
- Upload `MeMik-v1_7_0.zip`

#### 3. Add an `updates.json` file in the repo (main branch)

```json
{
  "version": "1.7.0",
  "download_url": "https://github.com/yourname/memik-updates/releases/download/v1.7.0/MeMik-v1_7_0.zip",
  "changelog": "• Liquid Glass theme\n• Favourite icons fixed\n• Free auto-update support",
  "name": "MeMik 1.7.0"
}
```

Raw URL will look like:
```
https://raw.githubusercontent.com/yourname/memik-updates/main/updates.json
```

#### 4. Tell the extension where to look

Open the extension popup → open the browser console on the popup (right-click → Inspect) and run:

```js
chrome.runtime.sendMessage({
  type: "setUpdateCheckUrl",
  url: "https://raw.githubusercontent.com/yourname/memik-updates/main/updates.json"
});
```

Or set it permanently via storage:

```js
chrome.storage.local.set({
  updateCheckUrl: "https://raw.githubusercontent.com/yourname/memik-updates/main/updates.json"
});
```

After that the extension will automatically check for updates.

### Updating in the future

1. Bump `"version"` in `manifest.json`
2. Build the new ZIP
3. Create a new GitHub Release and upload the ZIP
4. Update `updates.json` with the new version + download URL
5. Users will see the update banner the next time they open the popup (or within a few hours)

### Notes

- Completely free (GitHub free tier is more than enough).
- Works with any HTTPS host that serves a JSON file (GitHub Pages, Cloudflare R2, Netlify, etc.).
- Because this is an unpacked / sideloaded extension, Chrome does **not** allow silent CRX auto-install. The user still needs to download the new ZIP and click **Reload** on `chrome://extensions`. The banner makes this process clear and one-click.

## Load

Load unpacked from `chrome://extensions`.

## Tests

```bash
node tests/detective-test.js
node tests/smoke-test.js
node tests/full-test.js
node tests/delay-simulation-test.js
node --expose-gc tests/memory-growth-test.js
node tests/scale-stress-test.js
```

## 1.9.0 changes
- **Platform ads & analytics ruleset** (`rulesets/platform-ads.json`): blocks Google Analytics, LinkedIn Insight/ads, TikTok ads & pixel, Pinterest ads & tag, Yahoo ads/trackers, YouTube ad endpoints (`ads.youtube.com`, `/pagead/`, `/ptracking`) and Oppo/HeyTap/OnePlus/Realme ad servers. Page loads and first-party sites are never blocked.
- **Security tab**: protection score, per-category blocking switches, privacy hardening (WebRTC leak, third-party cookies, hyperlink auditing, ad-privacy APIs, Do Not Track).
- **Detective**: local password strength meter and cryptographic password generator wired to the leak check.
- Import/Export buttons in Automation (and the password tool) now use consistent icons with labels.
- Glass theme: readable text on the VPN-style pages; theme preview is now a tap-to-cycle showcase that does not change the app theme.

## 1.9.1 changes
- Ad blocker: "Platform ads & analytics" is no longer a separate switch; it is always on with Threat Protection. Removed the stats Reset button.
- Proxy: country flags on every server, a Location picker (fastest/auto or a country, NordVPN-style), and Sort by Fastest/Country. Quick connect follows the chosen location.
- Detective: new minimal Toolkit (JWT inspector, encoder/decoder/hash), inspired by OWASP PTK. The outdated-library check was already part of the full scan.
