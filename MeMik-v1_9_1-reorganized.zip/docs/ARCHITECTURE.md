# MeMik architecture

This document describes how the codebase is organized, the patterns new code should
follow, and — just as importantly — which parts of a recent refactor were deliberately
left alone and why. It uses **Detective** (the safety-scanner feature) as the worked
example throughout, since it's the one feature that was fully migrated to the patterns
described here.

## Why a worked example instead of a full rewrite

This is a ~10,600-line, unbundled Manifest V3 extension: no webpack/esbuild, scripts
loaded directly via `<script>` tags and `importScripts()`. Several subsystems —
captcha solving, proxy rotation, fingerprint spoofing, ad blocking — have cross-file
message protocols that took real reading to understand even for the one (Detective)
fully documented here. Relocating or rewriting files in those subsystems blind, without
being able to fully regression-test them in this environment (no live proxy servers, no
real captcha challenges), risks silently breaking working, security-sensitive code.

So the approach taken was: build the real shared infrastructure once, apply it
end-to-end to one feature as a complete, tested reference implementation, and document
the pattern clearly enough that the same migration can be repeated safely for the other
subsystems later, one at a time, with their own test coverage.

## Folder structure

```
shared/                          Cross-cutting infrastructure, no feature logic.
  logger.js                        Leveled console logger (Logger.debug/info/warn/error).
  errors.js                        AppError, toAppError(), wrapHandler() for handlers.
  api-router.js                    Self-registering handler registry (ApiRouter).
  messages.js                      MSG.* constants — the message-passing API surface.
  config.js                        Environment/config values (endpoints, timeouts, limits,
                                    storage keys), separated from the logic that uses them.
  dom.js                           Generic popup UI helpers ($, h, plural, copyText, ...).
  net.js                           withTimeout / fetchTimeout.

background/
  background.js                    Entry point: importScripts + the legacy message switch
                                    + bootstraps everything else. See "The message API" below.
  allowlist.js, automation-policy.js, captcha-solver.js, media.js, proxy-scope.js,
  temp-mail.js                     Existing feature modules — untouched logic, see below.
  modules/detective/engine.js      Detective's business logic (headers, CSP, cookies,
                                    port scanning, DNS, IP tracking). Pure background-side
                                    logic; knows nothing about the popup's DOM.

content/
  *.js                             Existing content scripts — untouched logic.
  modules/detective/page-scanner.js  Detective's passive DOM scan, injected into every page.

popup/
  popup.html, popup.js             The app shell: navigation, every feature's UI that
                                    hasn't been split out yet, plus Detective's bootstrap
                                    call. See "Popup script loading order" below.
  popup.css                        Shared styles for the whole popup, including Detective's.
  state/
    store.js                         Generic pub/sub store (createStore). Not Detective-
                                      specific — any feature can use this.
    detective-store.js               Detective's state (view mode, display prefs, last
                                      report, port-scan state), built on store.js.
  services/
    detective-api.js                 The only file that calls chrome.runtime/chrome.storage
                                      for Detective. Returns plain data or throws.
  components/detective/
    labels.js                        Engine-code → human-label maps, shared by two views.
    report-view.js, site-info-view.js, visited-view.js, port-scan-view.js,
    scan-actions.js, appearance-controls.js
                                      One file per panel. Each renders into its own DOM
                                      elements and owns its own event bindings.
    detective-page.js                Wires the above together; the only file that needs
                                      to know all of them exist.

docs/
  ARCHITECTURE.md                  This file.

tests/
  detective-test.js                47 unit tests for the engine + page-scanner logic,
                                    plus a Node-vs-browser compatibility check for the
                                    shared/net.js and shared/config.js dependency.
```

## The message API

The popup and extension pages talk to the background service worker over
`chrome.runtime.sendMessage({ type: "...", ... })`. That `type` string is the
extension's internal API surface, and it had two problems: the strings were duplicated
as literals at every call site (typo-prone), and every handler lived as one more `case`
in a single ~500-line `switch` in `background.js`.

**What changed:**
- `shared/messages.js` defines every message type once, as `MSG.SOME_NAME`, grouped by
  feature and documented inline. Both `background.js` and the popup code that calls it
  should use these constants, not string literals.
- `shared/api-router.js` adds `ApiRouter.register(type, handler)` /
  `ApiRouter.dispatch(type, message, sender)`. A module can register its own handlers
  instead of adding a case to the switch. `background.js`'s switch falls through to
  `ApiRouter.dispatch` in its `default:` case, so both mechanisms share one response
  path and one error-handling wrapper.
- `shared/errors.js`'s `wrapHandler()` times every call, logs success/failure via
  `Logger`, and normalizes whatever a handler throws into `{ ok: false, error, code }`.
  `ApiRouter.register` applies this automatically. `background.js`'s own dispatch
  (for the handlers still in the switch) got the same timing/logging/normalization
  wrapped around the whole switch, without touching any individual case body.

**What this looks like for a new feature**, using Detective as the example
(`background/modules/detective/engine.js`, bottom of the file):

```js
ApiRouter.register(
  [MSG.DETECTIVE_RUN, MSG.DETECTIVE_SITE_INFO /* ... */],
  (message, sender) => handle(message, sender),
  "detective"
);
```

No change to `background.js` is needed to add a new message type this way — that's the
"scalable" part. Detective's eight message types were removed from the switch entirely
once this was in place.

## State management

`popup/state/store.js` is a small, generic pub/sub store:

```js
const store = createStore({ count: 0 });
store.subscribe((state, prevState) => { /* re-render whatever cares */ });
store.patch({ count: 1 });       // merges, notifies subscribers
store.set({ count: 0 });         // replaces, notifies subscribers
```

`popup/state/detective-store.js` is the reference usage: it wraps `createStore` with
Detective's specific state shape (`view`, `palette`, `density`, `busy`, `report`,
`ports`) and a `setDisplay()` helper that also persists display prefs to
`chrome.storage.local`. Multiple view components can react to the same state change —
for example, `detective-page.js` subscribes once and re-renders both the report view and
the port-scan view whenever `view` (Simple/Detailed) changes, rather than each button
handler needing to know about every other panel.

Other features in `popup.js` still keep their state as plain module-scoped variables.
That's a reasonable pattern for small, single-view pieces of state; reach for
`createStore` when more than one component needs to react to the same change.

## Naming conventions

- **Files:** kebab-case (`report-view.js`, `detective-api.js`).
- **Constants:** `SCREAMING_SNAKE_CASE` for true constants (`MSG.DETECTIVE_RUN`,
  `CONFIG.detective.timeouts.dohMs`'s *keys* are camelCase since they're config fields,
  not global constants — see `shared/config.js` for the convention there).
- **Functions/variables:** `camelCase`.
- **"Modules" (the plain-script globals this codebase uses instead of ES classes):**
  `PascalCase` when exported as a named capability (`Logger`, `ApiRouter`, `DetectiveApi`,
  `DetectiveStore`, `DetectiveReportView`), matching the existing `MemikDetective`,
  `MeMikMedia` style already in the codebase.
- **Message types** (the wire strings in `MSG`): `camelCase`, matching what
  `background.js`'s switch already expects — changing the wire format itself was out of
  scope for this pass.

This wasn't mechanically applied to the ~9,000 lines outside Detective and `shared/` —
see the next section — but it's the standard for anything touched going forward.

## What wasn't moved, and why

The following were deliberately left as-is in this pass:

- **Logic in `background/allowlist.js`, `automation-policy.js`, `captcha-solver.js`,
  `media.js`, `proxy-scope.js`, `temp-mail.js`, and every `content/*.js` file**: these
  implement proxy rotation, captcha solving, fingerprint spoofing and ad blocking, each
  with its own cross-file message protocol. They now have file-header doc comments
  explaining their purpose and how they're loaded, but their internals are untouched.
  Migrating one to the `ApiRouter`/`shared/config.js` pattern is safe to do next,
  one file at a time, each with its own before/after test coverage — the same way
  Detective was done.
- **`background.js`'s legacy switch** (~50 remaining cases): kept exactly as it was,
  just wrapped with centralized logging/error-normalization. Converting each case into
  a registered handler is a safe, mechanical transform in principle, but doing all ~50
  at once — including proxy and captcha logic this pass didn't otherwise touch — carries
  more risk than value in a single change. `ApiRouter` coexists with it indefinitely.
- **`background.js`'s own `fetchJsonTimeout`**: conceptually the same as
  `shared/net.js`'s `fetchTimeout`, not yet consolidated because its call sites are
  inside proxy-rotation logic this pass didn't audit closely enough to touch safely.
- **A few same-named helpers in separate closures** (`sleep` in `background.js`,
  `captcha-solver.js`, and `temp-mail.js`; a couple of `add`/`collect`/`describe`
  helpers across content scripts): checked and confirmed these are small,
  independently-implemented functions that happen to share a name, not copied logic —
  consolidating them would mean threading a shared module into each file's loading
  context for marginal benefit.

## Confirmed dead code removed

- **`content/fingerprint.js`** — an earlier implementation of the fingerprint-spoofing
  logic. Verified unreferenced in `manifest.json` (content_scripts or
  web_accessible_resources), `background.js`'s `importScripts`, and every
  `chrome.scripting.executeScript` call in the codebase. Its logic was superseded by an
  inlined copy inside `content/fingerprint-bridge.js`'s `MAIN_SOURCE` template string,
  which is what actually runs. Removed; `fingerprint-bridge.js` itself was not touched.

## Popup script loading order

`popup.html` loads scripts in dependency order (see the file for the exact list):
`shared/*` → `popup/state/*` → `popup/services/*` → `popup/components/detective/*` →
`popup.js`. None of this uses ES modules (`import`/`export`) — everything is a plain
script attaching to `window`/`self`/`globalThis`, consistent with the rest of the
codebase and with how the MV3 service worker loads files via `importScripts()`.

`popup.js` itself stays wrapped in its original top-level IIFE (removing that wrapper
risks colliding with non-configurable `window` properties like `location`/`top` across
~2,500 lines that weren't individually audited for that). Two functions it needs to
share with the separately-loaded Detective modules — `say()` (the toast/banner
notifier) and `openSheet()` (page navigation) — are exported explicitly:
`window.say = (...a) => say(...a);` near their definitions, rather than unwrapping the
whole file. Everything else Detective's popup code needs comes from `shared/`,
`popup/state/`, or `popup/services/`.

## Error handling

- **Background message handlers**: every message, whether handled by the legacy switch
  or by `ApiRouter`, is timed and logged (`Logger.debug`/`Logger.error`) and its result
  normalized to `{ ok: true, ... }` or `{ ok: false, error, code }` before
  `sendResponse()`. No handler needs to format its own error response.
- **Detective's engine** (`background/modules/detective/engine.js`): every individual
  check in the content-script page scanner (`content/modules/detective/page-scanner.js`)
  runs inside its own `try/catch` via a `run(name, fn)` wrapper, so one failing check
  can never prevent the rest of the scan from completing — failures are collected and
  surfaced to the user as "N checks could not run on this page" rather than silently
  losing the whole report.
- **Detective's popup views**: each async action (run a scan, look up site info, start
  a port test) catches its own errors and renders a `.det-error` block with a specific
  message, rather than leaving the UI stuck on a loading spinner.

## Running the tests

```
node tests/detective-test.js     # 47 unit tests: engine scoring/analysis + page-scanner
                                  # helpers, including a Node-vs-browser compatibility
                                  # check for the shared/net.js and shared/config.js
                                  # conditional-require pattern used in engine.js.
```

There's no automated test harness for the untouched subsystems in this repository;
the unit tests above were written alongside Detective's original implementation and
extended where this refactor touched shared behavior (e.g. the `withTimeout`/
`fetchTimeout` consolidation).
