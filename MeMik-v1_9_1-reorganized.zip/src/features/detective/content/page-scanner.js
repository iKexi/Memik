/**
 * MeMik Detective page scanner (content script).
 *
 * Passive analysis of the page that is open. It reads the DOM and the browser's own
 * resource timeline; it never sends payloads and never exploits anything.
 *
 * Every check runs in its own try/catch, so one broken check can never break the scan.
 * Cookie VALUES and secret VALUES are never returned, only names and masked previews.
 */
(function () {
  "use strict";

  const GEN = (window.__memikSecScanGen = (window.__memikSecScanGen || 0) + 1);
  const MDN = "https://developer.mozilla.org/en-US/docs/Web/";
  const MAX_EL = 20000;

  /* ---------------- helpers ---------------- */
  const f = (cat, id, level, conf, title, why, fix, detail, ref) =>
    ({ cat, id, level, conf, title, why: why || "", fix: fix || "", detail: detail || "", ref: ref || "" });

  const SECOND_LEVEL = /^(co|com|org|net|gov|edu|ac|or|ne|go)$/i;
  function etld1(host) {
    host = String(host || "").toLowerCase().replace(/^\[|\]$/g, "");
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host) || host.includes(":")) return host;
    const p = host.split(".");
    if (p.length <= 2) return host;
    const last = p[p.length - 1], mid = p[p.length - 2];
    return (last.length === 2 && SECOND_LEVEL.test(mid) ? p.slice(-3) : p.slice(-2)).join(".");
  }

  function parseUrl(raw, base) { try { return new URL(raw, base || location.href); } catch (_) { return null; } }
  function cap(arr, n) { return arr.length > n ? arr.slice(0, n).concat(`+${arr.length - n} more`) : arr; }
  function mask(v) { v = String(v); return v.slice(0, 4) + "…" + "(" + v.length + " chars)"; }
  function list(arr, n) { return cap(Array.from(new Set(arr)), n || 6).join(", "); }

  /* Libraries with security fixes in later versions (version-range facts, not live CVE lookups). */
  const VULN_LIBS = [
    { re: /jquery[-.@/]v?(\d+\.\d+(?:\.\d+)?)/i, name: "jQuery", rules: [
      { lt: "3.5.0", msg: "has an XSS flaw in HTML handling (CVE-2020-11022, CVE-2020-11023)", to: "3.5.0 or newer" },
      { lt: "3.4.0", msg: "has a prototype pollution flaw (CVE-2019-11358)", to: "3.4.0 or newer" } ] },
    { re: /bootstrap[-.@/]v?(\d+\.\d+(?:\.\d+)?)/i, name: "Bootstrap", rules: [
      { lt: "3.4.1", major: 3, msg: "has an XSS flaw in tooltips and popovers (CVE-2019-8331)", to: "3.4.1 or newer" },
      { lt: "4.3.1", major: 4, msg: "has an XSS flaw in tooltips and popovers (CVE-2019-8331)", to: "4.3.1 or newer" } ] },
    { re: /lodash(?:\.min)?[-.@/]v?(\d+\.\d+(?:\.\d+)?)/i, name: "Lodash", rules: [
      { lt: "4.17.21", msg: "has prototype pollution and command injection flaws (CVE-2020-8203, CVE-2021-23337)", to: "4.17.21 or newer" } ] },
    { re: /moment(?:\.min)?[-.@/]v?(\d+\.\d+(?:\.\d+)?)/i, name: "Moment.js", rules: [
      { lt: "2.29.4", msg: "can be slowed to a crawl by crafted input (CVE-2022-31129)", to: "2.29.4 or newer" } ] },
    { re: /angular(?:\.min)?\.js[?@/-]*v?(1\.\d+(?:\.\d+)?)|angularjs[/@-]v?(1\.\d+(?:\.\d+)?)/i, name: "AngularJS", eol: true }
  ];

  function cmpVer(a, b) {
    const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number);
    for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; }
    return 0;
  }

  function libIssues(src) {
    const out = [];
    for (const lib of VULN_LIBS) {
      const m = lib.re.exec(src);
      if (!m) continue;
      const ver = m[1] || m[2];
      if (!ver) continue;
      if (lib.eol) { out.push({ name: lib.name, ver, msg: "reached end of life in December 2021 and no longer gets security fixes", to: "a supported framework" }); continue; }
      for (const r of lib.rules) {
        if (r.major && String(ver).split(".")[0] != r.major) continue;
        if (cmpVer(ver, r.lt) < 0) { out.push({ name: lib.name, ver, msg: r.msg, to: r.to }); break; }
      }
    }
    return out;
  }

  /* Detection helpers are pure functions so they can be unit-tested. */
  const DB_ERR = /You have an error in your SQL syntax|Warning:\s*mysqli?_|mysqli_sql_exception|supplied argument is not a valid MySQL|ORA-\d{5}:|PG::SyntaxError|org\.postgresql\.util\.PSQLException|pg_query\(\)|SQLSTATE\[[0-9A-Z]+\]|Unclosed quotation mark after the character string|Microsoft OLE DB Provider for SQL Server|SQLite3::SQLException|SQLite\.Exception|System\.Data\.SqlClient\.SqlException|com\.mysql\.jdbc\.exceptions|java\.sql\.SQLException/i;
  const DEBUG_PAGES = [
    [/Server Error in '\/[^']*' Application/i, "ASP.NET error page"],
    [/Traceback \(most recent call last\)/, "Python stack trace"],
    [/Whoops! There was an error|Illuminate\\\\/i, "Laravel debug page"],
    [/Whitelabel Error Page/i, "Spring error page"],
    [/Fatal error:.{0,200} on line \d+/i, "PHP fatal error"],
    [/(?:Warning|Notice|Deprecated):\s.{0,200} in \/[^\s]+ on line \d+/i, "PHP warning with file path"],
    [/DEBUG = True|You're seeing this error because you have DEBUG/i, "Django debug page"],
    [/at [\w$.]+\([\w$]+\.java:\d+\)/, "Java stack trace"],
    [/ActionController::RoutingError|ActiveRecord::\w+Error/, "Rails error page"],
    [/\bat (?:Object\.|async )?[\w$.<>]+ \((?:\/|[A-Z]:\\)[^)]+:\d+:\d+\)/, "Node.js stack trace"]
  ];
  const SECRET_PATTERNS = [
    [/AKIA[0-9A-Z]{16}/, "AWS access key ID", "high"],
    [/sk_live_[0-9a-zA-Z]{20,}/, "Stripe live secret key", "critical"],
    [/gh[pousr]_[A-Za-z0-9]{36,}/, "GitHub token", "critical"],
    [/xox[abprs]-[A-Za-z0-9-]{10,}/, "Slack token", "high"],
    [/-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/, "Private key", "critical"],
    [/AIza[0-9A-Za-z_-]{35}/, "Google API key", "low"]
  ];
  const SINK = /\.(?:innerHTML|outerHTML)\s*=(?!=)|insertAdjacentHTML\s*\(|document\.write(?:ln)?\s*\(|\beval\s*\(|new\s+Function\s*\(|set(?:Timeout|Interval)\s*\(\s*["'`]|\.html\s*\(/;
  const SOURCE = /location\.(?:hash|search|href)|document\.(?:URL|documentURI|referrer)|window\.name/;
  const REDIRECT_KEYS = /^(redirect|redirect_uri|redirect_url|return|returnurl|return_to|returnto|next|url|goto|continue|dest|destination|target|callback|forward|out|link|r|u)$/i;

  function scanScriptText(text) {
    const sink = SINK.test(text), source = SOURCE.test(text);
    return { sink, source, flow: sink && source };
  }
  function findDbError(text) { const m = DB_ERR.exec(text); return m ? m[0] : ""; }
  function findDebugPage(text) { for (const [re, name] of DEBUG_PAGES) if (re.test(text)) return name; return ""; }
  function findSecrets(text) {
    const out = [];
    for (const [re, name, level] of SECRET_PATTERNS) { const m = re.exec(text); if (m) out.push({ name, level, preview: name === "Private key" ? "(key block)" : mask(m[0]) }); }
    return out;
  }
  function paramRedirects(search) {
    const out = [];
    try {
      new URLSearchParams(search).forEach((val, key) => {
        if (/^(https?:)?\/\/[^/\s]/i.test(val) || /^\/\\|^\\\\/.test(val)) out.push({ key, val, named: REDIRECT_KEYS.test(key) });
      });
    } catch (_) {}
    return out;
  }

  /* ---------------- the scan ---------------- */
  function scan() {
    const out = [];
    const errors = [];
    const tech = [];
    const facts = { forms: 0, passwordFields: 0, scriptsInline: 0, scriptsExternal: 0, thirdPartyHosts: [], links: 0, iframes: 0, title: "", cookieNames: [], cspMeta: "" };
    const pass = (cat, id, title, detail, ref) => out.push(f(cat, id, "pass", "confirmed", title, "", "", detail, ref));
    const run = (name, fn) => { try { fn(); } catch (e) { errors.push({ check: name, error: String((e && e.message) || e).slice(0, 160) }); } };

    const isHttps = location.protocol === "https:";
    const pageHost = location.hostname;
    const pageSite = etld1(pageHost);
    const isLocal = /^(localhost|127\.\d+\.\d+\.\d+|\[?::1\]?)$/i.test(pageHost) || /\.local$/i.test(pageHost);
    const q = (sel, root) => { try { return Array.from((root || document).querySelectorAll(sel)); } catch (_) { return []; } };
    const isThird = host => etld1(host) !== pageSite;

    const scriptsAll = q("script");
    const inlineScripts = scriptsAll.filter(s => !s.src).slice(0, 80);
    const extScripts = scriptsAll.filter(s => s.src);

    run("facts", () => {
      facts.title = (document.title || "").slice(0, 120);
      facts.forms = document.forms ? document.forms.length : 0;
      facts.passwordFields = q('input[type="password"]').length;
      facts.scriptsInline = inlineScripts.length;
      facts.scriptsExternal = extScripts.length;
      facts.links = q("a[href]").length;
      facts.iframes = q("iframe").length;
      const hosts = new Set();
      extScripts.concat(q('link[rel~="stylesheet"][href]'), q("img[src]"), q("iframe[src]")).forEach(el => {
        const u = parseUrl(el.src || el.href || el.getAttribute("src") || el.getAttribute("href"));
        if (u && /^https?:$/.test(u.protocol) && isThird(u.hostname)) hosts.add(u.hostname);
      });
      facts.thirdPartyHosts = Array.from(hosts).slice(0, 40);
      const meta = document.querySelector('meta[http-equiv="Content-Security-Policy" i]');
      facts.cspMeta = meta ? (meta.getAttribute("content") || "") : "";
      // names only, never values
      facts.cookieNames = (document.cookie || "").split(";").map(s => s.trim().split("=")[0]).filter(Boolean).slice(0, 60);
    });

    /* ---- secure connection ---- */
    run("https", () => {
      if (isHttps) pass("https", "https-pass", "Page uses HTTPS", location.origin);
      else if (isLocal) out.push(f("https", "https-local", "info", "confirmed", "Local page over HTTP", "Local development addresses are exempt from the HTTPS rule.", "", location.origin));
      else out.push(f("https", "https-missing", "high", "confirmed", "Page is not using HTTPS",
        "Everything sent to and from this page can be read or changed by anyone on the network.",
        "Install a TLS certificate (Let's Encrypt is free) and redirect all http:// traffic to https://.", location.origin, MDN + "Security/Transport_Layer_Security"));
    });

    /* ---- mixed content ---- */
    run("mixed", () => {
      if (!isHttps) return;
      const active = new Set(), passive = new Set(), confirmed = new Set();
      const A = ["script[src]", "link[rel~='stylesheet'][href]", "iframe[src]", "object[data]", "embed[src]"];
      const P = ["img[src]", "audio[src]", "video[src]", "source[src]", "video[poster]"];
      const attrOf = el => el.getAttribute("src") || el.getAttribute("href") || el.getAttribute("data") || el.getAttribute("poster") || "";
      A.forEach(sel => q(sel).forEach(el => { const v = attrOf(el); if (/^http:\/\//i.test(v)) active.add(v); }));
      P.forEach(sel => q(sel).forEach(el => { const v = attrOf(el); if (/^http:\/\//i.test(v)) passive.add(v); }));
      try {
        performance.getEntriesByType("resource").forEach(e => {
          if (!/^http:\/\//i.test(e.name)) return;
          confirmed.add(e.name);
          (/^(script|css|link|iframe|xmlhttprequest|fetch|other)$/.test(e.initiatorType) ? active : passive).add(e.name);
        });
      } catch (_) {}
      if (active.size) out.push(f("mixed", "mixed-active", "high", confirmed.size ? "confirmed" : "likely",
        `${active.size} insecure script, style or frame${active.size > 1 ? "s" : ""} on an HTTPS page`,
        "Anyone on the network can swap an http:// script for their own and take over the page.",
        "Change these addresses to https:// (or make them relative).", list(Array.from(active), 5), MDN + "Security/Mixed_content"));
      if (passive.size) out.push(f("mixed", "mixed-passive", "low", confirmed.size ? "confirmed" : "likely",
        `${passive.size} insecure image or media file${passive.size > 1 ? "s" : ""}`,
        "Browsers usually upgrade or block these, but they can still be tampered with and may break.",
        "Change these addresses to https://.", list(Array.from(passive), 5), MDN + "Security/Mixed_content"));
      if (!active.size && !passive.size) pass("mixed", "mixed-pass", "No mixed content found", "", MDN + "Security/Mixed_content");
    });

    /* ---- forms ---- */
    run("forms", () => {
      const forms = q("form");
      if (!forms.length) { pass("forms", "forms-none", "No forms on this page"); return; }
      let problems = 0, noCsrf = 0;
      const crossSensitive = [];
      const csrfMeta = q('meta[name*="csrf" i], meta[name*="xsrf" i]').length > 0;
      forms.slice(0, 60).forEach(form => {
        const pw = q('input[type="password"]', form).length > 0;
        const method = (form.getAttribute("method") || "get").toLowerCase();
        const action = parseUrl(form.getAttribute("action") || location.href);
        const where = action ? action.href.slice(0, 80) : "(unknown)";
        const toHttp = action && action.protocol === "http:" && !(isLocal && /^(localhost|127\.\d+\.\d+\.\d+|\[?::1\]?)$/i.test(action.hostname));
        if (pw && !isHttps && !isLocal) { problems++; out.push(f("forms", "form-pw-http-page", "critical", "confirmed", "Login form on an unencrypted page", "Passwords typed here travel in plain text.", "Serve the page over HTTPS.", "Form posts to " + where)); }
        else if (pw && toHttp) { problems++; out.push(f("forms", "form-pw-http-action", "critical", "confirmed", "Password form sends data over HTTP", "The page is secure but the password is submitted without encryption.", "Change the form action to https://.", "Form posts to " + where)); }
        else if (toHttp && isHttps) { problems++; out.push(f("forms", "form-http-action", "high", "confirmed", "A form submits to an HTTP address", "Data entered here is sent without encryption.", "Change the form action to https://.", "Form posts to " + where)); }
        if (pw && method === "get") { problems++; out.push(f("forms", "form-pw-get", "high", "confirmed", "Password form uses GET", "The password ends up in the address bar, browser history and server logs.", 'Set method="post" on the form.', "Form posts to " + where)); }
        if (action && action.origin !== location.origin) {
          const sensitive = pw || q("input", form).some(i => /^(cc-|card)/i.test(i.getAttribute("autocomplete") || "") || /card|cvv|cvc/i.test(i.name || ""));
          if (sensitive) crossSensitive.push(action.host);
        }
        if (method === "post") {
          const has = csrfMeta || q('input[type="hidden"]', form).some(i => /csrf|xsrf|token|nonce|authenticity|requestverification|wpnonce|form_key/i.test(i.name || ""));
          if (!has) noCsrf++;
        }

        // Pentesting Case 1: Brute Force check (login form missing rate limit/lockout/challenge)
        const hasLoginFields = q('input[name*="user" i], input[name*="login" i], input[type="email"]', form).length > 0;
        const hasCaptcha = q('[class*="captcha" i], [id*="captcha" i], iframe[src*="captcha" i], iframe[src*="turnstile" i], iframe[src*="recaptcha" i]', form).length > 0;
        if (pw && hasLoginFields && !hasCaptcha) {
          problems++;
          out.push(f("forms", "auth-brute-force", "high", "review",
            "Login form lacks brute-force or rate-limiting challenge",
            "Authentication endpoints without progressive delays, CAPTCHA, or account lockout can be automated by attackers for dictionary attacks.",
            "Implement progressive delays, IP rate-limiting, and CAPTCHA challenges after failed login attempts.",
            "Form posts to: " + where));
        }

        // Pentesting Case 3: Sensitive password change / state change over GET
        const isPassChange = q('input[name*="password_new" i], input[name*="password_conf" i], input[name*="new_pass" i]', form).length > 0;
        if (isPassChange && method === "get") {
          problems++;
          out.push(f("forms", "csrf-sensitive-get", "critical", "confirmed",
            "Sensitive password change action uses GET",
            "Account modification actions submitted via GET can be triggered without user consent by cross-site links, images, or prefetch requests.",
            "Use HTTP POST with anti-CSRF tokens and SameSite=Strict cookies.",
            "Form posts to: " + where));
        }

        // Pentesting Case 5: Unrestricted File Upload
        const fileInputs = q('input[type="file"]', form);
        if (fileInputs.length) {
          const unconstrained = fileInputs.filter(fi => !fi.hasAttribute("accept") || fi.getAttribute("accept") === "*/*" || fi.getAttribute("accept") === "");
          if (unconstrained.length) {
            problems++;
            out.push(f("forms", "upload-unrestricted", "high", "review",
              "Unrestricted file upload input without type validation",
              "The file upload input does not specify accepted file extensions or MIME types (accept attribute). Unchecked uploads may allow executable scripts (.php, .exe) to be uploaded.",
              "Specify the accept attribute (e.g. accept='image/*') and strictly validate file extension, MIME type, and magic bytes on the server.",
              "Upload field: " + (unconstrained[0].name || "uploaded")));
          }
          const hasMaxFileSize = q('input[type="hidden"][name="MAX_FILE_SIZE"]', form).length > 0;
          if (hasMaxFileSize) {
            out.push(f("forms", "upload-client-limit", "low", "review",
              "Form relies on client-side MAX_FILE_SIZE limit",
              "Hidden MAX_FILE_SIZE inputs are not enforced by browsers or servers and can be easily bypassed by attackers.",
              "Enforce file upload size limits in backend server configuration and code.",
              "Form posts to: " + where));
          }
        }

        // Pentesting Case 6: Insecure CAPTCHA multi-step workflow bypass
        const stepInput = q('input[type="hidden"][name="step"]', form)[0];
        if (stepInput && pw) {
          problems++;
          out.push(f("forms", "captcha-step-bypass", "medium", "likely",
            "Multi-step verification workflow relies on client-side hidden field",
            "The form includes a hidden 'step' parameter. If workflow progression is not tracked in server session state, attackers can tamper with 'step' to bypass CAPTCHA verification.",
            "Track verification steps exclusively in the server-side user session.",
            "Hidden field: step=" + (stepInput.value || "1")));
        }
      });
      if (crossSensitive.length) { problems++; out.push(f("forms", "form-cross-sensitive", "medium", "review", "A sensitive form sends data to another site", "Passwords or card details are submitted to a different domain. That is correct for payment providers but dangerous otherwise.", "Confirm you trust the receiving site.", "Posts to: " + list(crossSensitive))); }
      if (noCsrf) { problems++; out.push(f("forms", "form-csrf", "low", "review", `${noCsrf} POST form${noCsrf > 1 ? "s" : ""} without a visible anti-forgery token`, "Without a token (or SameSite cookies), another site may be able to submit these forms for a logged-in visitor.", "Check that your framework adds CSRF protection or that session cookies use SameSite=Lax/Strict.", "Some frameworks protect forms in ways a page scan cannot see.")); }
      if (!problems) pass("forms", "forms-pass", `${forms.length} form${forms.length > 1 ? "s" : ""} look safe`);
    });

    /* ---- links & frames ---- */
    run("links", () => {
      let issues = 0;
      const base = document.querySelector("base[href]");
      if (base) { const u = parseUrl(base.getAttribute("href")); if (u && u.origin !== location.origin) { issues++; out.push(f("links", "base-external", "medium", "confirmed", "The page's base URL points to another site", "Every relative link and script on the page loads from that site.", "Remove the <base> tag or point it at your own origin.", "base href = " + u.href.slice(0, 100))); } }
      const frames = q("iframe[src]").filter(fr => { const u = parseUrl(fr.getAttribute("src")); return u && /^https?:$/.test(u.protocol) && u.origin !== location.origin && !fr.hasAttribute("sandbox"); });
      if (frames.length) { issues++; out.push(f("links", "iframe-nosandbox", "low", "review", `${frames.length} embedded third-party frame${frames.length > 1 ? "s" : ""} without sandbox`, "A sandbox limits what an embedded page can do (open pop-ups, navigate your page, run plugins).", 'Add sandbox="allow-scripts allow-same-origin" (or tighter) to frames you do not fully trust.', list(frames.map(x => (parseUrl(x.getAttribute("src")) || {}).host || ""), 5), MDN + "HTML/Element/iframe#sandbox")); }
      const refresh = document.querySelector('meta[http-equiv="refresh" i]');
      if (refresh) { const m = /url\s*=\s*([^;]+)$/i.exec(refresh.getAttribute("content") || ""); const u = m && parseUrl(m[1].trim().replace(/^['"]|['"]$/g, "")); if (u && u.origin !== location.origin) { issues++; out.push(f("links", "meta-refresh", "low", "review", "Page auto-redirects to another site", "A meta refresh sends visitors away without a click.", "Use a server-side redirect, and only to places you control.", u.href.slice(0, 100))); } }
      const blank = q('a[target="_blank"]').filter(a => !/noopener|noreferrer/i.test(a.getAttribute("rel") || ""));
      if (blank.length) out.push(f("links", "blank-noopener", "info", "confirmed", `${blank.length} link${blank.length > 1 ? "s open" : " opens"} in a new tab without rel="noopener"`, "Current browsers already treat these safely. Old browsers let the new tab control your page.", 'Add rel="noopener noreferrer" for older-browser safety.', ""));
      if (!issues) pass("links", "links-pass", "No risky links or frames found");
    });

    /* ---- third-party code (SRI) ---- */
    run("supply", () => {
      const STATIC_CDN = /(^|\.)(cdnjs\.cloudflare\.com|cdn\.jsdelivr\.net|unpkg\.com|code\.jquery\.com|ajax\.googleapis\.com|stackpath\.bootstrapcdn\.com|maxcdn\.bootstrapcdn\.com|cdn\.bootcdn\.net|cdn\.staticfile\.org)$/i;
      const noSri = [], dynamic = new Set();
      const tags = extScripts.concat(q('link[rel~="stylesheet"][href]'));
      tags.forEach(el => {
        const u = parseUrl(el.src || el.href);
        if (!u || !/^https?:$/.test(u.protocol) || !isThird(u.hostname)) return;
        if (el.integrity) return;
        if (STATIC_CDN.test(u.hostname)) noSri.push(u.host + u.pathname.slice(0, 40));
        else dynamic.add(u.hostname);
      });
      if (noSri.length) out.push(f("supply", "sri-missing", "medium", "likely", `${noSri.length} library file${noSri.length > 1 ? "s" : ""} from a public CDN without an integrity check`, "If the CDN is hacked, or the file changes, malicious code would run on your site. An integrity hash makes the browser refuse changed files.", 'Add integrity="sha384-…" and crossorigin="anonymous" to these tags (srihash.org generates them).', list(noSri, 4), MDN + "Security/Subresource_Integrity"));
      else if (tags.length) pass("supply", "sri-pass", "Public CDN files are integrity-checked (or none are used)");
      if (dynamic.size) out.push(f("supply", "third-party-scripts", "info", "confirmed", `Code loaded from ${dynamic.size} other site${dynamic.size > 1 ? "s" : ""}`, "Analytics, ads and widgets can change at any time and run with full access to your page.", "Keep only what you need and review each provider.", list(Array.from(dynamic), 10)));
    });

    /* ---- XSS surfaces ---- */
    run("xss", () => {
      let issues = 0;
      let handlers = 0;
      const els = q("*").slice(0, MAX_EL);
      els.forEach(el => { for (const a of el.attributes || []) if (/^on[a-z]+$/i.test(a.name)) handlers++; });
      if (handlers) { issues++; out.push(f("xss", "xss-inline-handlers", handlers > 10 ? "medium" : "low", "confirmed", `${handlers} inline event handler${handlers > 1 ? "s" : ""} (onclick=, onerror=, …)`, "Inline handlers are the easiest way for an injected tag to run code, and they stop you from using a strict CSP.", "Move them to addEventListener() in a script file.", "", MDN + "HTTP/Guides/CSP#inline_javascript")); }
      const js = q("a[href], form[action], iframe[src]").filter(el => /^\s*javascript:/i.test(el.getAttribute("href") || el.getAttribute("action") || el.getAttribute("src") || ""));
      if (js.length) { issues++; out.push(f("xss", "xss-js-uri", "medium", "confirmed", `${js.length} javascript: link${js.length > 1 ? "s" : ""}`, "javascript: addresses run code when clicked and are blocked by a strict CSP.", "Replace them with real links or buttons that use event listeners.", "")); }
      let sinks = 0, flows = 0, msgNoOrigin = 0;
      inlineScripts.forEach(s => {
        const t = (s.textContent || "").slice(0, 200000);
        const r = scanScriptText(t);
        if (r.flow) flows++; else if (r.sink) sinks++;
        if (/addEventListener\(\s*["']message["']/.test(t) && !/\.origin\b/.test(t)) msgNoOrigin++;
      });
      if (flows) { issues++; out.push(f("xss", "xss-dom-flow", "medium", "review", `${flows} inline script${flows > 1 ? "s" : ""} may feed URL data into the page`, "The script reads data a visitor controls (URL, referrer) and also writes HTML or runs code. If the data is not cleaned first, that is DOM-based XSS.", "Use textContent instead of innerHTML, and never pass URL data to eval or document.write.", "A scan cannot trace the data flow. Treat this as a prompt to review the code.", MDN + "Security/Types_of_attacks#cross-site_scripting_xss")); }
      if (sinks) { issues++; out.push(f("xss", "xss-sinks", "low", "review", `${sinks} inline script${sinks > 1 ? "s" : ""} use risky functions`, "innerHTML, document.write and eval() are safe only with trusted data.", "Prefer textContent, DOM methods and a sanitiser such as DOMPurify.", "")); }
      if (msgNoOrigin) { issues++; out.push(f("xss", "xss-postmessage", "low", "review", `${msgNoOrigin} message listener${msgNoOrigin > 1 ? "s" : ""} that may not check the sender`, "Without an origin check, any other site can send your page messages.", "Check event.origin against an allow-list before using event.data.", "", MDN + "API/Window/postMessage#security_concerns")); }
      try {
        const params = new URLSearchParams(location.search);
        const reflected = [];
        const html = (document.documentElement.outerHTML || "").slice(0, 2000000);
        params.forEach((val, key) => {
          if (!val || val.length < 5 || /^\d+$/.test(val) || /^(true|false|null)$/i.test(val)) return;
          if (!html.includes(val)) return;
          const inScript = inlineScripts.some(s => (s.textContent || "").includes(val));
          const inHandler = els.some(el => { for (const a of el.attributes || []) if (/^on/i.test(a.name) && a.value.includes(val)) return true; return false; });
          reflected.push({ key, risky: inScript || inHandler });
        });
        const risky = reflected.filter(r => r.risky);
        if (risky.length) { issues++; out.push(f("xss", "xss-reflect-risky", "high", "likely", "A URL parameter is placed inside script code", "The value of this parameter appears inside a <script> or an on* handler. If it is not escaped, a crafted link can run code on your page.", "Escape output for its context (JavaScript string, HTML attribute) or avoid echoing the parameter.", "Parameters: " + list(risky.map(r => r.key)))); }
        const plain = reflected.filter(r => !r.risky);
        if (plain.length) out.push(f("xss", "xss-reflect", "info", "review", "URL values are shown on the page", "Search pages do this on purpose. It is only a problem if the output is not HTML-escaped.", "Confirm the server escapes these values.", "Parameters: " + list(plain.map(r => r.key))));
      } catch (_) {}
      // Pentesting Case 9: Stored XSS guestbook/message inputs
      const storedInputs = [];
      q("form input[name], form textarea[name]").forEach(i => {
        const n = (i.name || "").toLowerCase();
        if (/^(txtname|mtxmessage|guestbook|comment|message|post_body|user_comment)$/i.test(n)) {
          storedInputs.push(i.name);
        }
      });
      if (storedInputs.length >= 2) {
        issues++;
        out.push(f("xss", "xss-stored-guestbook", "high", "review",
          "Stored content input form (guestbook / comments) detected",
          "User comments and messages stored in the database and rendered back to other visitors must be contextually HTML-escaped to prevent Stored XSS.",
          "Sanitize input and escape all dynamic HTML output with a library such as DOMPurify or framework auto-escaping.",
          "Form fields: " + list(storedInputs, 5)));
      }

      if (!issues) pass("xss", "xss-pass", "No risky script patterns found");
    });

    /* ---- open redirects ---- */
    run("redirect", () => {
      const own = paramRedirects(location.search);
      let issues = 0;
      if (own.length) {
        issues++;
        const named = own.filter(o => o.named);
        out.push(f("redirect", "redirect-param", named.length ? "medium" : "low", "review",
          "A URL parameter holds a web address",
          "If the site redirects to whatever address this parameter contains, attackers can send victims to a fake site from a link on your domain.",
          "Only redirect to addresses on an allow-list, or to relative paths.", "Parameters: " + list(own.map(o => o.key))));
      }
      const links = q("a[href]").slice(0, 3000).filter(a => {
        const u = parseUrl(a.getAttribute("href"));
        if (!u || u.origin !== location.origin) return false;
        let hasParam = false;
        try {
          new URLSearchParams(u.search).forEach((val, key) => {
            if (REDIRECT_KEYS.test(key) && val.length > 0) hasParam = true;
          });
        } catch (_) {}
        return hasParam || paramRedirects(u.search).some(p => p.named);
      });
      if (links.length) {
        issues++;
        out.push(f("redirect", "redirect-links", "low", "review",
          `${links.length} link${links.length > 1 ? "s" : ""} on this page pass a destination address to your site`,
          "These look like redirect endpoints (e.g. ?redirect=... or ?next=...). Verify each one validates its target against an allow-list.",
          "Restrict redirect targets to a strict allow-list.",
          list(links.map(a => (parseUrl(a.getAttribute("href")) || {}).pathname || ""), 4)));
      }
      if (!issues) pass("redirect", "redirect-pass", "No redirect parameters found");
    });

    /* ---- database / debug / secret leaks ---- */
    run("leaks", () => {
      let issues = 0;
      const text = ((document.body && document.body.innerText) || "").slice(0, 400000);
      const codeText = q("pre, code, textarea, .highlight").map(e => e.textContent || "").join("\n");
      const db = findDbError(text);
      if (db) {
        const doc = codeText.includes(db);
        issues++;
        out.push(f("leaks", "leak-db-error", doc ? "low" : "high", doc ? "review" : "likely", doc ? "Database error text appears in a code sample" : "The page shows a database error",
          doc ? "It looks like documentation, not a live error." : "Error messages reveal table names and query structure and are a gift to attackers. They also mean a query is failing.",
          doc ? "No action needed if this is a tutorial." : "Turn off detailed errors in production, log them privately, and fix the failing query with prepared statements.", "Matched: " + db.slice(0, 80)));
      }
      const dbg = findDebugPage(text);
      if (dbg) { issues++; out.push(f("leaks", "leak-debug", "high", "likely", `Debug information is visible (${dbg})`, "Stack traces expose file paths, library versions and sometimes passwords or tokens.", "Disable debug mode and show a generic error page in production.", "")); }
      if (/^Index of \//m.test(text.slice(0, 300)) || /<title>\s*Index of \//i.test(document.head ? document.head.innerHTML : "")) { issues++; out.push(f("leaks", "leak-dirlist", "medium", "likely", "Directory listing is turned on", "Visitors can browse and download every file in this folder.", "Disable directory indexing (Options -Indexes in Apache, autoindex off in nginx).", "")); }
      const hay = inlineScripts.map(s => (s.textContent || "").slice(0, 100000)).join("\n") + "\n" + (document.documentElement.outerHTML || "").slice(0, 600000);
      const seen = new Set();
      findSecrets(hay).forEach(s => {
        if (seen.has(s.name)) return;
        seen.add(s.name); issues++;
        out.push(f("leaks", "leak-secret-" + s.name.toLowerCase().replace(/\W+/g, "-"), s.level, "likely", `${s.name} found in the page source`,
          s.level === "low" ? "Google API keys are meant to be public but should be restricted to your domains and APIs." : "Secrets in page source can be copied by anyone who views the page.",
          s.level === "low" ? "Restrict the key by HTTP referrer and API in the Google Cloud console." : "Revoke and rotate this credential now, then keep it on the server.", "Preview: " + s.preview));
      });
      const comments = [];
      try {
        const walker = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_COMMENT);
        let n, c = 0;
        while ((n = walker.nextNode()) && c++ < 400) if (/password|passwd|secret|api[_-]?key|token|credential|todo:?|fixme|debug/i.test(n.nodeValue || "")) comments.push((n.nodeValue || "").trim().slice(0, 40));
      } catch (_) {}
      if (comments.length) { issues++; out.push(f("leaks", "leak-comments", "low", "review", `${comments.length} HTML comment${comments.length > 1 ? "s" : ""} mention sensitive words`, "Developer notes in the page source can hint at weak spots.", "Strip comments from production HTML.", "Starts with: " + list(comments.map(c => `"${c}…"`), 3))); }
      if (!issues) pass("leaks", "leak-pass", "No errors, debug output or secrets visible");
    });

    /* ---- database-facing inputs & command/LFI inspection ---- */
    run("inputs", () => {
      const names = [];
      q("form input[name], form select[name], form textarea[name]").forEach(i => { if (/^(id|uid|pid|q|query|search|filter|sort|order|cat|category)$|_id$/i.test(i.name)) names.push(i.name); });
      new URLSearchParams(location.search).forEach((v, k) => { if (/^(id|uid|pid|item|cat|page|sort|order|q|query|search)$|_id$/i.test(k)) names.push(k); });
      if (names.length) out.push(f("inputs", "inputs-db", "info", "review", "Inputs that probably query a database", "A page scan cannot see server code, so this is only a map of where to look. SQL injection is prevented with prepared statements on the server.", "Make sure every query that uses these values is parameterised.", "Fields: " + list(names, 10)));
      else pass("inputs", "inputs-none", "No database-style inputs spotted");

      // Pentesting Case 2: Command Injection inputs (ip, cmd, ping, exec, command, host)
      const cmdInputs = [];
      q("form input[name]").forEach(i => {
        const n = (i.name || "").toLowerCase();
        if (/^(ip|ping|cmd|exec|command|host|traceroute|shell|query_ip|target_host)$/i.test(n)) {
          if ((i.type === "text" || i.type === "") && !i.hasAttribute("pattern")) {
            cmdInputs.push(i.name);
          }
        }
      });
      if (cmdInputs.length) {
        out.push(f("inputs", "input-cmd-exec", "high", "review",
          "Form accepts command execution / network parameters",
          "Inputs like 'ip' or 'cmd' frequently pass parameters directly to system shells. If unescaped, shell command injection is possible.",
          "Use language-native network APIs instead of shell execution, and validate targets with strict IP or hostname regex.",
          "Command inputs: " + list(cmdInputs, 5)));
      }

      // Pentesting Case 4: File Inclusion parameters in URL or Links
      const lfiParams = [];
      new URLSearchParams(location.search).forEach((v, k) => {
        if (/^(page|file|include|template|doc|document|view|layout|path)$/i.test(k) &&
            (/\.(php|inc|html|txt|cgi|asp|jsp)(\?|$)/i.test(v) || /\.\./.test(v))) {
          lfiParams.push(`${k}=${v}`);
        }
      });
      if (lfiParams.length) {
        out.push(f("inputs", "lfi-file-param", "high", "review",
          "File inclusion parameter detected in URL",
          "Parameters specifying filenames (e.g. page=include.php) can expose Local File Inclusion (LFI) or Remote File Inclusion (RFI) if included directly by backend code.",
          "Map permitted views to internal identifiers or an allowlist instead of accepting file paths from request parameters.",
          "Parameters: " + list(lfiParams, 5)));
      }
      const lfiLinks = [];
      q("a[href]").forEach(a => {
        const u = parseUrl(a.getAttribute("href"));
        if (!u || u.origin !== location.origin) return;
        u.searchParams.forEach((v, k) => {
          if (/^(page|file|include|template|doc|document|view|layout|path)$/i.test(k) &&
              (/\.(php|inc|html|txt|cgi|asp|jsp)(\?|$)/i.test(v) || /\.\./.test(v))) {
            lfiLinks.push(`${k}=${v}`);
          }
        });
      });
      if (lfiLinks.length) {
        out.push(f("inputs", "lfi-link-param", "medium", "review",
          "Page links expose file inclusion parameters",
          "Internal links contain file inclusion vectors like '?page=file1.php'. Verify that the server validates and restricts allowed files.",
          "Use an allowlist of permitted identifiers instead of direct file names.",
          "Links: " + list(lfiLinks, 5)));
      }

      // Pentesting Case 7: Unconstrained SQLi inputs (id, user_id without type="number" or pattern)
      const sqliInputs = [];
      q("form input[name]").forEach(i => {
        const n = (i.name || "").toLowerCase();
        if (/^(id|user_id|item_id|cat_id|product_id|uid)$/i.test(n)) {
          if ((i.type === "text" || i.type === "") && !i.hasAttribute("pattern") && !i.getAttribute("maxlength")) {
            sqliInputs.push(i.name);
          }
        }
      });
      if (sqliInputs.length) {
        out.push(f("inputs", "sqli-unconstrained-input", "high", "review",
          "Unconstrained database query input 'id'",
          "The input field '" + sqliInputs.join(", ") + "' accepts unconstrained text. If concatenated directly into backend SQL queries without parameterization, it enables SQL Injection.",
          "Use parameterized queries (prepared statements) with ORM/database drivers, and constrain HTML inputs with type='number' or pattern='[0-9]+'.",
          "Target field: " + sqliInputs.join(", ")));
      }

      // Pentesting Case 11: Client-side cryptographic token computation in JavaScript
      const hasTokenInput = q('form input[type="hidden"][name*="token" i], form input[name*="token" i]').length > 0;
      const hasClientCrypto = inlineScripts.some(s => {
        const t = (s.textContent || "").toLowerCase();
        return (t.includes("md5") || t.includes("sha1") || t.includes("crypto") || t.includes("hash")) &&
               (t.includes("token") || t.includes("phrase") || t.includes("rot13"));
      });
      if (hasTokenInput && hasClientCrypto) {
        out.push(f("inputs", "js-client-crypto-token", "medium", "confirmed",
          "Client-side cryptographic token computation detected",
          "The page computes authentication or security tokens (MD5/hash) using client-side JavaScript. Client-side security mechanisms can be easily inspected, manipulated, and bypassed by attackers.",
          "Compute and validate security tokens exclusively on the server side.",
          "Form contains token calculated via client-side script"));
      }
    });

    /* ---- technology ---- */
    run("tech", () => {
      const add = (name, how, version, kind) => tech.push({ name, how, version: version || "", kind: kind || "web" });
      const gen = document.querySelector('meta[name="generator" i]');
      if (gen) { const c = gen.getAttribute("content") || ""; const m = /^(.*?)\s+v?(\d+(?:\.\d+)*)/.exec(c); add(m ? m[1] : c, "Generator meta tag", m && m[2], "cms"); }
      const srcs = extScripts.map(s => s.src).concat(q("link[href]").map(l => l.href));
      const has = re => srcs.some(s => re.test(s));
      if (has(/\/wp-content\/|\/wp-includes\//)) add("WordPress", "wp-content paths", "", "cms");
      if (has(/\/sites\/default\/files\//)) add("Drupal", "sites/default paths", "", "cms");
      if (has(/cdn\.shopify\.com/)) add("Shopify", "Shopify CDN", "", "cms");
      if (has(/static\.parastorage\.com|wixstatic/)) add("Wix", "Wix assets", "", "cms");
      if (has(/squarespace/)) add("Squarespace", "Squarespace assets", "", "cms");
      if (document.getElementById("__next") || document.getElementById("__NEXT_DATA__") || has(/\/_next\/static\//)) add("Next.js", "__next markers", "", "framework");
      if (document.getElementById("__nuxt") || has(/\/_nuxt\//)) add("Nuxt", "__nuxt markers", "", "framework");
      const ng = document.querySelector("[ng-version]");
      if (ng) add("Angular", "ng-version attribute", ng.getAttribute("ng-version"), "framework");
      if (document.querySelector("[ng-app]")) add("AngularJS", "ng-app attribute", "", "framework");
      if (document.querySelector("[data-reactroot]") || has(/react(?:-dom)?(?:\.production)?(?:\.min)?\.js/)) add("React", "React markers", "", "framework");
      if (document.querySelector("[data-v-app], [data-server-rendered]") || has(/vue(?:\.runtime)?(?:\.global)?(?:\.prod)?(?:\.min)?\.js/)) add("Vue", "Vue markers", "", "framework");
      if (has(/googletagmanager\.com/)) add("Google Tag Manager", "script source", "", "analytics");
      if (has(/google-analytics\.com|gtag\/js/)) add("Google Analytics", "script source", "", "analytics");
      if (has(/connect\.facebook\.net/)) add("Meta Pixel / SDK", "script source", "", "analytics");
      if (has(/js\.stripe\.com/)) add("Stripe.js", "script source", "", "payments");
      srcs.forEach(src => {
        const m = /(jquery|bootstrap|lodash|moment|angular|react|vue|d3|three|chart|axios)[-.@/]v?(\d+\.\d+(?:\.\d+)?)/i.exec(src);
        if (m) add(m[1].replace(/^./, c => c.toUpperCase()), "file name", m[2], "library");
        libIssues(src).forEach(v => out.push(f("supply", "lib-" + v.name.toLowerCase().replace(/\W/g, "") + "-" + v.ver, "medium", "likely",
          `${v.name} ${v.ver} is out of date`, `This version ${v.msg}.`, `Upgrade to ${v.to}.`, "Found in: " + src.slice(0, 100))));
      });
    });

    return { url: location.href, scannedAt: Date.now(), engine: "2.0", findings: out, facts, tech, errors };
  }

  /* ---------------- messaging ---------------- */
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || (msg.type !== "detectiveScan" && msg.type !== "securityScanPage")) return;
    if (GEN !== window.__memikSecScanGen) return;       // a newer copy of this script owns the listener
    try { sendResponse({ ok: true, result: scan() }); }
    catch (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); }
    return true;
  });

  if (typeof globalThis !== "undefined" && globalThis.__MEMIK_TEST__) {
    globalThis.__MEMIK_TEST__.scanner = { scan, etld1, cmpVer, libIssues, scanScriptText, findDbError, findDebugPage, findSecrets, paramRedirects };
  }
})();
