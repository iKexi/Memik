/**
 * popup/components/detective/detective-page.js — the Detective page's entry point.
 *
 * Replaces what used to be a few hundred lines of top-level code inside popup.js's
 * IIFE. `init()` runs once, at popup load, wiring every control's event listener
 * (cheap and safe to do before the page is ever shown — the original code did the
 * same). `onOpen()` runs each time the person navigates to the Detective page.
 *
 * This is the only file that needs to know about every other Detective component;
 * nothing else needs to import this one.
 *
 * Plain script, exposes a single global: `DetectivePage`.
 */
(function (root) {
  "use strict";

  async function init() {
    await DetectiveAppearanceControls.init();
    DetectiveAppearanceControls.bind();
    DetectiveScanActions.bind();
    DetectiveSiteInfoView.bind();
    DetectiveVisitedView.bind();
    DetectivePortScanView.bind();
    DetectiveToolkitView.bind();

    // The Simple/Detailed toggle lives on the report view, but both the report and the
    // port-scan view read DetectiveStore's `view` when drawing themselves, so both need
    // to redraw when it changes.
    DetectiveStore.subscribe((state, prev) => {
      if (state.view === prev.view) return;
      if (state.report) DetectiveReportView.render(state.report);
      if (state.ports) DetectivePortScanView.render(state.ports);
    });
  }

  /** Called every time the Detective page is navigated to. */
  function onOpen() {
    DetectiveAppearanceControls.sync();
    const box = document.getElementById("detPortBox");
    if (box && box.open) DetectivePortScanView.load();
  }

  const DetectivePage = { init, onOpen };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectivePage;
  else root.DetectivePage = DetectivePage;
})(typeof window !== "undefined" ? window : globalThis);
