/**
 * popup/components/detective/scan-actions.js — "Run all checks" and the per-category buttons.
 *
 * Plain script, exposes a single global: `DetectiveScanActions`.
 */
(function (root) {
  "use strict";
  const { $, h, clearEl } = root;

  function setBusy(on) {
    DetectiveStore.patch({ busy: on });
    document.querySelectorAll("#page-detective .vpn-action").forEach(b => { b.disabled = on; b.setAttribute("aria-busy", String(on)); });
  }

  async function run(mode) {
    if (DetectiveStore.get().busy) return;
    const out = clearEl($("auditResults"));
    const st = $("detScanStatus");
    if (st) { st.textContent = "Scanning this page…"; st.className = "note"; }
    out.appendChild(h("div", { class: "det-loading" }, h("span", { class: "det-spinner", "aria-hidden": "true" }), "Checking the page and its server response…"));
    setBusy(true);
    try {
      const tab = await DetectiveApi.activeHttpTab();
      const reply = await DetectiveApi.runScan(mode, tab.id);
      DetectiveReportView.render(reply);
    } catch (e) {
      const msg = e.message || String(e);
      clearEl(out).appendChild(h("div", { class: "det-error", role: "alert" }, h("strong", null, "The scan could not finish."), h("span", null, msg)));
      if (st) { st.textContent = "Scan failed."; st.className = "note det-status-bad"; }
    } finally { setBusy(false); }
  }

  const CATEGORY_BUTTONS = [
    ["detInfoBtn", "info"], ["detLinksBtn", "links"], ["detHeadersBtn", "headers"], ["detMixBtn", "mixed"],
    ["detCookieBtn", "cookie"], ["detCspBtn", "csp"], ["detXssBtn", "xss"], ["detSqlBtn", "sql"], ["detRedirectBtn", "redirect"]
  ];

  function bind() {
    CATEGORY_BUTTONS.forEach(([id, mode]) => { if ($(id)) $(id).onclick = () => run(mode); });
    if ($("auditScanBtn")) $("auditScanBtn").onclick = () => run("all");
  }

  const DetectiveScanActions = { run, bind };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveScanActions;
  else root.DetectiveScanActions = DetectiveScanActions;
})(typeof window !== "undefined" ? window : globalThis);
