/**
 * popup/state/detective-store.js — Detective's popup UI state.
 *
 * Holds the state that used to live as a loose module-level object inside popup.js
 * (view mode, display preferences, the last report, in-progress port scan). Components
 * read it with `DetectiveStore.get()` and re-render on `DetectiveStore.subscribe(fn)`;
 * nothing here talks to chrome.* APIs — that's popup/services/detective-api.js.
 *
 * Display preferences (view/palette/density) are persisted to chrome.storage.local
 * under CONFIG.detective.storageKeys.uiPrefs; call `DetectiveStore.loadPrefs()` once
 * when the Detective page is opened.
 *
 * Plain script, exposes a single global: `DetectiveStore`.
 */
(function (root) {
  "use strict";

  const store = createStore({
    view: "simple",            // "simple" | "detailed"
    palette: "std",            // "std" | "cb" (colour-blind safe)
    density: "comfortable",    // "comfortable" | "compact"
    busy: false,               // a full/category scan is in flight
    report: null,              // the last scan report
    ports: null                // the last port-scan state (mirrors chrome.storage.session)
  });

  async function loadPrefs() {
    try {
      const key = CONFIG.detective.storageKeys.uiPrefs;
      const { [key]: prefs } = await chrome.storage.local.get({ [key]: null });
      if (prefs && typeof prefs === "object") {
        const patch = {};
        if (prefs.view === "simple" || prefs.view === "detailed") patch.view = prefs.view;
        if (prefs.palette === "std" || prefs.palette === "cb") patch.palette = prefs.palette;
        if (prefs.density === "comfortable" || prefs.density === "compact") patch.density = prefs.density;
        if (Object.keys(patch).length) store.patch(patch);
      }
    } catch (e) { if (typeof Logger !== "undefined") Logger.warn("detective-store", "could not load display prefs", {}, e); }
  }

  function savePrefs() {
    const { view, palette, density } = store.get();
    const key = CONFIG.detective.storageKeys.uiPrefs;
    chrome.storage.local.set({ [key]: { view, palette, density } }).catch(e => {
      if (typeof Logger !== "undefined") Logger.warn("detective-store", "could not save display prefs", {}, e);
    });
  }

  /** Patch view/palette/density and persist. The one way components should change a display pref. */
  function setDisplay(partial) { store.patch(partial); savePrefs(); }

  const DetectiveStore = Object.assign({}, store, { loadPrefs, setDisplay });
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveStore;
  else root.DetectiveStore = DetectiveStore;
})(typeof window !== "undefined" ? window : globalThis);
