/**
 * popup/components/detective/toolkit-view.js — two small, fully local tools in Detective,
 * inspired by OWASP PTK's JWT and Decoder pages:
 *
 *   • JWT inspector      — decodes a token and flags risky settings (alg none, no expiry,
 *                          key-injection headers…). Tries a short list of very common
 *                          HMAC secrets so weak signing keys on YOUR tokens show up.
 *   • Encoder / decoder  — Base64, Base64URL, URL, Hex, HTML entities and SHA hashes.
 *
 * Nothing is sent anywhere: everything runs in the popup with the Web Crypto API.
 * Plain script; exposes `DetectiveToolkitView` (pure helpers are reachable for tests).
 */
(function (root) {
  "use strict";

  /* ------------------------------------------------------------ codecs */
  const te = typeof TextEncoder !== "undefined" ? new TextEncoder() : null;
  const td = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { fatal: true }) : null;

  const bytesToB64 = bytes => { let s = ""; for (const b of bytes) s += String.fromCharCode(b); return btoa(s); };
  const b64ToBytes = str => {
    const clean = String(str).replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
    const bin = atob(clean + "=".repeat((4 - clean.length % 4) % 4));
    return Uint8Array.from(bin, c => c.charCodeAt(0));
  };
  const toHex = bytes => Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
  const fromHex = str => {
    const h = String(str).replace(/0x/gi, "").replace(/[\s:,-]+/g, "");
    if (!/^[0-9a-f]*$/i.test(h) || h.length % 2) throw new Error("Not valid hex (needs pairs of 0-9 a-f).");
    return Uint8Array.from(h.match(/../g) || [], x => parseInt(x, 16));
  };
  const htmlEnc = s => String(s).replace(/[&<>"'`]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;", "`": "&#96;" }[c]));
  const htmlDec = s => String(s)
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d))
    .replace(/&(lt|gt|quot|apos|amp);/g, (_, n) => ({ lt: "<", gt: ">", quot: '"', apos: "'", amp: "&" }[n]));

  async function digest(algo, text) {
    const buf = await crypto.subtle.digest(algo, te.encode(text));
    return toHex(new Uint8Array(buf));
  }

  const OPS = {
    b64enc: { label: "Base64 encode", run: async s => bytesToB64(te.encode(s)) },
    b64dec: { label: "Base64 decode", run: async s => td.decode(b64ToBytes(s)) },
    b64uenc: { label: "Base64URL encode", run: async s => bytesToB64(te.encode(s)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") },
    urlenc: { label: "URL encode", run: async s => encodeURIComponent(s) },
    urldec: { label: "URL decode", run: async s => decodeURIComponent(s.replace(/\+/g, " ")) },
    hexenc: { label: "Hex encode", run: async s => toHex(te.encode(s)) },
    hexdec: { label: "Hex decode", run: async s => td.decode(fromHex(s)) },
    htmlenc: { label: "HTML entities encode", run: async s => htmlEnc(s) },
    htmldec: { label: "HTML entities decode", run: async s => htmlDec(s) },
    sha1: { label: "SHA-1", run: s => digest("SHA-1", s) },
    sha256: { label: "SHA-256", run: s => digest("SHA-256", s) },
    sha384: { label: "SHA-384", run: s => digest("SHA-384", s) },
    sha512: { label: "SHA-512", run: s => digest("SHA-512", s) }
  };

  async function transform(op, text) {
    const o = OPS[op]; if (!o) throw new Error("Pick an operation.");
    try { return await o.run(String(text)); }
    catch (e) {
      const name = e && e.name;
      if (name === "InvalidCharacterError") throw new Error("That is not valid Base64.");
      if (name === "URIError") throw new Error("That is not valid URL encoding.");
      if (name === "TypeError") throw new Error("The result is not readable text (binary data).");
      throw e;
    }
  }

  /* --------------------------------------------------------------- JWT */
  const WEAK_SECRETS = ["secret", "password", "123456", "12345678", "changeme", "admin", "jwt", "jwtsecret", "jwt_secret",
    "your-256-bit-secret", "your-secret", "mysecret", "supersecret", "secretkey", "secret123", "key", "test", "default",
    "qwerty", "letmein", "token", "private", "s3cr3t", "HS256", "hmac", "app", "dev", "development", "production", "1234567890"];

  function parseJwt(raw) {
    const token = String(raw || "").trim().replace(/^bearer\s+/i, "").replace(/\s+/g, "");
    const parts = token.split(".");
    if (parts.length < 2 || parts.length > 3 || parts.slice(0, 2).some(p => !/^[A-Za-z0-9_-]+$/.test(p)))
      throw new Error("That does not look like a JWT (expected header.payload.signature).");
    let header, payload;
    try { header = JSON.parse(td.decode(b64ToBytes(parts[0]))); payload = JSON.parse(td.decode(b64ToBytes(parts[1]))); }
    catch (_) { throw new Error("The header or payload is not valid Base64URL JSON."); }
    if (!header || typeof header !== "object") throw new Error("The JWT header is not a JSON object.");
    return { token, parts, header, payload, signature: parts[2] || "" };
  }

  const when = sec => { const d = new Date(sec * 1000); return isNaN(d) ? String(sec) : d.toISOString().replace("T", " ").slice(0, 19) + " UTC"; };

  function analyzeJwt(jwt, nowMs) {
    const now = (nowMs || Date.now()) / 1000;
    const h = jwt.header, p = jwt.payload && typeof jwt.payload === "object" ? jwt.payload : {};
    const out = [];
    const add = (level, title, why) => out.push({ level, title, why: why || "" });
    const alg = String(h.alg || "");

    if (!alg) add("high", "No algorithm declared", "A token without `alg` cannot be verified reliably.");
    else if (/^none$/i.test(alg)) add("critical", "Algorithm is “none” — the token is unsigned", "Anyone can forge it. Servers must reject `alg: none`.");
    else if (/^HS/i.test(alg)) add("info", `Signed with a shared secret (${alg})`, "Anyone who learns the secret can mint tokens. Use a long random key, or an asymmetric algorithm (RS/ES/EdDSA).");
    if (!/^none$/i.test(alg) && !jwt.signature) add("high", "Signature part is empty", "The token carries no signature.");
    for (const k of ["jku", "x5u", "jwk", "x5c"]) if (k in h) add("high", `Header “${k}” can point a server at an attacker's key`, "Servers should ignore key-location headers supplied inside the token.");
    if (typeof h.kid === "string" && /[\/\\'";]|\.\.|\s--/.test(h.kid)) add("high", "Suspicious “kid” header", "Key IDs containing path or SQL characters have been used for file-read and injection attacks.");

    if (p.exp == null) add("medium", "No expiry (exp)", "A stolen token would work forever.");
    else if (typeof p.exp !== "number") add("medium", "Expiry is not a number");
    else if (p.exp < now) add("info", `Expired on ${when(p.exp)}`);
    else {
      const days = Math.round((p.exp - now) / 86400);
      if (days > 365) add("medium", `Valid for another ${days} days`, "Very long lifetimes make stolen tokens dangerous. Prefer minutes to hours plus refresh tokens.");
      else add("ok", `Expires ${when(p.exp)}`);
    }
    if (typeof p.nbf === "number" && p.nbf > now) add("info", `Not valid before ${when(p.nbf)}`);
    if (p.iss == null) add("low", "No issuer (iss)", "Without iss/aud checks a token from one service can be replayed against another.");
    if (p.aud == null) add("low", "No audience (aud)");
    const sensitive = Object.keys(p).filter(k => /pass(word)?|secret|ssn|card|cvv|private/i.test(k));
    if (sensitive.length) add("medium", `Sensitive-looking claim${sensitive.length > 1 ? "s" : ""}: ${sensitive.join(", ")}`, "JWT payloads are only encoded, not encrypted — anyone holding the token can read them.");
    return out;
  }

  async function weakSecret(jwt) {
    const m = /^HS(256|384|512)$/i.exec(String(jwt.header.alg || ""));
    if (!m || !jwt.signature || jwt.parts.length !== 3) return null;
    const data = te.encode(jwt.parts[0] + "." + jwt.parts[1]);
    const want = jwt.signature;
    for (const secret of WEAK_SECRETS) {
      const key = await crypto.subtle.importKey("raw", te.encode(secret), { name: "HMAC", hash: "SHA-" + m[1] }, false, ["sign"]);
      const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, data));
      if (bytesToB64(sig).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") === want) return secret;
    }
    return null;
  }

  async function inspectJwt(raw, nowMs) {
    const jwt = parseJwt(raw);
    const findings = analyzeJwt(jwt, nowMs);
    const secret = await weakSecret(jwt);
    if (secret) findings.unshift({ level: "critical", title: `Signed with a guessable secret: “${secret}”`, why: "Attackers can forge valid tokens. Rotate to a long random key now." });
    return { header: jwt.header, payload: jwt.payload, findings };
  }

  /* -------------------------------------------------------------- DOM */
  function bind() {
    if (typeof document === "undefined") return;
    const $ = id => document.getElementById(id);
    const say = (m, k) => { if (root.say) root.say(m, k); };
    const copy = async (text, ok) => { try { await navigator.clipboard.writeText(text); say(ok, "ok"); } catch (_) { say("Could not copy.", "error"); } };
    const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };

    /* JWT */
    const jBtn = $("detJwtBtn");
    if (jBtn) {
      const run = async () => {
        const out = $("detJwtOut"); out.textContent = "";
        try {
          const r = await inspectJwt($("detJwtInput").value);
          for (const f of r.findings) {
            const row = el("div", "det-jwt-row det-jwt-" + f.level);
            row.appendChild(el("strong", "", f.title));
            if (f.why) row.appendChild(el("span", "", f.why));
            out.appendChild(row);
          }
          for (const [label, obj] of [["Header", r.header], ["Payload", r.payload]]) {
            const box = el("details", "det-jwt-json"); box.open = true;
            box.appendChild(el("summary", "", label));
            box.appendChild(el("pre", "", JSON.stringify(obj, null, 2)));
            out.appendChild(box);
          }
        } catch (e) { out.appendChild(el("div", "det-jwt-row det-jwt-high", e.message || String(e))); }
      };
      jBtn.addEventListener("click", run);
      const clr = $("detJwtClear"); if (clr) clr.addEventListener("click", () => { $("detJwtInput").value = ""; $("detJwtOut").textContent = ""; });
    }

    /* Encoder / decoder */
    const eBtn = $("detEncRun"), sel = $("detEncOp");
    if (eBtn && sel) {
      sel.innerHTML = Object.entries(OPS).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("");
      const go = async () => {
        const out = $("detEncOut");
        try { out.value = await transform(sel.value, $("detEncInput").value); out.classList.remove("det-err"); }
        catch (e) { out.value = e.message || String(e); out.classList.add("det-err"); }
      };
      eBtn.addEventListener("click", go);
      $("detEncInput").addEventListener("input", () => { if ($("detEncLive") && $("detEncLive").checked) go(); });
      const cp = $("detEncCopy"); if (cp) cp.addEventListener("click", () => { const v = $("detEncOut").value; if (v) copy(v, "Result copied."); });
      const sw = $("detEncSwap"); if (sw) sw.addEventListener("click", () => { $("detEncInput").value = $("detEncOut").value; $("detEncOut").value = ""; });
    }
  }

  const DetectiveToolkitView = { bind, transform, parseJwt, analyzeJwt, inspectJwt, OPS };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveToolkitView;
  else root.DetectiveToolkitView = DetectiveToolkitView;
})(typeof window !== "undefined" ? window : globalThis);
