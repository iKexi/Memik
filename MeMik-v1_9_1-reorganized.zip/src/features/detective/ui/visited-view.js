/**
 * popup/components/detective/visited-view.js — "Visited sites & IPs" panel.
 *
 * `visitedCache`/`clearArm` are view-local (not in DetectiveStore): nothing outside
 * this panel needs them, so there's no reason to make them shared state.
 *
 * Plain script, exposes a single global: `DetectiveVisitedView`.
 */
(function (root) {
  "use strict";
  const { $, h, clearEl, plural, fmtAgo } = root;

  let visitedCache = [];
  let clearArm = 0;

  function render() {
    const box = clearEl($("detVisitedList"));
    const q = (($("detVisitedFilter") && $("detVisitedFilter").value) || "").trim().toLowerCase();
    const enabled = $("detLogToggle") && $("detLogToggle").checked;
    const rows = visitedCache.filter(v => !q || v.host.toLowerCase().includes(q) || (v.ips || []).some(i => i.toLowerCase().includes(q)));
    if (!rows.length) {
      box.appendChild(h("p", { class: "note" }, !visitedCache.length
        ? (enabled ? "No sites recorded yet. Browse a few pages, then tap Refresh." : "Recording is off. Turn it on above to start a list.")
        : "No matches."));
      return;
    }
    box.appendChild(h("p", { class: "note" }, `${plural(rows.length, "site")}${q ? " match" : ""}`));
    rows.slice(0, 200).forEach(v => box.appendChild(h("div", { class: "det-visit" },
      h("div", { class: "det-visit-main" },
        h("span", { class: "det-visit-host" }, h("span", { class: "det-lock " + (v.https ? "on" : "off"), title: v.https ? "HTTPS" : "Not encrypted" }, v.https ? "🔒" : "⚠"), v.host),
        h("span", { class: "det-visit-ip" }, (v.ips && v.ips.length ? v.ips.join(", ") : "IP not recorded") + (v.proxied ? " (some visits via proxy)" : "")),
        h("span", { class: "det-visit-meta" }, `${plural(v.count, "visit")} · last ${fmtAgo(v.last)}`)),
      h("button", { type: "button", class: "det-mini", onclick: () => DetectiveReportView.goToPortTest(v.host) }, "Ports"))));
  }

  async function load() {
    try {
      const r = await DetectiveApi.getVisited();
      visitedCache = r.list || [];
      $("detLogToggle").checked = !!r.enabled;
      render();
    } catch (e) {
      clearEl($("detVisitedList")).appendChild(h("p", { class: "note det-warn" }, e.message || String(e)));
    }
  }

  function bind() {
    if ($("detVisitedBox")) $("detVisitedBox").addEventListener("toggle", () => { if ($("detVisitedBox").open) load(); });
    if ($("detLogToggle")) $("detLogToggle").addEventListener("change", async () => {
      const enabled = $("detLogToggle").checked;
      await DetectiveApi.setVisitedEnabled(enabled);
      root.say(enabled ? "Recording visited sites on this device." : "Recording stopped. Your list is kept until you clear it.", "ok", 4);
      render();
    });
    if ($("detVisitedFilter")) $("detVisitedFilter").addEventListener("input", render);
    if ($("detVisitedRefresh")) $("detVisitedRefresh").onclick = load;
    if ($("detVisitedCopy")) $("detVisitedCopy").onclick = () =>
      copyText(visitedCache.map(v => `${v.host}\t${(v.ips || []).join(",")}\t${v.count}\t${new Date(v.last).toISOString()}`).join("\n") || "(empty)", root.say, "List copied.");
    if ($("detVisitedClear")) $("detVisitedClear").onclick = async () => {
      const btn = $("detVisitedClear");
      if (Date.now() - clearArm > 4000) { clearArm = Date.now(); btn.textContent = "Tap again to clear"; setTimeout(() => { btn.textContent = "Clear"; }, 4000); return; }
      clearArm = 0; btn.textContent = "Clear";
      await DetectiveApi.clearVisited();
      visitedCache = []; render(); root.say("Visited list cleared.", "ok", 3);
    };
  }

  const DetectiveVisitedView = { render, load, bind };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveVisitedView;
  else root.DetectiveVisitedView = DetectiveVisitedView;
})(typeof window !== "undefined" ? window : globalThis);
