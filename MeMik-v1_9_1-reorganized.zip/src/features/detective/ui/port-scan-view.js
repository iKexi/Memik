/**
 * popup/components/detective/port-scan-view.js — "Open ports test" panel.
 *
 * The scan itself runs in the background service worker (background/modules/detective/
 * engine.js); this view just starts/stops it and renders whatever state
 * DetectiveApi.watchPortState pushes (via chrome.storage.session, so progress survives
 * the popup closing and reopening). Caches the last state on DetectiveStore so the
 * Simple/Detailed toggle in report-view.js can trigger a re-render here too.
 *
 * Plain script, exposes a single global: `DetectivePortScanView`.
 */
(function (root) {
  "use strict";
  const { $, h, clearEl, plural } = root;
  const PORT_STATUS = DetLabels.PORT_STATUS;

  function toText(s) {
    const L = [`MeMik open ports test for ${s.host}`, s.summary ? s.summary.verdict : "", ""];
    (s.rows || []).forEach(r => L.push(`${String(r.port).padEnd(6)}${r.name.padEnd(34)}${(PORT_STATUS[r.status] || [r.status])[0]}${r.publicListed ? " (public scan)" : ""}`));
    (s.notes || []).forEach(n => L.push("", "Note: " + n));
    return L.join("\n");
  }

  function render(state) {
    DetectiveStore.patch({ ports: state });
    const out = clearEl($("detPortOut"));
    const bar = $("detPortBar");
    const start = $("detPortStart"), stop = $("detPortStop");
    if (!state) { bar.classList.add("hidden"); stop.classList.add("hidden"); start.disabled = false; return; }
    const running = !!state.running;
    bar.classList.toggle("hidden", !running);
    stop.classList.toggle("hidden", !running);
    start.disabled = running;
    if (running) { bar.max = state.total || 1; bar.value = state.done || 0; }

    if (state.error) out.appendChild(h("div", { class: "det-error", role: "alert" }, h("strong", null, "The port test hit a problem."), h("span", null, state.error)));
    if (running) out.appendChild(h("p", { class: "note" }, `Testing ${state.host}: ${state.done || 0} of ${state.total} ports…`));
    (state.notes || []).forEach(n => out.appendChild(h("p", { class: "note det-warn" }, n)));

    const view = DetectiveStore.get().view;
    const rows = state.rows || [];
    const reachable = rows.filter(r => r.status === "open" || r.status === "possibly-open" || r.publicListed);
    const attention = reachable.filter(r => ["critical", "high", "medium"].includes(r.level));
    const expected = reachable.filter(r => !attention.includes(r));

    if (state.summary) {
      out.appendChild(h("div", { class: "det-head tone-" + state.summary.tone },
        h("div", { class: "det-badge " + state.summary.tone, "aria-hidden": "true" }, state.summary.tone === "ok" ? "✓" : String(attention.length || "!")),
        h("div", { class: "det-head-text" },
          h("div", { class: "det-verdict" }, state.summary.verdict),
          h("div", { class: "det-host" }, `${state.host}${state.dns && (state.dns.a[0] || state.dns.aaaa[0]) && (state.dns.a[0] || state.dns.aaaa[0]) !== state.host ? " · " + (state.dns.a[0] || state.dns.aaaa[0]) : ""}`))));
    }

    if (attention.length) {
      out.appendChild(h("div", { class: "det-sec-title" }, "Needs attention"));
      attention.forEach(r => out.appendChild(DetectiveReportView.findingEl({
        level: r.level, title: `Port ${r.port}: ${r.name} is reachable`, why: r.why, fix: r.fix,
        detail: (PORT_STATUS[r.status] ? PORT_STATUS[r.status][0] : r.status) + (r.publicListed ? ". Also listed by a public internet scan." : "") + ". " + (r.note || ""),
        conf: r.conf === "none" ? "review" : (r.conf || "review")
      }, { showFix: true, open: view === "detailed" })));
    }
    if (state.summary && view === "detailed") {
      if (expected.length) {
        out.appendChild(h("div", { class: "det-sec-title" }, "Reachable, as expected"));
        expected.forEach(r => out.appendChild(h("div", { class: "det-portrow" }, h("span", { class: "det-port" }, String(r.port)), h("span", { class: "det-portname" }, r.name), h("span", { class: "det-tag lv-info" }, "Open"))));
      }
      out.appendChild(h("div", { class: "det-sec-title" }, "Every port tested", h("span", { class: "det-sec-count" }, String(rows.length))));
      rows.forEach(r => {
        const s = PORT_STATUS[r.status] || [r.status, "lv-info"];
        out.appendChild(h("div", { class: "det-portrow", title: r.note || "" },
          h("span", { class: "det-port" }, String(r.port)), h("span", { class: "det-portname" }, r.name),
          h("span", { class: "det-tag " + s[1] }, s[0])));
      });
    } else if (state.summary) {
      const closed = rows.filter(r => r.status === "closed").length;
      const other = rows.filter(r => ["filtered", "blocked", "no-web-service"].includes(r.status)).length;
      out.appendChild(h("p", { class: "note" }, `${plural(rows.length, "port")} tested: ${closed} closed${other ? `, ${other} gave no web answer or cannot be tested from a browser` : ""}. Switch to Detailed for every port.`));
    }

    if (state.summary && state.publicDb) {
      const p = state.publicDb;
      let t;
      if (p.skipped) t = p.reason;
      else if (!p.ok) t = p.error;
      else if (p.empty) t = "A public internet scan database has no open ports recorded for this IP.";
      else t = `A public internet scan database lists these open ports for this IP: ${p.ports.join(", ") || "none"}. This can be a few days old.`;
      out.appendChild(h("p", { class: "note" }, t));
      if (p.ok && p.vulns && p.vulns.length && view === "detailed") out.appendChild(h("p", { class: "note" }, `Known vulnerabilities that match the software seen on this IP (not confirmed): ${p.vulns.slice(0, 8).join(", ")}${p.vulns.length > 8 ? ` and ${p.vulns.length - 8} more` : ""}.`));
    }
    if (state.summary) {
      out.appendChild(h("p", { class: "note" }, "A browser can only fully test web ports. Other ports are marked possible or untestable instead of guessed. For a complete audit run nmap from a computer you control."));
      out.appendChild(h("div", { class: "btns compact" },
        h("button", { type: "button", class: "btn ghost small", onclick: () => copyText(toText(state), root.say, "Port results copied.") }, "Copy results")));
    }
  }

  async function load() {
    try { render(await DetectiveApi.getPortScanState()); } catch (_) {}
  }

  function bind() {
    DetectiveApi.watchPortState(state => render(state));

    if ($("detPortBox")) $("detPortBox").addEventListener("toggle", async () => {
      if (!$("detPortBox").open) return;
      if (!$("detPortTarget").value) {
        try { const t = await DetectiveApi.activeHttpTab(); $("detPortTarget").value = new URL(t.url).hostname; } catch (_) {}
      }
      load();
    });
    if ($("detPortPreset")) $("detPortPreset").addEventListener("change", () => $("detPortCustomWrap").classList.toggle("hidden", $("detPortPreset").value !== "custom"));
    if ($("detPortStart")) $("detPortStart").onclick = async () => {
      const out = $("detPortOut");
      try {
        const tab = await DetectiveApi.activeHttpTab().catch(() => null);
        await DetectiveApi.startPortScan({
          target: $("detPortTarget").value, preset: $("detPortPreset").value, custom: $("detPortCustom").value,
          confirmOwner: $("detPortOwn").checked, tabId: tab ? tab.id : null
        });
      } catch (e) {
        clearEl(out).appendChild(h("div", { class: "det-error", role: "alert" }, h("strong", null, "The test did not start."), h("span", null, e.message || String(e))));
      }
    };
    if ($("detPortStop")) $("detPortStop").onclick = () => DetectiveApi.cancelPortScan();
  }

  const DetectivePortScanView = { render, load, bind, toText };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectivePortScanView;
  else root.DetectivePortScanView = DetectivePortScanView;
})(typeof window !== "undefined" ? window : globalThis);
