/**
 * popup/components/detective/site-info-view.js — "This site & its IP" panel.
 *
 * Fetches via DetectiveApi.fetchSiteInfo and renders into #detSiteOut. Owns its own
 * loading/error states (kept close to the fetch, as the rest of Detective's views do)
 * rather than threading that through the store — it's view-local, nothing else needs it.
 *
 * Plain script, exposes a single global: `DetectiveSiteInfoView`.
 */
(function (root) {
  "use strict";
  const { $, h, clearEl, plural } = root;

  function kv(label, value, extra) {
    if (value == null || value === "") return null;
    return h("div", { class: "det-kv" }, h("span", { class: "det-kv-k" }, label), h("span", { class: "det-kv-v" }, value), extra || null);
  }

  function renderResult(out, r) {
    clearEl(out);
    const ips = r.dns ? r.dns.a.concat(r.dns.aaaa) : [];
    const card = h("div", { class: "det-card2" },
      kv("Website", r.host),
      kv("Connection", r.https ? "Encrypted (HTTPS)" : "Not encrypted (HTTP)"),
      kv("IP your browser used", r.connectedIp || "Not recorded. Reload the page, then look up again.",
        r.connectedIp ? h("button", { type: "button", class: "det-mini", onclick: () => copyText(r.connectedIp, root.say, "IP copied.") }, "Copy") : null),
      r.proxied ? h("p", { class: "note det-warn" }, "A proxy is on, so the IP above may be the proxy's address, not the site's. The DNS addresses below are the site's real ones.") : null,
      kv("DNS addresses", ips.length ? ips.join(", ") : (r.dnsError || "None found")),
      r.dns && r.dns.cname.length ? kv("Alias (CNAME)", r.dns.cname.join(", ")) : null,
      kv("Served through", r.cdn ? r.cdn + " (shared network, not your own server)" : ""),
      kv("Server software", r.server),
      r.dns && r.dns.resolver ? h("p", { class: "note" }, `DNS answered by ${r.dns.resolver}. The site name is sent to that resolver only when you tap Look up.`) : null,
      h("div", { class: "btns compact" },
        h("button", { type: "button", class: "btn ghost small", onclick: () => DetectiveReportView.goToPortTest(r.host) }, "Test ports")));
    out.appendChild(card);

    const c = r.connections || [];
    const third = c.filter(x => x.thirdParty).length;
    const box = h("details", { class: "det-more", open: c.length <= 12 }, h("summary", null, `${plural(c.length, "server")} contacted (${third} outside this site)`));
    if (r.connectionsNote) box.appendChild(h("p", { class: "note" }, r.connectionsNote));
    c.forEach(x => box.appendChild(h("div", { class: "det-conn" },
      h("span", { class: "det-conn-host" }, x.host, x.thirdParty ? h("span", { class: "det-tag small" }, "other site") : null),
      h("span", { class: "det-conn-ip" }, x.ip || "no IP recorded"),
      h("span", { class: "det-conn-n" }, plural(x.count, "request")))));
    out.appendChild(box);
  }

  async function run() {
    const out = $("detSiteOut"), btn = $("detSiteBtn");
    clearEl(out).appendChild(h("div", { class: "det-loading" }, h("span", { class: "det-spinner", "aria-hidden": "true" }), "Looking up…"));
    btn.disabled = true;
    try {
      const tab = await DetectiveApi.activeHttpTab();
      const r = await DetectiveApi.fetchSiteInfo(tab.id);
      renderResult(out, r);
    } catch (e) {
      clearEl(out).appendChild(h("div", { class: "det-error", role: "alert" }, h("strong", null, "Lookup failed."), h("span", null, e.message || String(e))));
    } finally { btn.disabled = false; }
  }

  function bind() { if ($("detSiteBtn")) $("detSiteBtn").onclick = run; }

  const DetectiveSiteInfoView = { run, bind };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveSiteInfoView;
  else root.DetectiveSiteInfoView = DetectiveSiteInfoView;
})(typeof window !== "undefined" ? window : globalThis);
