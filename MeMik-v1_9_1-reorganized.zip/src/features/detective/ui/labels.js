/**
 * popup/components/detective/labels.js — human-readable labels for engine codes.
 *
 * The background engine (background/modules/detective/engine.js) returns machine
 * codes (level: "high", conf: "likely", mode: "xss", ...); these maps turn them into
 * the words shown in the UI. Kept separate from the view files since more than one of
 * them needs the same vocabulary.
 *
 * Plain script, exposes a single global: `DetLabels`.
 */
(function (root) {
  "use strict";

  const LEVEL = { critical: "Critical", high: "High", medium: "Medium", low: "Low", info: "Note", pass: "Passed" };
  const CONF = { confirmed: "Confirmed", likely: "Likely", review: "Needs your review" };
  const CONF_HELP = {
    confirmed: "The scan saw this directly.",
    likely: "Strong sign, but a scan from outside cannot be 100% sure.",
    review: "A pattern worth a human look. It may be fine."
  };
  const CAT = {
    https: "Secure connection", mixed: "Mixed content", headers: "Security headers", csp: "Content Security Policy",
    cookies: "Cookies", xss: "Script injection (XSS)", forms: "Forms", links: "Links & frames", redirect: "Redirects",
    supply: "Third-party code", inputs: "Data inputs", leaks: "Leaks & errors", tech: "Technology"
  };
  const MODE = {
    all: "All checks", info: "Tech fingerprint", links: "Links, forms & third-party code", headers: "Security headers",
    mixed: "Mixed content", cookie: "Cookies", csp: "Content Security Policy", xss: "Script injection",
    sql: "Database errors & inputs", redirect: "Redirects"
  };
  const SOURCE = {
    browser: "the response your browser received", head: "a separate request to this address",
    origin: "the site's home page", none: "no server response"
  };
  /** status -> [label, CSS level class] for the open-ports test. */
  const PORT_STATUS = {
    open: ["Open", "lv-high"], "possibly-open": ["Possibly open", "lv-medium"], closed: ["Closed", "lv-pass"],
    filtered: ["No reply", "lv-info"], "no-web-service": ["No web service", "lv-info"],
    blocked: ["Can't test", "lv-info"], "not-tested": ["Seen by public scan", "lv-medium"]
  };

  const DetLabels = { LEVEL, CONF, CONF_HELP, CAT, MODE, SOURCE, PORT_STATUS };
  if (typeof module !== "undefined" && module.exports) module.exports = DetLabels;
  else root.DetLabels = DetLabels;
})(typeof window !== "undefined" ? window : globalThis);
