/**
 * popup/components/detective/report-view.js — renders a Detective scan report.
 *
 * Pure-ish rendering: `render(report)` takes the engine's report object (see
 * background/modules/detective/engine.js buildReport()) and draws it into #auditResults
 * and #detScanStatus. The only state it touches is DetectiveStore's `view` (Simple vs
 * Detailed) and caching the last `report`, both through the store, not local variables,
 * so other components (the port-scan view) can react to the same view toggle.
 *
 * Plain script, exposes a single global: `DetectiveReportView`.
 */
(function (root) {
  "use strict";
  const { $, h, clearEl, plural } = root;
  const L = DetLabels;

  function toneFor(report) {
    const c = report.counts || {};
    if (c.critical || c.high) return "bad";
    if (c.medium) return "warn";
    return "ok";
  }

  function scoreRing(score, grade, tone) {
    const NS = "http://www.w3.org/2000/svg", R = 34, C = 2 * Math.PI * R;
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 80 80"); svg.setAttribute("class", "det-ring " + tone); svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", `Safety score ${score} out of 100, grade ${grade}`);
    const mk = (cls, extra) => {
      const c = document.createElementNS(NS, "circle");
      c.setAttribute("cx", "40"); c.setAttribute("cy", "40"); c.setAttribute("r", String(R)); c.setAttribute("class", cls);
      if (extra) for (const k in extra) c.setAttribute(k, extra[k]);
      return c;
    };
    svg.appendChild(mk("det-ring-track"));
    svg.appendChild(mk("det-ring-fill", { "stroke-dasharray": `${(C * score) / 100} ${C}`, transform: "rotate(-90 40 40)" }));
    const t1 = document.createElementNS(NS, "text"); t1.setAttribute("x", "40"); t1.setAttribute("y", "42"); t1.setAttribute("class", "det-ring-num"); t1.textContent = String(score);
    const t2 = document.createElementNS(NS, "text"); t2.setAttribute("x", "40"); t2.setAttribute("y", "56"); t2.setAttribute("class", "det-ring-grade"); t2.textContent = "Grade " + grade;
    svg.appendChild(t1); svg.appendChild(t2);
    return svg;
  }

  /** One finding as a collapsible row. `opts.showFix` puts the fix in the summary subtitle. */
  function findingEl(f, opts) {
    opts = opts || {};
    const d = h("details", { class: `det-find lv-${f.level}` });
    if (opts.open) d.open = true;
    d.appendChild(h("summary", null,
      h("span", { class: "det-dot", "aria-hidden": "true" }),
      h("span", { class: "det-find-main" },
        h("span", { class: "det-find-title" }, f.title),
        opts.showFix && f.fix ? h("span", { class: "det-find-sub" }, f.fix) : null),
      h("span", { class: "det-tag" }, L.LEVEL[f.level] || f.level)));
    const row = (label, text, mono) => text ? h("div", { class: "det-row" }, h("span", { class: "det-row-label" }, label), h("span", { class: mono ? "det-row-val mono" : "det-row-val" }, text)) : null;
    const body = h("div", { class: "det-find-body" },
      row("Why it matters", f.why),
      opts.showFix ? null : row("How to fix", f.fix),
      row("Evidence", f.detail, true),
      f.level !== "pass" && f.conf ? h("div", { class: "det-row" }, h("span", { class: "det-row-label" }, "Confidence"), h("span", { class: "det-row-val", title: L.CONF_HELP[f.conf] || "" }, `${L.CONF[f.conf] || f.conf}. ${L.CONF_HELP[f.conf] || ""}`)) : null,
      /^https:\/\//i.test(f.ref || "") ? h("a", { class: "det-ref", href: f.ref, target: "_blank", rel: "noopener noreferrer" }, "Learn more") : null);
    d.appendChild(body);
    return d;
  }

  /** The report as plain text, for the "Copy report" button. */
  function toText(r) {
    const L2 = [];
    L2.push(`MeMik Detective report`);
    L2.push(`Site: ${r.host}  (${r.url})`);
    L2.push(`Scanned: ${new Date(r.scannedAt).toLocaleString()}  ·  Scope: ${L.MODE[r.mode] || r.mode}`);
    if (r.mode === "all") L2.push(`Score: ${r.score}/100 (grade ${r.grade})`);
    if (r.ip) L2.push(`Server IP: ${r.ip}${r.cdn ? "  (" + r.cdn + ")" : ""}`);
    L2.push(r.verdict, "");
    const groups = {};
    r.findings.filter(f => f.level !== "pass").forEach(f => (groups[f.cat] = groups[f.cat] || []).push(f));
    Object.keys(groups).forEach(cat => {
      L2.push(`== ${L.CAT[cat] || cat} ==`);
      groups[cat].forEach(f => {
        L2.push(`[${L.LEVEL[f.level]}] ${f.title}  (${L.CONF[f.conf] || f.conf})`);
        if (f.why) L2.push(`  Why: ${f.why}`);
        if (f.fix) L2.push(`  Fix: ${f.fix}`);
        if (f.detail) L2.push(`  Evidence: ${f.detail}`);
      });
      L2.push("");
    });
    const passed = r.findings.filter(f => f.level === "pass");
    if (passed.length) L2.push(`Passed (${passed.length}): ` + passed.map(f => f.title).join("; "), "");
    if (r.tech && r.tech.length) L2.push("Technology: " + r.tech.map(t => t.name + (t.version ? " " + t.version : "")).join(", "), "");
    (r.notes || []).forEach(n => L2.push("Note: " + n));
    L2.push(r.scope);
    return L2.join("\n");
  }

  function goToPortTest(host) {
    $("detPortTarget").value = host;
    $("detPortBox").open = true;
    $("detPortBox").scrollIntoView({ block: "start", behavior: "smooth" });
  }

  /** Render a report into #auditResults / #detScanStatus. Caches it on the store for the view toggle. */
  function render(r) {
    const el = clearEl($("auditResults"));
    const st = $("detScanStatus");
    if (!r || !Array.isArray(r.findings)) {
      if (el) el.appendChild(h("p", { class: "note" }, "No results."));
      if (st) { st.textContent = "No results."; st.className = "note"; }
      return;
    }
    DetectiveStore.patch({ report: r });
    const view = DetectiveStore.get().view;
    const issues = r.findings.filter(f => f.level !== "pass" && f.level !== "info");
    const notes = r.findings.filter(f => f.level === "info");
    const passes = r.findings.filter(f => f.level === "pass");
    const tone = toneFor(r);
    const full = r.mode === "all";

    if (st) {
      st.textContent = `${L.MODE[r.mode] || "Scan"} · ${r.host} · ${new Date(r.scannedAt).toLocaleTimeString()}`;
      st.className = "note det-status-" + tone;
    }

    el.appendChild(h("div", { class: "det-head tone-" + tone },
      full ? scoreRing(r.score, r.grade, tone) : h("div", { class: "det-badge " + tone, "aria-hidden": "true" }, issues.length ? String(issues.length) : "✓"),
      h("div", { class: "det-head-text" },
        h("div", { class: "det-verdict" }, issues.length || full ? r.verdict : (r.mode === "info" ? "Here is what this page is built with." : "All clear. Nothing to fix in this check.")),
        h("div", { class: "det-host" }, r.host + (r.ip && r.ip !== r.host ? " · " + r.ip : "")))));

    const chips = h("div", { class: "det-chips" });
    ["critical", "high", "medium", "low"].forEach(k => {
      const n = (r.counts || {})[k];
      if (n) chips.appendChild(h("span", { class: `det-chip lv-${k}` }, h("span", { class: "det-dot", "aria-hidden": "true" }), `${n} ${L.LEVEL[k].toLowerCase()}`));
    });
    chips.appendChild(h("span", { class: "det-chip lv-pass" }, h("span", { class: "det-dot", "aria-hidden": "true" }), `${passes.length} passed`));
    el.appendChild(chips);

    const seg = h("div", { class: "theme-segment det-seg2 det-viewseg", role: "radiogroup", "aria-label": "Result detail" });
    [["simple", "Simple"], ["detailed", "Detailed"]].forEach(([k, label]) => {
      seg.appendChild(h("button", {
        type: "button", class: "theme-seg" + (view === k ? " active" : ""), role: "radio", "aria-checked": String(view === k),
        onclick: () => DetectiveStore.setDisplay({ view: k })
      }, label));
    });
    el.appendChild(seg);

    const body = h("div", { class: "det-body" });
    if (view === "simple") {
      if (!issues.length) body.appendChild(h("p", { class: "det-allgood" }, r.mode === "info" ? "Switch to Detailed to see the technology list." : "No problems found by these checks."));
      const top = issues.filter(f => (r.top || []).includes(f.id));
      const rest = issues.filter(f => !(r.top || []).includes(f.id));
      if (top.length) {
        body.appendChild(h("div", { class: "det-sec-title" }, "Fix these first"));
        top.forEach(f => body.appendChild(findingEl(f, { showFix: true })));
      }
      if (rest.length) {
        const box = h("details", { class: "det-more" }, h("summary", null, `${plural(rest.length, "more thing")} to improve`));
        rest.forEach(f => box.appendChild(findingEl(f, { showFix: true })));
        body.appendChild(box);
      }
      if (passes.length) {
        const box = h("details", { class: "det-more det-passed" }, h("summary", null, `${plural(passes.length, "check")} passed`));
        box.appendChild(h("ul", { class: "det-passlist" }, passes.map(f => h("li", null, f.title))));
        body.appendChild(box);
      }
      if (notes.length) body.appendChild(h("p", { class: "note det-hint" }, `${plural(notes.length, "extra note")} in the Detailed view.`));
    } else {
      const order = Object.keys(L.CAT);
      const cats = Array.from(new Set(r.findings.map(f => f.cat))).sort((a, b) => order.indexOf(a) - order.indexOf(b));
      cats.forEach(cat => {
        const items = r.findings.filter(f => f.cat === cat && f.level !== "pass");
        const ok = r.findings.filter(f => f.cat === cat && f.level === "pass");
        if (!items.length && !ok.length) return;
        const group = h("section", { class: "det-group2" },
          h("div", { class: "det-sec-title" }, L.CAT[cat] || cat, h("span", { class: "det-sec-count" }, items.length ? plural(items.length, "finding") : "all clear")));
        items.forEach(f => group.appendChild(findingEl(f, { open: f.level !== "info" })));
        ok.forEach(f => group.appendChild(findingEl(f, {})));
        body.appendChild(group);
      });
      if (r.tech && r.tech.length) {
        body.appendChild(h("section", { class: "det-group2" },
          h("div", { class: "det-sec-title" }, "Technology detected", h("span", { class: "det-sec-count" }, String(r.tech.length))),
          h("div", { class: "det-techs" }, r.tech.map(t => h("span", { class: "det-techchip", title: "Found via " + t.how }, t.name + (t.version ? " " + t.version : ""))))));
      }
      const fx = r.facts || {};
      if (full) body.appendChild(h("section", { class: "det-group2" },
        h("div", { class: "det-sec-title" }, "About this page"),
        h("div", { class: "det-facts" },
          [["Forms", fx.forms], ["Scripts (own)", fx.scriptsInline], ["Scripts (external)", fx.scriptsExternal], ["Other sites used", (fx.thirdPartyHosts || []).length], ["Links", fx.links], ["Frames", fx.iframes]]
            .map(([k, v]) => h("div", { class: "det-fact" }, h("span", { class: "det-fact-n" }, String(v || 0)), h("span", { class: "det-fact-l" }, k))))));
    }
    el.appendChild(body);

    const foot = h("div", { class: "det-foot" });
    (r.notes || []).forEach(n => foot.appendChild(h("p", { class: "note" }, n)));
    if (r.errors && r.errors.length) foot.appendChild(h("p", { class: "note" }, `${plural(r.errors.length, "check")} could not run on this page (${r.errors.map(e => e.check).join(", ")}). The rest completed normally.`));
    foot.appendChild(h("p", { class: "note" }, `Headers read from ${L.SOURCE[r.headerSource] || r.headerSource}. ${r.scope}`));
    foot.appendChild(h("div", { class: "btns compact" },
      h("button", { type: "button", class: "btn ghost small", onclick: () => copyText(toText(r), root.say, "Report copied.") }, "Copy report"),
      h("button", { type: "button", class: "btn ghost small", onclick: () => downloadText(`memik-${r.host}-${new Date(r.scannedAt).toISOString().slice(0, 10)}.json`, JSON.stringify(r, null, 2), "application/json") }, "Download JSON"),
      full && r.ip ? h("button", { type: "button", class: "btn ghost small", onclick: () => goToPortTest(r.host) }, "Test ports") : null));
    el.appendChild(foot);
  }

  const DetectiveReportView = { render, toText, findingEl, goToPortTest };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveReportView;
  else root.DetectiveReportView = DetectiveReportView;
})(typeof window !== "undefined" ? window : globalThis);
