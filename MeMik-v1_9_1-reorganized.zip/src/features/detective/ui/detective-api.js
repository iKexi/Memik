/**
 * popup/services/detective-api.js — Detective's data layer.
 *
 * Every chrome.runtime/chrome.tabs/chrome.storage call Detective's popup UI makes goes
 * through here, using the MSG constants from shared/messages.js rather than literal
 * strings. Nothing in here touches the DOM; it returns plain data (or throws), which
 * the view components in popup/components/detective/ turn into markup. This is the
 * seam you'd replace with a mock in a unit test, or point at a different transport.
 *
 * Plain script, exposes a single global: `DetectiveApi`.
 */
(function (root) {
  "use strict";

  /** The active tab, or throws if it isn't a normal http(s) page Detective can scan. */
  async function activeHttpTab() {
    const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (!tab?.id || !/^https?:/i.test(tab.url || "")) {
      throw new Error("Open a normal http(s) page first. Browser pages cannot be scanned.");
    }
    return tab;
  }

  /** Run a scan (mode: "all" or one category) against a tab. Throws on failure. */
  async function runScan(mode, tabId) {
    const reply = await chrome.runtime.sendMessage({ type: MSG.DETECTIVE_RUN, mode: mode || "all", tabId });
    if (!reply?.ok) throw new Error(reply?.error || "Scan failed.");
    return reply;
  }

  /** This page's IP, DNS, CDN and every server it contacted. Throws on failure. */
  async function fetchSiteInfo(tabId) {
    const r = await chrome.runtime.sendMessage({ type: MSG.DETECTIVE_SITE_INFO, tabId });
    if (!r?.ok) throw new Error(r?.error || "Lookup failed.");
    return r;
  }

  /** The visited-sites log and whether recording is on. Throws on failure. */
  async function getVisited() {
    const r = await chrome.runtime.sendMessage({ type: MSG.DETECTIVE_VISITED_GET });
    if (!r?.ok) throw new Error(r?.error || "Could not load the list.");
    return r;
  }

  async function setVisitedEnabled(enabled) {
    return chrome.runtime.sendMessage({ type: MSG.DETECTIVE_VISITED_SET, enabled: !!enabled });
  }

  async function clearVisited() {
    return chrome.runtime.sendMessage({ type: MSG.DETECTIVE_VISITED_CLEAR });
  }

  /** Start a consent-gated port test. Does not wait for it to finish; see watchPortState. */
  async function startPortScan({ target, preset, custom, confirmOwner, tabId }) {
    const r = await chrome.runtime.sendMessage({
      type: MSG.DETECTIVE_PORT_START, target, preset, custom, confirmOwner: !!confirmOwner, tabId
    });
    if (!r?.ok) throw new Error(r?.error || "Could not start the test.");
    return r;
  }

  async function cancelPortScan() {
    return chrome.runtime.sendMessage({ type: MSG.DETECTIVE_PORT_CANCEL });
  }

  /** The current (possibly in-progress) port-scan state, or null if none has run. */
  async function getPortScanState() {
    const key = CONFIG.detective.storageKeys.portScanState;
    const { [key]: state } = await chrome.storage.session.get(key);
    return state || null;
  }

  /**
   * Call `onChange(state)` whenever the port-scan state updates (polling-free: this
   * is pushed by the background service worker via chrome.storage.onChanged).
   * Returns an unsubscribe function.
   */
  function watchPortState(onChange) {
    const key = CONFIG.detective.storageKeys.portScanState;
    const listener = (changes, area) => { if (area === "session" && changes[key]) onChange(changes[key].newValue || null); };
    try { chrome.storage.onChanged.addListener(listener); } catch (e) { if (typeof Logger !== "undefined") Logger.warn("detective-api", "could not watch port state", {}, e); }
    return () => { try { chrome.storage.onChanged.removeListener(listener); } catch (_) {} };
  }

  /** Resolve a hostname via DNS-over-HTTPS. Not currently wired to a button, kept for completeness. */
  async function lookupHost(host) {
    const r = await chrome.runtime.sendMessage({ type: MSG.DETECTIVE_LOOKUP, host });
    if (!r?.ok) throw new Error(r?.error || "Lookup failed.");
    return r.dns;
  }

  const DetectiveApi = {
    activeHttpTab, runScan, fetchSiteInfo, getVisited, setVisitedEnabled, clearVisited,
    startPortScan, cancelPortScan, getPortScanState, watchPortState, lookupHost
  };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveApi;
  else root.DetectiveApi = DetectiveApi;
})(typeof window !== "undefined" ? window : globalThis);
