/**
 * popup/components/detective/appearance-controls.js — the "Result display" section:
 * colour palette, spacing, and the link out to the shared Appearance page for
 * theme/accent (which Detective does not duplicate; see popup/popup.html).
 *
 * Plain script, exposes a single global: `DetectiveAppearanceControls`.
 */
(function (root) {
  "use strict";
  const doc = document;

  function apply() {
    const { palette, density } = DetectiveStore.get();
    doc.documentElement.setAttribute("data-det-palette", palette);
    doc.documentElement.setAttribute("data-det-density", density);
  }

  function sync() {
    const { palette, density } = DetectiveStore.get();
    doc.querySelectorAll("[data-det-palette]").forEach(b => {
      const on = b.getAttribute("data-det-palette") === palette;
      b.setAttribute("aria-checked", String(on)); b.classList.toggle("active", on);
    });
    doc.querySelectorAll("[data-det-density]").forEach(b => {
      const on = b.getAttribute("data-det-density") === density;
      b.setAttribute("aria-checked", String(on)); b.classList.toggle("active", on);
    });
  }

  function bind() {
    doc.querySelectorAll("[data-det-palette]").forEach(b => b.addEventListener("click", () => {
      DetectiveStore.setDisplay({ palette: b.getAttribute("data-det-palette") });
    }));
    doc.querySelectorAll("[data-det-density]").forEach(b => b.addEventListener("click", () => {
      DetectiveStore.setDisplay({ density: b.getAttribute("data-det-density") });
    }));
    const more = doc.getElementById("detMoreTheme");
    if (more) more.addEventListener("click", () => root.openSheet(true, "theme"));
    DetectiveStore.subscribe((state, prev) => {
      if (state.palette !== prev.palette || state.density !== prev.density) { apply(); sync(); }
    });
  }

  async function init() {
    await DetectiveStore.loadPrefs();
    apply();
    sync();
  }

  const DetectiveAppearanceControls = { init, apply, sync, bind };
  if (typeof module !== "undefined" && module.exports) module.exports = DetectiveAppearanceControls;
  else root.DetectiveAppearanceControls = DetectiveAppearanceControls;
})(typeof window !== "undefined" ? window : globalThis);
