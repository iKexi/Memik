/**
 * MeMik Detective engine (background).
 *
 * - Reads the real HTTP response headers of the page (webRequest, with a HEAD fallback).
 * - Analyses security headers, CSP and Set-Cookie flags.
 * - Merges those findings with the page scan from content/modules/detective/page-scanner.js.
 * - Scores the result and writes plain-language advice.
 * - Tracks which IP each site / sub-resource host connected to.
 * - Resolves DNS (DNS-over-HTTPS), looks up public port data (Shodan InternetDB)
 *   and runs an opt-in live port test for sites the user owns.
 *
 * Loaded with importScripts() in the service worker (see background/background.js), after
 * shared/logger.js, shared/errors.js, shared/api-router.js, shared/messages.js, shared/config.js
 * and shared/net.js — this file uses all six. Also loads standalone in Node for tests.
 */
(function (root) {
  "use strict";

  const VERSION = "2.0";

  // shared/net.js and shared/config.js: ambient globals on `root` when loaded via
  // importScripts() in the service worker (the real runtime); required explicitly when
  // this file is loaded standalone under Node (the test suite).
  const isNode = typeof module !== "undefined" && module.exports;
  const { withTimeout, fetchTimeout } = isNode ? require("../../../shared/net.js") : root;
  const CONFIG = isNode ? require("../../../shared/config.js") : root.CONFIG;

  /* ------------------------------------------------------------------ *
   *  Finding model, scoring
   * ------------------------------------------------------------------ */
  const LEVELS = ["critical", "high", "medium", "low", "info", "pass"];
  const LEVEL_W = { critical: 20, high: 12, medium: 6, low: 2, info: 0, pass: 0 };
  const CONF_M = { confirmed: 1, likely: 0.7, review: 0.35 };
  const CAT_CAP = 40;

  const CAT_LABEL = {
    https: "Secure connection", mixed: "Mixed content", headers: "Security headers",
    csp: "Content Security Policy", cookies: "Cookies", xss: "Script injection (XSS)",
    forms: "Forms", links: "Links & frames", redirect: "Redirects", supply: "Third-party code",
    inputs: "Data inputs", leaks: "Leaks & errors", tech: "Technology"
  };

  const MODE_CATS = {
    all: null,
    info: ["tech"],
    links: ["links", "forms", "redirect", "supply"],
    headers: ["https", "headers"],
    mixed: ["mixed"],
    cookie: ["cookies"],
    csp: ["csp"],
    xss: ["xss"],
    sql: ["inputs", "leaks"],
    redirect: ["redirect"]
  };

  const MDN = "https://developer.mozilla.org/en-US/docs/Web/";

  function mk(cat, id, level, conf, title, why, fix, detail, ref) {
    return { cat, id, level, conf: conf || "confirmed", title, why: why || "", fix: fix || "", detail: detail || "", ref: ref || "" };
  }

  function weightOf(f) {
    return (LEVEL_W[f.level] || 0) * (CONF_M[f.conf] || 1);
  }

  function scoreFindings(findings) {
    const perCat = {};
    for (const f of findings) {
      const w = weightOf(f);
      if (w > 0) perCat[f.cat] = (perCat[f.cat] || 0) + w;
    }
    let lost = 0;
    for (const k of Object.keys(perCat)) lost += Math.min(CAT_CAP, perCat[k]);
    const score = Math.max(0, Math.round(100 - lost));
    const grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 65 ? "C" : score >= 50 ? "D" : "F";
    const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0, pass: 0 };
    for (const f of findings) if (counts[f.level] != null) counts[f.level]++;
    return { score, grade, counts };
  }

  function verdictFor(counts, scope) {
    const serious = counts.critical + counts.high;
    const what = scope === "all" ? "this page" : "these checks";
    if (counts.critical) return `Needs attention now. ${counts.critical + counts.high} serious problem${counts.critical + counts.high > 1 ? "s" : ""} found on ${what}.`;
    if (serious) return `Needs attention. ${serious} important problem${serious > 1 ? "s" : ""} found on ${what}.`;
    if (counts.medium) return `Mostly good. ${counts.medium} thing${counts.medium > 1 ? "s" : ""} worth fixing.`;
    if (counts.low) return `Good. Only minor improvements left.`;
    return `Excellent. These checks found nothing to fix.`;
  }

  function topFixes(findings, n) {
    return findings
      .filter(f => weightOf(f) > 0)
      .sort((a, b) => weightOf(b) - weightOf(a))
      .slice(0, n || 3);
  }

  const LEVEL_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4, pass: 5 };
  function sortFindings(list) {
    return list.slice().sort((a, b) =>
      (LEVEL_ORDER[a.level] - LEVEL_ORDER[b.level]) || ((CONF_M[b.conf] || 0) - (CONF_M[a.conf] || 0)));
  }

  /* ------------------------------------------------------------------ *
   *  Header normalising
   * ------------------------------------------------------------------ */
  function normHeaders(list) {
    const map = {};
    const setCookies = [];
    for (const h of list || []) {
      if (!h || !h.name) continue;
      const k = String(h.name).toLowerCase();
      const v = String(h.value == null ? "" : h.value);
      if (k === "set-cookie") { setCookies.push(v); continue; }
      map[k] = map[k] ? map[k] + ", " + v : v;
    }
    return { map, setCookies };
  }

  /* ------------------------------------------------------------------ *
   *  CSP
   * ------------------------------------------------------------------ */
  function parseCsp(str) {
    const d = {};
    String(str || "").split(";").forEach(part => {
      const p = part.trim();
      if (!p) return;
      const bits = p.split(/\s+/);
      const k = bits.shift().toLowerCase();
      if (!(k in d)) d[k] = bits;
    });
    return d;
  }

  function analyzeCsp(enforced, reportOnly, meta) {
    const out = [];
    const ref = MDN + "HTTP/Headers/Content-Security-Policy";
    const policy = enforced || meta || "";
    if (!policy) {
      if (reportOnly) {
        out.push(mk("csp", "csp-report-only", "medium", "confirmed",
          "Content Security Policy is only in report mode",
          "A report-only policy logs problems but does not block anything, so it gives no protection yet.",
          "When the reports look clean, switch Content-Security-Policy-Report-Only to Content-Security-Policy.",
          "Report-only policy: " + reportOnly.slice(0, 300), ref));
      } else {
        out.push(mk("csp", "csp-missing", "medium", "confirmed",
          "No Content Security Policy",
          "A CSP limits which scripts can run. Without one, any script injected into the page runs freely.",
          "Send a Content-Security-Policy header. Start with: default-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'",
          "No Content-Security-Policy header or meta tag was found.", ref));
      }
      return out;
    }

    const d = parseCsp(policy);
    const source = enforced ? "header" : "meta tag";
    const scriptSrc = d["script-src"] || d["script-src-elem"] || d["default-src"];
    const issues = [];

    if (!scriptSrc) {
      out.push(mk("csp", "csp-no-script-policy", "medium", "confirmed",
        "CSP does not restrict scripts",
        "The policy has no script-src or default-src, so scripts can load from anywhere.",
        "Add a script-src (or default-src) directive, for example script-src 'self'.",
        "Directives present: " + Object.keys(d).join(", "), ref));
    } else {
      const lower = scriptSrc.map(s => s.toLowerCase());
      const hasNonceOrHash = lower.some(s => /^'(nonce-|sha(256|384|512)-)/.test(s));
      const strictDynamic = lower.includes("'strict-dynamic'");
      if (lower.includes("'unsafe-inline'") && !hasNonceOrHash) {
        issues.push(true);
        out.push(mk("csp", "csp-unsafe-inline", "medium", "confirmed",
          "CSP allows inline scripts",
          "'unsafe-inline' lets injected <script> tags and onclick= handlers run, which removes most of the protection.",
          "Remove 'unsafe-inline' and use nonces or hashes for the inline scripts you need.",
          "script-src: " + scriptSrc.join(" "), ref));
      }
      if (lower.includes("'unsafe-eval'")) {
        issues.push(true);
        out.push(mk("csp", "csp-unsafe-eval", "low", "confirmed",
          "CSP allows eval()",
          "'unsafe-eval' lets text be turned into code, which makes some injection attacks easier.",
          "Remove 'unsafe-eval' and avoid eval(), new Function() and string timers in your code.",
          "script-src: " + scriptSrc.join(" "), ref));
      }
      if (!strictDynamic && lower.some(s => s === "*" || s === "http:" || s === "https:" || s === "data:")) {
        issues.push(true);
        out.push(mk("csp", "csp-wildcard", "medium", "confirmed",
          "CSP allows scripts from almost anywhere",
          "A wildcard, https: or data: source in script-src lets an attacker load code from any site they control.",
          "List the exact hosts you need, or use nonces with 'strict-dynamic'.",
          "script-src: " + scriptSrc.join(" "), ref));
      }

      // Pentesting Case 10: CSP bypass domains in script-src
      const BYPASS_DOMAINS = ["pastebin.com", "hastebin.com", "raw.githubusercontent.com", "gist.github.com", "gist.githubusercontent.com", "toptal.com"];
      const matchedBypass = [];
      lower.forEach(s => {
        const cleanHost = s.replace(/^https?:\/\//i, "").replace(/\/.*$/, "").toLowerCase();
        if (BYPASS_DOMAINS.some(b => cleanHost === b || cleanHost.endsWith("." + b))) {
          matchedBypass.push(s);
        }
      });
      if (matchedBypass.length) {
        issues.push(true);
        out.push(mk("csp", "csp-bypass-hosts", "high", "confirmed",
          "CSP allows scripts from open paste / bypass domains",
          "The script-src directive permits scripts from open paste or user-upload domains (" + matchedBypass.join(", ") + "). Attackers can host arbitrary JavaScript there to bypass the Content Security Policy.",
          "Remove open paste sites from script-src. Use nonces or hashes with 'strict-dynamic' instead of broad host allowlists.",
          "script-src bypass hosts: " + matchedBypass.join(", "), ref));
      }
    }

    const objectSrc = d["object-src"] || d["default-src"];
    if (!objectSrc || !objectSrc.map(s => s.toLowerCase()).includes("'none'")) {
      issues.push(true);
      out.push(mk("csp", "csp-object", "low", "confirmed",
        "CSP does not block plugins",
        "Old plugin content (<object>, <embed>) is a known way around script rules.",
        "Add object-src 'none'.", "object-src: " + (objectSrc ? objectSrc.join(" ") : "(not set)"), ref));
    }
    if (!d["base-uri"] && enforced) {
      issues.push(true);
      out.push(mk("csp", "csp-base", "low", "confirmed",
        "CSP does not lock the base URL",
        "An injected <base> tag can redirect every relative link and script on the page.",
        "Add base-uri 'self' (or 'none').", "base-uri is not set.", ref));
    }
    if (meta && !enforced) {
      out.push(mk("csp", "csp-meta", "info", "confirmed",
        "CSP is set with a meta tag",
        "Meta policies work, but they cannot use frame-ancestors or report-uri, and they apply only after the tag is parsed.",
        "Prefer the Content-Security-Policy HTTP header.", "", ref));
    }
    if (!issues.length) {
      out.push(mk("csp", "csp-pass", "pass", "confirmed", "Content Security Policy looks solid", "", "", "Policy from " + source + ".", ref));
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   *  Cookies (from Set-Cookie headers)
   * ------------------------------------------------------------------ */
  const SESSIONISH = /(sess|sid\b|auth|token|jwt|login|sso|remember|passport|connect\.sid)/i;
  const CSRFISH = /(csrf|xsrf)/i;

  function parseSetCookie(raw) {
    const parts = String(raw).split(";").map(s => s.trim());
    const nv = parts.shift() || "";
    const i = nv.indexOf("=");
    const o = { name: i < 0 ? nv : nv.slice(0, i), secure: false, httpOnly: false, sameSite: null, path: null, domain: null };
    for (const a of parts) {
      const j = a.indexOf("=");
      const key = (j < 0 ? a : a.slice(0, j)).trim().toLowerCase();
      const val = j < 0 ? "" : a.slice(j + 1).trim();
      if (key === "secure") o.secure = true;
      else if (key === "httponly") o.httpOnly = true;
      else if (key === "samesite") o.sameSite = val.toLowerCase();
      else if (key === "path") o.path = val;
      else if (key === "domain") o.domain = val;
    }
    return o;
  }

  function nameList(arr) {
    const u = Array.from(new Set(arr));
    return u.slice(0, 8).join(", ") + (u.length > 8 ? ` and ${u.length - 8} more` : "");
  }

  function analyzeCookies(setCookies, isHttps, domNames) {
    const out = [];
    const ref = MDN + "HTTP/Headers/Set-Cookie";
    const cookies = (setCookies || []).map(parseSetCookie).filter(c => c.name);
    const flaggedNames = new Set();

    if (cookies.length) {
      const noSecure = cookies.filter(c => isHttps && !c.secure);
      const noSecureSess = noSecure.filter(c => SESSIONISH.test(c.name));
      const noHttpOnly = cookies.filter(c => !c.httpOnly && SESSIONISH.test(c.name) && !CSRFISH.test(c.name));
      const noSameSite = cookies.filter(c => !c.sameSite && SESSIONISH.test(c.name));
      const noneNoSecure = cookies.filter(c => c.sameSite === "none" && !c.secure);
      const prefixBad = cookies.filter(c =>
        (/^__Host-/i.test(c.name) && (!c.secure || c.path !== "/" || c.domain)) ||
        (/^__Secure-/i.test(c.name) && !c.secure));

      if (noSecureSess.length) {
        noSecureSess.forEach(c => flaggedNames.add(c.name));
        out.push(mk("cookies", "cookie-secure-session", "medium", "confirmed",
          "Login cookies can be sent over plain HTTP",
          "Without the Secure flag, a login cookie can leak on an unencrypted connection (for example public Wi-Fi).",
          "Add the Secure attribute to these cookies.", "Cookies: " + nameList(noSecureSess.map(c => c.name)), ref));
      }
      const noSecureOther = noSecure.filter(c => !SESSIONISH.test(c.name));
      if (noSecureOther.length) {
        out.push(mk("cookies", "cookie-secure-other", "low", "confirmed",
          "Some cookies lack the Secure flag",
          "These cookies can be sent over an unencrypted connection.",
          "Add the Secure attribute unless the cookie must work on http:// pages.", "Cookies: " + nameList(noSecureOther.map(c => c.name)), ref));
      }
      if (noHttpOnly.length) {
        noHttpOnly.forEach(c => flaggedNames.add(c.name));
        out.push(mk("cookies", "cookie-httponly", "medium", "confirmed",
          "Login cookies can be read by scripts",
          "Without HttpOnly, any script that runs on the page (including injected ones) can steal the login cookie.",
          "Add the HttpOnly attribute to session and auth cookies.", "Cookies: " + nameList(noHttpOnly.map(c => c.name)), ref));
      }
      if (noSameSite.length) {
        out.push(mk("cookies", "cookie-samesite", "low", "confirmed",
          "Login cookies do not set SameSite",
          "Browsers default to Lax, but older ones do not. An explicit value protects against cross-site request attacks.",
          "Add SameSite=Lax (or Strict) to session cookies.", "Cookies: " + nameList(noSameSite.map(c => c.name)), ref));
      }
      if (noneNoSecure.length) {
        out.push(mk("cookies", "cookie-none-secure", "medium", "confirmed",
          "SameSite=None without Secure",
          "Chrome rejects these cookies, so the feature that sets them is probably broken.",
          "Add Secure, or change SameSite to Lax.", "Cookies: " + nameList(noneNoSecure.map(c => c.name)), ref));
      }
      if (prefixBad.length) {
        out.push(mk("cookies", "cookie-prefix", "low", "confirmed",
          "Cookie prefix rules are broken",
          "__Host- and __Secure- cookies must be Secure (and __Host- needs Path=/ and no Domain), or the browser ignores them.",
          "Fix the attributes or drop the prefix.", "Cookies: " + nameList(prefixBad.map(c => c.name)), ref));
      }
    }

    // Session-like cookies readable by JS on the page (covers cookies set earlier than this response).
    const readable = (domNames || []).filter(n => SESSIONISH.test(n) && !CSRFISH.test(n) && !flaggedNames.has(n));
    if (readable.length) {
      out.push(mk("cookies", "cookie-js-readable", "medium", "likely",
        "A login-style cookie is readable by scripts",
        "Cookies that scripts can read can also be stolen by injected scripts.",
        "Set HttpOnly on session and auth cookies.", "Cookies readable by JavaScript: " + nameList(readable), ref));
    }

    // Pentesting Case 8: Weak or predictable session cookie IDs
    const WEAK_SESS_NAMES = /^(dvwasession|weak_id|predictable_id)$/i;
    const weakSess = (cookies || []).filter(c => {
      const raw = (setCookies || []).find(sc => sc.startsWith(c.name + "=")) || "";
      const val = (raw.split(";")[0] || "").split("=")[1] || "";
      if (WEAK_SESS_NAMES.test(c.name)) return true;
      if (/^(session_id|sess_id|sessionid)$/i.test(c.name) && /^\d{1,8}$/.test(val)) return true;
      return false;
    });
    if (weakSess.length) {
      out.push(mk("cookies", "cookie-weak-session-id", "high", "likely",
        "Predictable or sequential session cookie detected",
        "Cookie '" + weakSess.map(c => c.name).join(", ") + "' has predictable or low-entropy sequential values. Attackers can predict other active session IDs to hijack accounts.",
        "Generate session identifiers using cryptographically secure pseudorandom number generators (CSPRNG) with at least 128 bits of entropy.",
        "Cookies: " + nameList(weakSess.map(c => c.name)), ref));
    }

    const problems = out.length;
    if (!problems) {
      out.push(mk("cookies", "cookie-pass", "pass", "confirmed",
        cookies.length || (domNames || []).length ? "Cookie flags look fine" : "No cookies set by this page",
        "", "", cookies.length ? `${cookies.length} cookie(s) checked.` : "", ref));
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   *  Security headers
   * ------------------------------------------------------------------ */
  function analyzeHeaders(h, isHttps, ctx) {
    const out = [];
    ctx = ctx || {};
    const csp = h["content-security-policy"] || "";

    // HSTS
    if (isHttps) {
      const ref = MDN + "HTTP/Headers/Strict-Transport-Security";
      const v = h["strict-transport-security"];
      if (!v) {
        out.push(mk("headers", "hsts-missing", "medium", "confirmed",
          "HTTPS is not enforced (no HSTS)",
          "Without HSTS, a visitor who types the address without https:// can be tricked onto an insecure copy of the site.",
          "Send Strict-Transport-Security: max-age=31536000; includeSubDomains",
          "Strict-Transport-Security header is missing.", ref));
      } else {
        const m = /max-age\s*=\s*"?(\d+)/i.exec(v);
        const age = m ? parseInt(m[1], 10) : 0;
        if (!m || age < 15552000) {
          out.push(mk("headers", "hsts-short", "low", "confirmed",
            "HSTS lifetime is short",
            "A short HSTS lifetime means browsers forget to enforce HTTPS quickly.",
            "Use max-age of at least 31536000 (one year).", "Header: " + v, ref));
        } else {
          out.push(mk("headers", "hsts-pass", "pass", "confirmed", "HTTPS is enforced (HSTS)", "", "",
            "Header: " + v + (/includesubdomains/i.test(v) ? "" : " (tip: add includeSubDomains)"), ref));
        }
      }
    }

    // Clickjacking
    {
      const xfo = (h["x-frame-options"] || "").toLowerCase();
      const fa = /(^|;)\s*frame-ancestors\s/i.test(csp);
      const ref = MDN + "HTTP/Headers/X-Frame-Options";
      if (fa || xfo === "deny" || xfo === "sameorigin") {
        out.push(mk("headers", "clickjack-pass", "pass", "confirmed", "Page cannot be framed by other sites", "", "",
          fa ? "Protected by CSP frame-ancestors." : "X-Frame-Options: " + h["x-frame-options"], ref));
      } else if (xfo) {
        out.push(mk("headers", "clickjack-weak", "low", "confirmed",
          "X-Frame-Options value is not effective",
          "Only DENY and SAMEORIGIN are supported by modern browsers.",
          "Use frame-ancestors 'self' in your CSP, or X-Frame-Options: SAMEORIGIN.", "Header: " + h["x-frame-options"], ref));
      } else {
        out.push(mk("headers", "clickjack-missing", "medium", "confirmed",
          "Other sites can put this page in a frame",
          "An attacker can overlay your page in an invisible frame and trick visitors into clicking (clickjacking).",
          "Send Content-Security-Policy: frame-ancestors 'self' (or X-Frame-Options: SAMEORIGIN).",
          "Neither X-Frame-Options nor CSP frame-ancestors is set.", ref));
      }
    }

    // nosniff
    if ((h["x-content-type-options"] || "").toLowerCase().includes("nosniff")) {
      out.push(mk("headers", "nosniff-pass", "pass", "confirmed", "Content type sniffing is disabled", "", "", "", MDN + "HTTP/Headers/X-Content-Type-Options"));
    } else {
      out.push(mk("headers", "nosniff-missing", "low", "confirmed",
        "Browsers may guess file types",
        "Without nosniff, a browser can treat an uploaded text file as a script.",
        "Send X-Content-Type-Options: nosniff", "Header is missing.", MDN + "HTTP/Headers/X-Content-Type-Options"));
    }

    // Referrer-Policy
    {
      const rp = (h["referrer-policy"] || "").toLowerCase();
      const ref = MDN + "HTTP/Headers/Referrer-Policy";
      if (!rp) {
        out.push(mk("headers", "referrer-missing", "low", "confirmed",
          "No explicit Referrer-Policy",
          "Modern browsers already trim the referrer, but setting it removes any doubt about what you leak to other sites.",
          "Send Referrer-Policy: strict-origin-when-cross-origin", "Header is missing.", ref));
      } else if (/unsafe-url|no-referrer-when-downgrade/.test(rp)) {
        out.push(mk("headers", "referrer-weak", "low", "confirmed",
          "Referrer-Policy leaks full URLs",
          "Full page addresses (which may contain tokens or IDs) are sent to other sites.",
          "Use strict-origin-when-cross-origin or no-referrer.", "Header: " + h["referrer-policy"], ref));
      } else {
        out.push(mk("headers", "referrer-pass", "pass", "confirmed", "Referrer-Policy is set", "", "", "Header: " + h["referrer-policy"], ref));
      }
    }

    // Permissions-Policy (info only)
    if (h["permissions-policy"] || h["feature-policy"]) {
      out.push(mk("headers", "perm-pass", "pass", "confirmed", "Permissions-Policy is set", "", "", "", MDN + "HTTP/Headers/Permissions-Policy"));
    } else {
      out.push(mk("headers", "perm-missing", "info", "confirmed",
        "No Permissions-Policy",
        "This header switches off browser features (camera, microphone, location) you do not use.",
        "Optional: Permissions-Policy: camera=(), microphone=(), geolocation=()", "", MDN + "HTTP/Headers/Permissions-Policy"));
    }

    // Cross-origin isolation (info only)
    if (!h["cross-origin-opener-policy"]) {
      out.push(mk("headers", "coop-missing", "info", "confirmed",
        "No Cross-Origin-Opener-Policy",
        "COOP isolates your page from pop-ups other sites open. It matters most for sites that handle sensitive data.",
        "Optional: Cross-Origin-Opener-Policy: same-origin", "", MDN + "HTTP/Headers/Cross-Origin-Opener-Policy"));
    }

    // Information leaks in headers
    const leaks = [];
    const server = h["server"] || "";
    if (/\d+\.\d+/.test(server)) leaks.push("Server: " + server);
    if (h["x-powered-by"]) leaks.push("X-Powered-By: " + h["x-powered-by"]);
    if (h["x-aspnet-version"]) leaks.push("X-AspNet-Version: " + h["x-aspnet-version"]);
    if (h["x-aspnetmvc-version"]) leaks.push("X-AspNetMvc-Version: " + h["x-aspnetmvc-version"]);
    if (h["x-generator"]) leaks.push("X-Generator: " + h["x-generator"]);
    if (leaks.length) {
      out.push(mk("headers", "leak-versions", "low", "confirmed",
        "Server software details are visible",
        "Exact versions help attackers pick known exploits for your software.",
        "Remove or genericise these headers in your server or CDN settings.", leaks.join("; ")));
    }

    // CORS
    {
      const acao = h["access-control-allow-origin"];
      const acac = (h["access-control-allow-credentials"] || "").toLowerCase() === "true";
      if (acao === "*" && acac) {
        out.push(mk("headers", "cors-wild-creds", "medium", "confirmed",
          "CORS is configured unsafely",
          "Allowing every origin together with credentials is invalid and usually means the server reflects origins or is misconfigured.",
          "Return a specific allowed origin, never * together with credentials.", "Access-Control-Allow-Origin: *; Access-Control-Allow-Credentials: true"));
      } else if (acao && acao.toLowerCase() === "null") {
        out.push(mk("headers", "cors-null", "medium", "confirmed",
          "CORS trusts the null origin",
          "Sandboxed pages and local files send Origin: null, so anyone can satisfy this rule.",
          "Remove null from the allowed origins.", "Access-Control-Allow-Origin: null"));
      }
    }

    // Deprecated header
    if (h["x-xss-protection"] && /^\s*1/.test(h["x-xss-protection"])) {
      out.push(mk("headers", "xxss-old", "info", "confirmed",
        "Deprecated X-XSS-Protection header",
        "Modern browsers ignore it, and in old ones it could create new bugs.",
        "Remove it or set it to 0 and rely on CSP.", "Header: " + h["x-xss-protection"]));
    }

    // Caching of pages with login fields
    if (ctx.passwordFields > 0) {
      const cc = (h["cache-control"] || "").toLowerCase();
      if (!/no-store|private/.test(cc)) {
        out.push(mk("headers", "cache-login", "low", "likely",
          "Login page may be cached",
          "Shared caches and the back button can keep copies of pages that hold personal data.",
          "Send Cache-Control: no-store on login and account pages.", "Cache-Control: " + (h["cache-control"] || "(not set)"), MDN + "HTTP/Headers/Cache-Control"));
      }
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   *  Technology from headers
   * ------------------------------------------------------------------ */
  function techFromHeaders(h) {
    const t = [];
    const add = (name, how, version) => t.push({ name, version: version || "", how, kind: "server" });
    if (h["server"]) {
      const m = /^([^\s/]+)(?:\/(\S+))?/.exec(h["server"]);
      add(m ? m[1] : h["server"], "Server header", m && m[2]);
    }
    if (h["x-powered-by"]) {
      const m = /^([^\s/]+)(?:\/(\S+))?/.exec(h["x-powered-by"]);
      add(m ? m[1] : h["x-powered-by"], "X-Powered-By header", m && m[2]);
    }
    if (h["cf-ray"]) add("Cloudflare", "cf-ray header");
    if (h["x-vercel-id"]) add("Vercel", "x-vercel-id header");
    if (h["x-amz-cf-id"]) add("Amazon CloudFront", "x-amz-cf-id header");
    if (h["x-served-by"] && /cache/i.test(h["x-served-by"])) add("Fastly", "x-served-by header");
    if (h["x-nf-request-id"]) add("Netlify", "x-nf-request-id header");
    if (h["x-github-request-id"]) add("GitHub Pages", "x-github-request-id header");
    if (h["fly-request-id"]) add("Fly.io", "fly-request-id header");
    return t;
  }

  function cdnHint(h) {
    h = h || {};
    if (h["cf-ray"] || /cloudflare/i.test(h["server"] || "")) return "Cloudflare";
    if (h["x-amz-cf-id"]) return "Amazon CloudFront";
    if (h["x-vercel-id"]) return "Vercel";
    if (h["x-nf-request-id"]) return "Netlify";
    if (h["x-served-by"] && /cache/i.test(h["x-served-by"])) return "Fastly";
    if (h["x-github-request-id"]) return "GitHub Pages";
    if (h["x-akamai-transformed"] || /akamai/i.test(h["server"] || "")) return "Akamai";
    return "";
  }

  /* ------------------------------------------------------------------ *
   *  Report assembly
   * ------------------------------------------------------------------ */
  function hostOf(url) { try { return new URL(url).hostname; } catch (_) { return ""; } }

  function buildReport(opts) {
    const mode = MODE_CATS.hasOwnProperty(opts.mode) ? opts.mode : "all";
    const dom = opts.dom || { findings: [], facts: {}, tech: [], errors: [] };
    const net = opts.net || null;
    const url = dom.url || opts.url || "";
    const isHttps = /^https:/i.test(url);
    const facts = dom.facts || {};
    let findings = (dom.findings || []).map(f => Object.assign({}, f));
    const notes = [];
    const tech = (dom.tech || []).slice();

    if (net && net.headers) {
      const h = net.headers;
      findings = findings.concat(analyzeHeaders(h, isHttps, { passwordFields: facts.passwordFields || 0 }));
      findings = findings.concat(analyzeCsp(h["content-security-policy"], h["content-security-policy-report-only"], facts.cspMeta));
      if (net.cookiesKnown) findings = findings.concat(analyzeCookies(net.setCookies, isHttps, facts.cookieNames));
      else {
        findings = findings.concat(analyzeCookies([], isHttps, facts.cookieNames));
        notes.push("Cookie flags could not be read from the server response, so only cookies visible to scripts were checked.");
      }
      techFromHeaders(h).forEach(x => tech.push(x));
      if (net.source === "head") notes.push("Headers came from a separate request to this address. They can differ from what your browser received if you are logged in.");
      if (net.source === "origin") notes.push("Headers came from the site's home page because this page could not be requested directly.");
    } else if (opts.netRequested !== false) {
      // No header data at all: keep going, say so plainly.
      findings = findings.concat(analyzeCsp("", "", facts.cspMeta).filter(f => f.id !== "csp-missing"));
      findings = findings.concat(analyzeCookies([], isHttps, facts.cookieNames));
      notes.push("Server headers could not be read, so header checks were skipped. Reload the page and scan again.");
      findings.push(mk("headers", "headers-unavailable", "info", "confirmed",
        "Security headers could not be checked",
        "The browser did not give the extension this page's response headers.",
        "Reload the page, then run the scan again."));
    }

    // Deduplicate by id (content script may already have emitted the same check).
    const seen = new Set();
    findings = findings.filter(f => { const k = f.id + "|" + (f.detail || "").slice(0, 60); if (seen.has(k)) return false; seen.add(k); return true; });

    const cats = MODE_CATS[mode];
    if (cats) findings = findings.filter(f => cats.includes(f.cat));
    const techOut = (!cats || cats.includes("tech")) ? dedupeTech(tech) : [];
    findings = sortFindings(findings);

    const sc = scoreFindings(findings);
    const top = topFixes(findings, 3).map(f => f.id);
    const errors = (dom.errors || []).slice(0, 10);

    return {
      ok: true,
      engine: VERSION,
      mode,
      url,
      host: hostOf(url),
      scannedAt: Date.now(),
      headerSource: net ? net.source : "none",
      ip: (net && net.ip) || "",
      cdn: net && net.headers ? cdnHint(net.headers) : "",
      score: sc.score,
      grade: sc.grade,
      counts: sc.counts,
      verdict: verdictFor(sc.counts, mode),
      top,
      findings,
      tech: techOut,
      facts: { forms: facts.forms || 0, scriptsExternal: facts.scriptsExternal || 0, scriptsInline: facts.scriptsInline || 0,
        thirdPartyHosts: facts.thirdPartyHosts || [], links: facts.links || 0, iframes: facts.iframes || 0, title: facts.title || "" },
      notes,
      errors,
      scope: "Checks the page you have open and its response headers. It does not test your server code, so passing is not a guarantee of safety."
    };
  }

  function dedupeTech(list) {
    const m = new Map();
    for (const t of list) {
      const k = (t.name || "").toLowerCase();
      if (!k) continue;
      const cur = m.get(k);
      if (!cur || (!cur.version && t.version)) m.set(k, t);
    }
    return Array.from(m.values());
  }

  /* ------------------------------------------------------------------ *
   *  Utilities
   * ------------------------------------------------------------------ */
  function isIPv4(s) { return /^(\d{1,3})(\.\d{1,3}){3}$/.test(s) && s.split(".").every(n => +n <= 255); }
  function isIPv6(s) { const t = String(s).replace(/^\[|\]$/g, ""); return (t.match(/:/g) || []).length >= 2 && /^[0-9a-f:.]+$/i.test(t); }
  function isPrivateIp(ip) {
    ip = String(ip || "").replace(/^\[|\]$/g, "").toLowerCase();
    if (isIPv4(ip)) {
      const [a, b] = ip.split(".").map(Number);
      return a === 10 || a === 127 || a === 0 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 169 && b === 254) || (a === 100 && b >= 64 && b <= 127);
    }
    return ip === "::1" || ip === "::" || /^f[cd]/.test(ip) || /^fe[89ab]/.test(ip);
  }

  /** Accepts "example.com", "https://example.com:8080/x", "1.2.3.4". Returns hostname or "". */
  function cleanTarget(input) {
    let s = String(input || "").trim();
    if (!s || s.length > 255) return "";
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) { try { s = new URL(s).hostname; } catch (_) { return ""; } }
    s = s.replace(/\/.*$/, "").replace(/^\[|\]$/g, "");
    if (/@/.test(s)) return "";
    if (!isIPv6(s)) s = s.replace(/:\d+$/, "");
    s = s.toLowerCase().replace(/\.$/, "");
    if (isIPv4(s) || isIPv6(s)) return s;
    if (s === "localhost") return s;
    if (!/[a-z]/.test(s.split(".").pop())) return "";      // "999.1.1.1" is a bad IP, not a hostname
    return /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(s) ? s : "";
  }

  /* ------------------------------------------------------------------ *
   *  DNS over HTTPS, Shodan InternetDB
   * ------------------------------------------------------------------ */
  async function dohQuery(host, type) {
    const urls = [
      `${CONFIG.detective.dohResolvers[0]}?name=${encodeURIComponent(host)}&type=${type}`,
      `${CONFIG.detective.dohResolvers[1]}?name=${encodeURIComponent(host)}&type=${type}`
    ];
    let lastErr = null;
    for (const u of urls) {
      try {
        const r = await fetchTimeout(u, { headers: { Accept: "application/dns-json" }, cache: "no-store", credentials: "omit" }, CONFIG.detective.timeouts.dohMs);
        if (!r.ok) { lastErr = new Error("DNS HTTP " + r.status); continue; }
        const j = await r.json();
        return { resolver: new URL(u).hostname, answers: Array.isArray(j.Answer) ? j.Answer : [], status: j.Status };
      } catch (e) { lastErr = e; }
    }
    throw lastErr || new Error("DNS lookup failed");
  }

  async function resolveHost(host) {
    host = cleanTarget(host);
    if (!host) throw new Error("Enter a valid website or IP.");
    if (isIPv4(host) || isIPv6(host)) return { host, a: isIPv4(host) ? [host] : [], aaaa: isIPv6(host) ? [host] : [], cname: [], resolver: "", literal: true };
    if (host === "localhost") return { host, a: ["127.0.0.1"], aaaa: ["::1"], cname: [], resolver: "", literal: true };
    const [a, aaaa] = await Promise.allSettled([dohQuery(host, "A"), dohQuery(host, "AAAA")]);
    if (a.status === "rejected" && aaaa.status === "rejected") throw new Error("Could not look up this name. Check the spelling and your connection.");
    const ans = [].concat(a.value ? a.value.answers : [], aaaa.value ? aaaa.value.answers : []);
    return {
      host,
      a: ans.filter(x => x.type === 1).map(x => x.data),
      aaaa: ans.filter(x => x.type === 28).map(x => x.data),
      cname: ans.filter(x => x.type === 5).map(x => String(x.data).replace(/\.$/, "")),
      resolver: (a.value || aaaa.value).resolver,
      literal: false
    };
  }

  async function shodanLookup(ip) {
    if (!ip || isPrivateIp(ip)) return { ok: true, skipped: true, reason: "Private address. Public databases do not know it." };
    try {
      const r = await fetchTimeout(CONFIG.detective.internetDbUrl + encodeURIComponent(ip), { cache: "no-store", credentials: "omit" }, CONFIG.detective.timeouts.internetDbMs);
      if (r.status === 404) return { ok: true, ip, ports: [], vulns: [], hostnames: [], cpes: [], tags: [], empty: true };
      if (!r.ok) return { ok: false, error: "Port database returned " + r.status };
      const j = await r.json();
      return { ok: true, ip, ports: (j.ports || []).map(Number).sort((a, b) => a - b), vulns: j.vulns || [], hostnames: j.hostnames || [], cpes: j.cpes || [], tags: j.tags || [] };
    } catch (e) {
      return { ok: false, error: "Could not reach the public port database." };
    }
  }

  /* ------------------------------------------------------------------ *
   *  Port catalogue + classification
   * ------------------------------------------------------------------ */
  // Ports that Chrome refuses to connect to (ERR_UNSAFE_PORT). A live test cannot tell us anything here.
  const CHROME_BLOCKED = new Set([1, 7, 9, 11, 13, 15, 17, 19, 20, 21, 22, 23, 25, 37, 42, 43, 53, 69, 77, 79, 87, 95, 101, 102, 103, 104, 109, 110, 111, 113, 115, 117, 119, 123, 135, 137, 139, 143, 161, 179, 389, 427, 465, 512, 513, 514, 515, 526, 530, 531, 532, 540, 548, 554, 556, 563, 587, 601, 636, 989, 990, 993, 995, 1719, 1720, 1723, 2049, 3659, 4045, 4190, 5060, 5061, 6000, 6566, 6665, 6666, 6667, 6668, 6669, 6679, 6697, 10080]);

  const PORTS = {
    21:    { name: "FTP", risk: "insecure" },
    22:    { name: "SSH", risk: "admin" },
    23:    { name: "Telnet", risk: "insecure" },
    25:    { name: "SMTP (mail)", risk: "mail" },
    53:    { name: "DNS", risk: "info" },
    80:    { name: "HTTP (web)", risk: "web" },
    110:   { name: "POP3 (mail)", risk: "mail" },
    143:   { name: "IMAP (mail)", risk: "mail" },
    443:   { name: "HTTPS (web)", risk: "web" },
    445:   { name: "SMB file sharing", risk: "insecure" },
    587:   { name: "SMTP submission", risk: "mail" },
    993:   { name: "IMAPS (mail)", risk: "mail" },
    995:   { name: "POP3S (mail)", risk: "mail" },
    1433:  { name: "Microsoft SQL Server", risk: "database" },
    1521:  { name: "Oracle database", risk: "database" },
    2375:  { name: "Docker API (unencrypted)", risk: "critical" },
    3000:  { name: "Dev server", risk: "dev" },
    3306:  { name: "MySQL / MariaDB", risk: "database" },
    3389:  { name: "Remote Desktop (RDP)", risk: "admin" },
    5000:  { name: "Dev server", risk: "dev" },
    5432:  { name: "PostgreSQL", risk: "database" },
    5601:  { name: "Kibana", risk: "admin" },
    5900:  { name: "VNC remote screen", risk: "admin" },
    5984:  { name: "CouchDB", risk: "database" },
    6379:  { name: "Redis", risk: "database" },
    8000:  { name: "Alternate web / dev", risk: "dev" },
    8080:  { name: "Alternate web", risk: "web" },
    8443:  { name: "Alternate HTTPS", risk: "web" },
    8888:  { name: "Alternate web / Jupyter", risk: "dev" },
    9090:  { name: "Admin panel (Prometheus / Cockpit)", risk: "admin" },
    9200:  { name: "Elasticsearch", risk: "database" },
    11211: { name: "Memcached", risk: "database" },
    15672: { name: "RabbitMQ admin", risk: "admin" },
    27017: { name: "MongoDB", risk: "database" }
  };

  const RISK_TEXT = {
    web:      { level: "info",     why: "Normal web port.", fix: "" },
    mail:     { level: "info",     why: "A mail service is reachable. Fine if you run a mail server.", fix: "If you do not run mail on this machine, close the port." },
    info:     { level: "info",     why: "Reachable service.", fix: "Close it if you do not need it." },
    dev:      { level: "medium",   why: "This looks like a development server. These often have no login and show debug data.", fix: "Do not expose development servers to the internet. Close the port or put it behind a login." },
    admin:    { level: "high",     why: "Remote-access or admin interface open to the internet. These are constantly attacked with password guessing.", fix: "Restrict this port to your own IP with a firewall, or use a VPN. Use keys or strong passwords plus 2-factor." },
    database: { level: "critical", why: "A database is reachable from the internet. Databases should only talk to your own servers.", fix: "Close this port in your firewall or cloud security group, and bind the database to localhost or a private network." },
    insecure: { level: "high",     why: "This service sends data without encryption or has a long history of attacks.", fix: "Close the port. Use SFTP/SSH instead of FTP/Telnet, and never expose file sharing (SMB) to the internet." },
    critical: { level: "critical", why: "The unencrypted Docker API gives full control of the machine to anyone who connects.", fix: "Close this port immediately and make sure the Docker daemon is not listening on TCP without TLS." }
  };

  const PORT_PRESETS = {
    quick:  [80, 443, 22, 21, 3306, 5432, 6379, 27017, 3389, 8080],
    common: [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 587, 993, 995, 1433, 1521, 2375, 3000, 3306, 3389, 5000, 5432, 5900, 6379, 8000, 8080, 8443, 8888, 9200, 11211, 27017],
    web:    [80, 443, 3000, 5000, 8000, 8080, 8443, 8888, 9090],
    admin:  [22, 23, 3389, 5601, 5900, 9090, 15672, 2375]
  };

  function parsePortList(text, max) {
    const set = new Set();
    String(text || "").split(/[\s,;]+/).filter(Boolean).forEach(tok => {
      const m = /^(\d{1,5})(?:-(\d{1,5}))?$/.exec(tok);
      if (!m) return;
      let a = +m[1], b = m[2] ? +m[2] : a;
      if (a > b) [a, b] = [b, a];
      if (a < 1 || b > 65535 || b - a > 50) return;
      for (let p = a; p <= b; p++) set.add(p);
    });
    return Array.from(set).slice(0, max || 60);
  }

  /** Decide a status from one probe result and the host's "closed port" baseline (ms). */
  function classifyProbe(port, probe, baseline) {
    if (CHROME_BLOCKED.has(port)) return { status: "blocked", conf: "none", note: "Chrome does not allow connections to this port, so it cannot be tested from the browser." };
    if (probe.ok) return { status: "open", conf: "confirmed", note: "A web service answered." };
    if (probe.timedOut) {
      return baseline && baseline.allTimedOut
        ? { status: "filtered", conf: "likely", note: "No reply. A firewall is probably dropping traffic." }
        : { status: "filtered", conf: "likely", note: "No reply while other closed ports reply instantly, so a firewall rule or a silent service is likely." };
    }
    const closedMs = baseline && baseline.closedMs != null ? baseline.closedMs : null;
    if (closedMs == null) return { status: "closed", conf: "review", note: "Connection failed quickly." };
    if (closedMs < 15) return { status: "no-web-service", conf: "review", note: "No web service answered. On very fast networks (localhost, LAN) a closed port and a non-web service such as SSH or a database look the same to a browser." };
    const limit = Math.max(closedMs * 1.6, closedMs + 40);
    if (probe.ms > limit) return { status: "possibly-open", conf: "review", note: "Connected, then the service did not speak HTTP (or its certificate was rejected). Likely a non-web service." };
    return { status: "closed", conf: "likely", note: "Connection refused." };
  }

  function portFinding(port, status, shodanListed) {
    const info = PORTS[port] || { name: "Port " + port, risk: "info" };
    const r = RISK_TEXT[info.risk] || RISK_TEXT.info;
    const reachable = status === "open" || status === "possibly-open" || shodanListed;
    return { port, name: info.name, risk: info.risk, level: reachable ? r.level : "pass", why: reachable ? r.why : "", fix: reachable ? r.fix : "" };
  }

  function summarizePortScan(rows) {
    const reachable = rows.filter(r => r.status === "open" || r.status === "possibly-open" || r.publicListed);
    const risky = reachable.filter(r => r.level === "critical" || r.level === "high" || r.level === "medium");
    let verdict, tone;
    if (!rows.length) { verdict = "Nothing was tested."; tone = "info"; }
    else if (risky.length) {
      tone = risky.some(r => r.level === "critical" || r.level === "high") ? "bad" : "warn";
      verdict = `${risky.length} risky port${risky.length > 1 ? "s are" : " is"} reachable: ${risky.map(r => r.port).join(", ")}.`;
    } else if (reachable.length) { tone = "ok"; verdict = `Only expected ports are reachable: ${reachable.map(r => r.port).join(", ")}.`; }
    else { tone = "ok"; verdict = "No open ports were found among the ports tested."; }
    return { verdict, tone, risky: risky.map(r => r.port), reachable: reachable.map(r => r.port) };
  }

  /* ------------------------------------------------------------------ *
   *  Live port probe (browser fetch timing)
   * ------------------------------------------------------------------ */
  const HTTPS_PORTS = new Set([443, 8443, 9443]);

  async function probeOne(host, port, timeoutMs) {
    const scheme = HTTPS_PORTS.has(port) ? "https" : "http";
    const hostPart = host.includes(":") ? `[${host}]` : host;
    const ctl = new AbortController();
    const t0 = Date.now();
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      await fetch(`${scheme}://${hostPart}:${port}/`, { method: "GET", mode: "no-cors", cache: "no-store", credentials: "omit", redirect: "manual", signal: ctl.signal });
      return { ok: true, ms: Date.now() - t0 };
    } catch (e) {
      const ms = Date.now() - t0;
      return { ok: false, ms, timedOut: ctl.signal.aborted || ms >= timeoutMs - 30 };
    } finally { clearTimeout(timer); }
  }

  function median(a) { const s = a.slice().sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; }

  async function baselineFor(host, probe) {
    const used = new Set();
    const ports = [];
    while (ports.length < 3) {
      const p = 49200 + Math.floor(Math.random() * 15000);
      if (!used.has(p) && !PORTS[p]) { used.add(p); ports.push(p); }
    }
    const res = [];
    for (const p of ports) res.push(await probe(host, p, CONFIG.detective.timeouts.portBaselineMs));
    const failed = res.filter(r => !r.ok);
    const timed = failed.filter(r => r.timedOut);
    if (res.some(r => r.ok)) return { closedMs: null, allTimedOut: false };
    if (timed.length === res.length) return { closedMs: null, allTimedOut: true };
    return { closedMs: median(failed.filter(r => !r.timedOut).map(r => r.ms)), allTimedOut: false };
  }

  async function proxyActive() {
    try {
      const s = await chrome.proxy.settings.get({ incognito: false });
      const mode = s && s.value && s.value.mode;
      return !!mode && mode !== "direct" && mode !== "system" && mode !== "auto_detect";
    } catch (_) { return false; }
  }

  let portJob = null;      // { cancel: bool }

  async function savePortState(state) {
    try { await chrome.storage.session.set({ [CONFIG.detective.storageKeys.portScanState]: state }); } catch (_) {}
  }

  async function startPortScan(msg) {
    if (portJob && !portJob.done) return { ok: false, error: "A port test is already running. Stop it first." };
    if (msg.confirmOwner !== true) return { ok: false, error: "Tick the box to confirm you own this site or have permission to test it." };
    const host = cleanTarget(msg.target);
    if (!host) return { ok: false, error: "Enter a website like example.com or an IP address." };

    const preset = PORT_PRESETS[msg.preset] ? PORT_PRESETS[msg.preset] : null;
    let ports = msg.preset === "custom" || !preset ? parsePortList(msg.custom, CONFIG.detective.limits.maxCustomPorts) : preset.slice();
    if (!ports.length) return { ok: false, error: "No valid ports. Use numbers 1-65535 separated by commas, e.g. 80, 443, 8080." };

    const job = portJob = { cancel: false, done: false };
    const state = { running: true, host, startedAt: Date.now(), total: ports.length, done: 0, rows: [], notes: [], dns: null, publicDb: null, summary: null, cancelled: false };
    await savePortState(state);

    (async () => {
      try {
        if (await proxyActive()) state.notes.push("A proxy is active in this browser, so the live test shows what the proxy can reach, not your own connection. Turn the proxy off for accurate results.");
        let ips = { a: [], aaaa: [] };
        try { ips = await resolveHost(host); state.dns = { a: ips.a, aaaa: ips.aaaa, cname: ips.cname }; } catch (e) { state.notes.push(e.message); }
        const ip = (ips.a && ips.a[0]) || (ips.aaaa && ips.aaaa[0]) || "";
        const pageHeaders = msg.headers || null;
        const cdn = cdnHint(pageHeaders) || ((ips.cname || []).some(c => /cloudflare|cloudfront|fastly|akamai|vercel|netlify/i.test(c)) ? "a CDN" : "");
        if (cdn) state.notes.push(`This site is behind ${cdn}. Port results describe the CDN's servers, not your own server. Test your origin server's IP directly for a true picture.`);
        await savePortState(state);

        // Passive public view
        const listed = new Set();
        if (ip) {
          const pub = await shodanLookup(ip);
          state.publicDb = pub;
          if (pub.ok && pub.ports) pub.ports.forEach(p => listed.add(p));
          await savePortState(state);
        }

        const targetHost = ip || host;
        const baseline = job.cancel ? null : await baselineFor(targetHost, probeOne);
        const queue = ports.slice();
        const rows = [];
        const LANES = CONFIG.detective.limits.portScanLanes;
        async function lane() {
          while (queue.length && !job.cancel) {
            const port = queue.shift();
            const probe = await probeOne(targetHost, port, CONFIG.detective.timeouts.portProbeMs);
            const c = classifyProbe(port, probe, baseline);
            const row = Object.assign({ status: c.status, conf: c.conf, note: c.note, ms: probe.ms, publicListed: listed.has(port) }, portFinding(port, c.status, listed.has(port)));
            rows.push(row);
            state.done = rows.length;
            state.rows = rows.slice().sort((a, b) => a.port - b.port);
            await savePortState(state);
          }
        }
        await Promise.all(Array.from({ length: Math.min(LANES, ports.length) }, lane));

        // Ports the public database knows about but we did not test
        if (listed.size) {
          const tested = new Set(rows.map(r => r.port));
          for (const p of listed) {
            if (tested.has(p) || rows.length >= 100) continue;
            rows.push(Object.assign({ status: "not-tested", conf: "likely", note: "Seen open by a public internet scan. Not tested live.", ms: 0, publicListed: true }, portFinding(p, "not-tested", true)));
          }
          state.rows = rows.slice().sort((a, b) => a.port - b.port);
        }
        state.summary = summarizePortScan(state.rows);
        state.cancelled = job.cancel;
        if (job.cancel) state.summary = Object.assign({}, state.summary, { verdict: "Stopped early. " + state.summary.verdict });
      } catch (e) {
        state.error = e && e.message || String(e);
      } finally {
        state.running = false;
        state.finishedAt = Date.now();
        job.done = true;
        await savePortState(state);
      }
    })();
    return { ok: true };
  }

  function cancelPortScan() {
    if (portJob && !portJob.done) { portJob.cancel = true; return { ok: true }; }
    return { ok: true, idle: true };
  }

  /* ------------------------------------------------------------------ *
   *  Response + connection tracking (service worker only)
   * ------------------------------------------------------------------ */
  const mainByTab = new Map();       // tabId -> { url, origin, status, headers, setCookies, ip, at }
  const connByTab = new Map();       // tabId -> Map(host -> { ip, count, types:Set, firstAt })
  const MAX_TABS = CONFIG.detective.limits.maxTabsTracked;
  let proxiedCache = { at: 0, v: false };

  function trimMap(m) { while (m.size > MAX_TABS) m.delete(m.keys().next().value); }

  async function sessionGet(key) { try { const r = await chrome.storage.session.get(key); return r[key]; } catch (_) { return undefined; } }
  async function sessionSet(obj) { try { await chrome.storage.session.set(obj); } catch (_) {} }

  const persistTimers = new Map();
  function persistConn(tabId) {
    if (persistTimers.has(tabId)) return;
    persistTimers.set(tabId, setTimeout(() => {
      persistTimers.delete(tabId);
      const m = connByTab.get(tabId);
      if (!m) return;
      const arr = Array.from(m.entries()).slice(0, 150).map(([h, v]) => [h, { ip: v.ip, count: v.count, types: Array.from(v.types), firstAt: v.firstAt }]);
      sessionSet({ [CONFIG.detective.storageKeys.connectionsPrefix + tabId]: arr });
    }, 1200));
  }

  async function getConn(tabId) {
    let m = connByTab.get(tabId);
    if (!m) {
      const saved = await sessionGet(CONFIG.detective.storageKeys.connectionsPrefix + tabId);
      m = new Map();
      if (Array.isArray(saved)) saved.forEach(([h, v]) => m.set(h, { ip: v.ip, count: v.count, types: new Set(v.types), firstAt: v.firstAt }));
      connByTab.set(tabId, m);
    }
    return m;
  }

  async function getMain(tabId) {
    let r = mainByTab.get(tabId);
    if (!r) { r = await sessionGet(CONFIG.detective.storageKeys.mainFramePrefix + tabId); if (r) mainByTab.set(tabId, r); }
    return r || null;
  }

  async function isProxied() {
    if (Date.now() - proxiedCache.at > CONFIG.detective.timeouts.proxyStatusCacheMs) { proxiedCache = { at: Date.now(), v: await proxyActive() }; }
    return proxiedCache.v;
  }

  /* visited-sites log (opt-in) */
  const VISIT_KEY = CONFIG.detective.storageKeys.visitedList;
  const VISIT_MAX = CONFIG.detective.limits.maxVisitedEntries;
  const LOG_KEY = CONFIG.detective.storageKeys.logVisitsEnabled;
  let visitChain = Promise.resolve();

  function logVisit(host, ip, https, proxied) {
    visitChain = visitChain.then(async () => {
      const { [LOG_KEY]: detLogVisits, [VISIT_KEY]: list } = await chrome.storage.local.get({ [LOG_KEY]: false, [VISIT_KEY]: [] });
      if (!detLogVisits || !host) return;
      const arr = Array.isArray(list) ? list : [];
      let e = arr.find(x => x.host === host);
      const now = Date.now();
      if (!e) { e = { host, ips: [], first: now, last: now, count: 0, https: !!https, proxied: false }; arr.push(e); }
      e.last = now; e.count++; e.https = !!https;
      if (proxied) e.proxied = true;
      if (ip && !e.ips.includes(ip)) { e.ips.unshift(ip); e.ips = e.ips.slice(0, 5); }
      arr.sort((a, b) => b.last - a.last);
      await chrome.storage.local.set({ [VISIT_KEY]: arr.slice(0, VISIT_MAX) });
    }).catch(() => {});
    return visitChain;
  }

  function registerListeners() {
    if (typeof chrome === "undefined" || !chrome.webRequest) return;
    try {
      chrome.webRequest.onResponseStarted.addListener(async d => {
        try {
          if (d.tabId < 0) return;
          const u = new URL(d.url);
          const nh = normHeaders(d.responseHeaders);
          const rec = { url: d.url, origin: u.origin, status: d.statusCode, headers: nh.map, setCookies: nh.setCookies, ip: d.ip || "", at: Date.now() };
          mainByTab.set(d.tabId, rec); trimMap(mainByTab);
          connByTab.set(d.tabId, new Map());
          sessionSet({ [CONFIG.detective.storageKeys.mainFramePrefix + d.tabId]: rec, [CONFIG.detective.storageKeys.connectionsPrefix + d.tabId]: [] });
          const m = connByTab.get(d.tabId);
          m.set(u.hostname, { ip: d.ip || "", count: 1, types: new Set(["main_frame"]), firstAt: Date.now() });
          // Never log private-browsing tabs.
          let incognito = false;
          try { incognito = !!(await chrome.tabs.get(d.tabId)).incognito; } catch (_) {}
          if (!incognito) logVisit(u.hostname, d.ip || "", u.protocol === "https:", await isProxied());
        } catch (_) {}
      }, { urls: ["http://*/*", "https://*/*"], types: ["main_frame"] }, ["responseHeaders", "extraHeaders"]);

      chrome.webRequest.onCompleted.addListener(async d => {
        try {
          if (d.tabId < 0 || d.type === "main_frame") return;
          const host = new URL(d.url).hostname;
          const m = await getConn(d.tabId);
          const cur = m.get(host);
          if (cur) { cur.count++; cur.types.add(d.type); if (!cur.ip && d.ip) cur.ip = d.ip; }
          else if (m.size < 200) m.set(host, { ip: d.ip || "", count: 1, types: new Set([d.type]), firstAt: Date.now() });
          persistConn(d.tabId);
        } catch (_) {}
      }, { urls: ["http://*/*", "https://*/*"] });

      chrome.tabs.onRemoved.addListener(id => {
        mainByTab.delete(id); connByTab.delete(id);
        try { chrome.storage.session.remove([CONFIG.detective.storageKeys.mainFramePrefix + id, CONFIG.detective.storageKeys.connectionsPrefix + id]); } catch (_) {}
      });
    } catch (e) { console.warn("MeMik detective listeners", e); }
  }

  /* ------------------------------------------------------------------ *
   *  Orchestration
   * ------------------------------------------------------------------ */
  async function askContent(tabId, mode) {
    const send = () => chrome.tabs.sendMessage(tabId, { type: "detectiveScan", mode }, { frameId: 0 });
    try { return await withTimeout(send(), CONFIG.detective.timeouts.contentScanMs, "The page took too long to scan."); }
    catch (_) {
      await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ["src/features/detective/content/page-scanner.js"] });
      return await withTimeout(send(), CONFIG.detective.timeouts.contentScanMs, "The page took too long to scan.");
    }
  }

  async function headersFor(tab) {
    const u = new URL(tab.url);
    const rec = await getMain(tab.id);
    if (rec && rec.origin === u.origin && rec.headers) {
      return { headers: rec.headers, setCookies: rec.setCookies || [], cookiesKnown: true, source: "browser", ip: rec.ip || "", status: rec.status };
    }
    // Fallback: a safe HEAD request (never GET: some URLs have side effects).
    const tryHead = async url => {
      const r = await fetchTimeout(url, { method: "HEAD", credentials: "omit", cache: "no-store", redirect: "follow" }, CONFIG.detective.timeouts.headFallbackMs);
      const list = []; r.headers.forEach((v, k) => list.push({ name: k, value: v }));
      return { r, nh: normHeaders(list) };
    };
    try {
      let { r, nh } = await tryHead(tab.url);
      let source = "head";
      if (r.status === 405 || r.status === 501) { ({ r, nh } = await tryHead(u.origin + "/")); source = "origin"; }
      return { headers: nh.map, setCookies: [], cookiesKnown: false, source, ip: "", status: r.status };
    } catch (_) {
      try {
        const { r, nh } = await tryHead(u.origin + "/");
        return { headers: nh.map, setCookies: [], cookiesKnown: false, source: "origin", ip: "", status: r.status };
      } catch (_2) { return null; }
    }
  }

  async function securityTxt(origin) {
    try {
      const r = await fetchTimeout(origin + CONFIG.detective.securityTxtPath, { method: "GET", credentials: "omit", cache: "no-store", redirect: "follow" }, CONFIG.detective.timeouts.securityTxtMs);
      if (!r.ok) return false;
      const t = (await r.text()).slice(0, 4000);
      return /^\s*Contact:/im.test(t);
    } catch (_) { return false; }
  }

  async function run(msg) {
    const mode = String(msg.mode || "all");
    let tabId = msg.tabId;
    if (tabId == null) tabId = (await chrome.tabs.query({ active: true, currentWindow: true }))[0]?.id;
    if (tabId == null) throw new Error("No active tab found.");
    const tab = await chrome.tabs.get(tabId);
    if (!/^https?:/i.test(tab.url || "")) throw new Error("Open a normal http(s) page first. Browser pages cannot be scanned.");

    let reply;
    try { reply = await askContent(tabId, mode); }
    catch (e) {
      throw new Error(/Cannot access|extensions gallery|Receiving end|Missing host/i.test(String(e && e.message))
        ? "Chrome does not allow scanning this page (for example the Chrome Web Store)."
        : (e && e.message) || "Scan failed.");
    }
    if (!reply || !reply.ok) throw new Error((reply && reply.error) || "Scan failed.");

    const wantsNet = !MODE_CATS[mode] || MODE_CATS[mode].some(c => ["https", "headers", "csp", "cookies", "tech"].includes(c));
    const net = wantsNet ? await headersFor(tab) : null;
    const report = buildReport({ mode, dom: reply.result, net, url: tab.url, netRequested: wantsNet });
    if (wantsNet && (mode === "all" || mode === "headers") && /^https:/i.test(tab.url)) {
      const has = await securityTxt(new URL(tab.url).origin);
      report.findings.push(has
        ? mk("headers", "sectxt-pass", "pass", "confirmed", "Has a security.txt contact file", "", "", "", "https://securitytxt.org/")
        : mk("headers", "sectxt-missing", "info", "confirmed", "No security.txt file",
            "A security.txt file tells researchers how to report problems to you.", "Optional: publish /.well-known/security.txt with a Contact: line.", "", "https://securitytxt.org/"));
      report.counts = scoreFindings(report.findings).counts;
      report.findings = sortFindings(report.findings);
    }
    return report;
  }

  async function siteInfo(msg) {
    let tabId = msg.tabId;
    if (tabId == null) tabId = (await chrome.tabs.query({ active: true, currentWindow: true }))[0]?.id;
    const tab = await chrome.tabs.get(tabId);
    if (!/^https?:/i.test(tab.url || "")) throw new Error("Open a normal http(s) page first.");
    const u = new URL(tab.url);
    const rec = await getMain(tabId);
    const conn = await getConn(tabId);
    const h = rec && rec.origin === u.origin ? rec.headers : null;
    const proxied = await isProxied();
    let dns = null, dnsError = "";
    try { dns = await resolveHost(u.hostname); } catch (e) { dnsError = e.message; }

    const mainIp = (rec && rec.origin === u.origin && rec.ip) || (conn.get(u.hostname) && conn.get(u.hostname).ip) || "";
    const first = u.hostname.split(".").slice(-2).join(".");
    const connections = Array.from(conn.entries()).map(([host, v]) => ({
      host, ip: v.ip || "", count: v.count, types: Array.from(v.types),
      thirdParty: !(host === u.hostname || host.endsWith("." + first))
    })).sort((a, b) => (a.host === u.hostname ? -1 : b.host === u.hostname ? 1 : b.count - a.count));

    return {
      ok: true,
      url: tab.url, host: u.hostname, https: u.protocol === "https:",
      connectedIp: mainIp,
      connectedIpPrivate: mainIp ? isPrivateIp(mainIp) : false,
      proxied,
      dns: dns ? { a: dns.a, aaaa: dns.aaaa, cname: dns.cname, resolver: dns.resolver } : null,
      dnsError,
      cdn: cdnHint(h),
      server: h ? (h["server"] || "") : "",
      connections,
      connectionsNote: rec ? "" : "Reload the page to start recording connections."
    };
  }

  /* ------------------------------------------------------------------ *
   *  Message router (called from background.js)
   * ------------------------------------------------------------------ */
  async function handle(msg) {
    switch (msg && msg.type) {
      case "detectiveRun": return await run(msg);
      case "detectiveSiteInfo": return await siteInfo(msg);
      case "detectiveVisitedGet": {
        const { [LOG_KEY]: detLogVisits, [VISIT_KEY]: list } = await chrome.storage.local.get({ [LOG_KEY]: false, [VISIT_KEY]: [] });
        return { ok: true, enabled: !!detLogVisits, list: Array.isArray(list) ? list : [] };
      }
      case "detectiveVisitedSet": {
        await chrome.storage.local.set({ [LOG_KEY]: !!msg.enabled });
        return { ok: true };
      }
      case "detectiveVisitedClear": {
        await visitChain;
        await chrome.storage.local.set({ [VISIT_KEY]: [] });
        return { ok: true };
      }
      case "detectivePortStart": {
        let headers = null;
        try { if (msg.tabId != null) { const r = await getMain(msg.tabId); if (r) headers = r.headers; } } catch (_) {}
        return await startPortScan(Object.assign({}, msg, { headers }));
      }
      case "detectivePortCancel": return cancelPortScan();
      case "detectiveLookup": {
        const r = await resolveHost(msg.host);
        return { ok: true, dns: { a: r.a, aaaa: r.aaaa, cname: r.cname, resolver: r.resolver } };
      }
      default: return undefined;
    }
  }

  registerListeners();

  // Self-register with the shared message-passing API (shared/api-router.js) rather than
  // adding cases to background.js's switch — see docs/ARCHITECTURE.md § "Scalable API
  // structure" for why new modules should do it this way.
  if (!isNode && typeof ApiRouter !== "undefined" && typeof MSG !== "undefined") {
    ApiRouter.register(
      [MSG.DETECTIVE_RUN, MSG.DETECTIVE_SITE_INFO, MSG.DETECTIVE_VISITED_GET, MSG.DETECTIVE_VISITED_SET,
       MSG.DETECTIVE_VISITED_CLEAR, MSG.DETECTIVE_PORT_START, MSG.DETECTIVE_PORT_CANCEL, MSG.DETECTIVE_LOOKUP],
      (message, sender) => handle(message, sender),
      "detective"
    );
  }

  const api = {
    VERSION, LEVELS, LEVEL_W, CONF_M, CAT_LABEL, MODE_CATS, PORTS, PORT_PRESETS, CHROME_BLOCKED,
    mk, scoreFindings, verdictFor, topFixes, sortFindings, normHeaders, parseCsp, analyzeCsp, parseSetCookie,
    analyzeCookies, analyzeHeaders, techFromHeaders, cdnHint, buildReport, cleanTarget, isPrivateIp, isIPv4,
    parsePortList, classifyProbe, portFinding, summarizePortScan, handle
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.MemikDetective = api;
})(typeof self !== "undefined" ? self : globalThis);
