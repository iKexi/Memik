/**
 * popup/components/security-hub.js — the "next level" additions to the Security tab:
 *
 *   1. Protection score   — a live 0-100 score with the single best next step.
 *   2. What to block      — per-category ad-block switches (ads, trackers, malware,
 *                           annoyances, platform ads & analytics).
 *   3. Privacy hardening  — browser-level switches through chrome.privacy (WebRTC IP leak
 *                           protection, third-party cookies, hyperlink auditing, ad-privacy
 *                           APIs, Do Not Track).
 *   4. Password tools     — local strength meter + cryptographic password generator that
 *                           feeds the existing breach check. Nothing is sent while typing.
 *
 * Plain script, exposes a single global: `SecurityHub`.
 */
(function (root) {
  "use strict";
  const doc = typeof document !== "undefined" ? document : null;
  const $ = id => doc.getElementById(id);

  /* ------------------------------------------------------------------ data */
  const CATEGORIES = [
    { id: "ads", title: "Ads", sub: "Banners, video ads and pop-unders" },
    { id: "trackers", title: "Trackers", sub: "Analytics, fingerprinting and telemetry" },
    { id: "malware", title: "Malware & phishing", sub: "Known dangerous and scam sites" },
    { id: "annoyances", title: "Annoyances", sub: "Overlays, cookie nags, notification prompts" }
  ];

  // Each hardening item knows how to read, apply and undo itself.
  // `settings` are chrome.privacy setting getters resolved lazily (API may be missing on some browsers).
  const PRIVACY = [
    {
      id: "webrtc", title: "Block WebRTC IP leaks",
      sub: "Stops sites discovering your real IP behind a proxy or VPN",
      settings: () => [chrome.privacy.network.webRTCIPHandlingPolicy],
      on: "disable_non_proxied_udp", isOn: v => v === "disable_non_proxied_udp" || v === "proxy_only"
    },
    {
      id: "cookies", title: "Block third-party cookies",
      sub: "Cuts cross-site tracking at the source",
      settings: () => [chrome.privacy.websites.thirdPartyCookiesAllowed],
      on: false, isOn: v => v === false
    },
    {
      id: "audit", title: "Disable hyperlink auditing",
      sub: "Stops silent “ping” beacons sent when you click links",
      settings: () => [chrome.privacy.websites.hyperlinkAuditingEnabled],
      on: false, isOn: v => v === false
    },
    {
      id: "adapis", title: "Turn off ad-privacy APIs",
      sub: "Topics, Protected Audience and ad measurement profiling",
      settings: () => [
        chrome.privacy.websites.topicsEnabled,
        chrome.privacy.websites.fledgeEnabled,
        chrome.privacy.websites.adMeasurementEnabled
      ].filter(Boolean),
      on: false, isOn: v => v === false
    },
    {
      id: "dnt", title: "Send “Do Not Track”",
      sub: "Asks sites not to follow you (honoured by some)",
      settings: () => [chrome.privacy.websites.doNotTrackEnabled],
      on: true, isOn: v => v === true
    }
  ];

  const WEIGHTS = { adblock: 25, categories: 20, privacy: 40, proxy: 15 };

  /* --------------------------------------------------------- tiny promisers */
  const storageGet = keys => new Promise(res => { try { chrome.storage.local.get(keys, r => res(r || {})); } catch (_) { res({}); } });
  const storageSet = obj => new Promise(res => { try { chrome.storage.local.set(obj, () => res()); } catch (_) { res(); } });
  const apiGet = s => new Promise(res => { try { s.get({}, d => res(chrome.runtime.lastError ? null : d)); } catch (_) { res(null); } });
  const apiSet = (s, value) => new Promise(res => { try { s.set({ value }, () => res(!chrome.runtime.lastError)); } catch (_) { res(false); } });
  const apiClear = s => new Promise(res => { try { s.clear({}, () => res(!chrome.runtime.lastError)); } catch (_) { res(false); } });

  const hasPrivacy = () => typeof chrome !== "undefined" && !!chrome.privacy && !!chrome.privacy.websites && !!chrome.privacy.network;

  /* ------------------------------------------------------------------ state */
  const hub = {
    cats: {},          // id -> bool
    priv: {},          // id -> { on, locked, available }
    adblock: true,
    popupsOnly: false,
    proxy: false
  };

  async function readPrivacy() {
    for (const item of PRIVACY) {
      let list = [];
      try { list = hasPrivacy() ? item.settings() : []; } catch (_) { list = []; }
      if (!list.length) { hub.priv[item.id] = { on: false, locked: true, available: false }; continue; }
      const results = await Promise.all(list.map(apiGet));
      const ok = results.filter(Boolean);
      if (!ok.length) { hub.priv[item.id] = { on: false, locked: true, available: false }; continue; }
      const on = ok.every(r => item.isOn(r.value));
      const locked = ok.some(r => r.levelOfControl === "not_controllable" || r.levelOfControl === "controlled_by_other_extensions");
      hub.priv[item.id] = { on, locked, available: true };
    }
  }

  async function readCore() {
    const d = await storageGet({ adblockEnabled: true, blockPopupsOnly: false, adblockCategories: {}, proxyEnabled: false });
    hub.adblock = d.adblockEnabled !== false;
    hub.popupsOnly = !!d.blockPopupsOnly;
    hub.proxy = !!d.proxyEnabled;
    const stored = d.adblockCategories && typeof d.adblockCategories === "object" ? d.adblockCategories : {};
    for (const c of CATEGORIES) hub.cats[c.id] = stored[c.id] !== false;
  }

  /* ------------------------------------------------------------------ score */
  function computeScore() {
    let score = 0;
    const tips = [];
    if (hub.adblock && !hub.popupsOnly) score += WEIGHTS.adblock;
    else if (hub.adblock) { score += WEIGHTS.adblock * 0.4; tips.push({ w: 10, text: "Turn off “Block pop-ups only” for full ad and tracker blocking." }); }
    else tips.push({ w: WEIGHTS.adblock, text: "Turn on Threat Protection to block ads, trackers and malicious sites." });

    const catOn = CATEGORIES.filter(c => hub.cats[c.id]).length;
    score += WEIGHTS.categories * (catOn / CATEGORIES.length);
    const offCats = CATEGORIES.filter(c => !hub.cats[c.id]);
    if (offCats.length) tips.push({ w: WEIGHTS.categories * offCats.length / CATEGORIES.length, text: `Enable “${offCats[0].title}” blocking.` });

    const avail = PRIVACY.filter(p => hub.priv[p.id] && hub.priv[p.id].available);
    const per = avail.length ? WEIGHTS.privacy / avail.length : 0;
    for (const p of avail) {
      if (hub.priv[p.id].on) score += per;
      else tips.push({ w: per, text: `${p.title}.` });
    }

    if (hub.proxy) score += WEIGHTS.proxy;
    else tips.push({ w: WEIGHTS.proxy * 0.6, text: "Connect to a server to hide your IP address (optional)." });

    tips.sort((a, b) => b.w - a.w);
    return { score: Math.round(Math.min(100, score)), tip: tips[0] ? tips[0].text : "" };
  }

  function labelFor(n) {
    if (n >= 85) return { text: "Strong protection", level: "good" };
    if (n >= 60) return { text: "Good protection", level: "ok" };
    if (n >= 35) return { text: "Partly protected", level: "warn" };
    return { text: "At risk", level: "bad" };
  }

  function renderScore() {
    const ring = $("shRing"); if (!ring) return;
    const { score, tip } = computeScore();
    const lab = labelFor(score);
    ring.style.setProperty("--p", String(score));
    ring.setAttribute("data-level", lab.level);
    const num = $("shScoreNum"); if (num) num.textContent = String(score);
    const l = $("shScoreLabel"); if (l) l.textContent = lab.text;
    const h = $("shScoreHint"); if (h) h.textContent = tip ? `Next step: ${tip}` : "Everything recommended is switched on.";
    const btn = $("shHardenBtn"); if (btn) btn.classList.toggle("hidden", !tip || /optional/.test(tip) && score >= 85);
  }

  /* ------------------------------------------------------------------ rows */
  function rowHtml(id, title, sub, checked, disabled, note) {
    const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    return `<div class="nv-feature sh-row" data-sh="${esc(id)}">
      <div class="nv-feature-text"><div class="nv-feature-title">${esc(title)}</div><div class="nv-feature-sub">${esc(note || sub)}</div></div>
      <label class="switch"><input type="checkbox" ${checked ? "checked" : ""} ${disabled ? "disabled" : ""} aria-label="${esc(title)}"><span class="slider"></span></label>
    </div>`;
  }

  function renderCats() {
    const box = $("shCats"); if (!box) return;
    const masterOff = !hub.adblock;
    box.innerHTML = CATEGORIES.map(c => rowHtml("cat:" + c.id, c.title, c.sub, hub.cats[c.id], masterOff,
      masterOff ? "Turn on Threat Protection first" : "")).join("");
  }

  function renderPriv() {
    const box = $("shPriv"); if (!box) return;
    if (!hasPrivacy()) { box.innerHTML = '<p class="nv-hint left">The browser privacy API is not available here.</p>'; return; }
    box.innerHTML = PRIVACY.map(p => {
      const st = hub.priv[p.id] || { on: false, locked: true, available: false };
      let note = "";
      if (!st.available) note = "Not supported by this browser";
      else if (st.locked) note = "Controlled by another extension or your administrator";
      return rowHtml("priv:" + p.id, p.title, p.sub, st.on, st.locked, note);
    }).join("");
  }

  /* ---------------------------------------------------------------- actions */
  async function setCategory(id, on) {
    hub.cats[id] = !!on;
    await storageSet({ adblockCategories: Object.assign({}, hub.cats) });
    try { await chrome.runtime.sendMessage({ type: "adblockSettingsChanged" }); } catch (_) {}
    renderScore();
  }

  async function setPrivacy(id, on) {
    const item = PRIVACY.find(p => p.id === id); if (!item) return false;
    let list = []; try { list = item.settings(); } catch (_) {}
    let ok = true;
    for (const s of list) {
      // Turning a protection off restores the browser default instead of forcing the opposite value.
      ok = (on ? await apiSet(s, item.on) : await apiClear(s)) && ok;
    }
    await readPrivacy();
    renderPriv(); renderScore();
    return ok;
  }

  async function applyRecommended() {
    const btn = $("shHardenBtn"); if (btn) btn.disabled = true;
    try {
      if (!hub.adblock || hub.popupsOnly) {
        hub.adblock = true; hub.popupsOnly = false;
        await storageSet({ adblockEnabled: true, antiAdblockEnabled: true, blockPopupsOnly: false });
      }
      for (const c of CATEGORIES) hub.cats[c.id] = true;
      await storageSet({ adblockCategories: Object.assign({}, hub.cats) });
      try { await chrome.runtime.sendMessage({ type: "adblockSettingsChanged", enabled: true, blockPopupsOnly: false }); } catch (_) {}
      for (const p of PRIVACY) {
        const st = hub.priv[p.id];
        if (st && st.available && !st.locked && !st.on) await setPrivacy(p.id, true);
      }
      await refresh();
      if (root.say) root.say("Recommended protection applied.", "ok");
    } finally { if (btn) btn.disabled = false; }
  }

  function bind() {
    const cats = $("shCats");
    if (cats) cats.addEventListener("change", async e => {
      const row = e.target.closest("[data-sh]"); if (!row) return;
      const id = row.getAttribute("data-sh").replace(/^cat:/, "");
      await setCategory(id, e.target.checked);
      if (root.say) root.say(`${(CATEGORIES.find(c => c.id === id) || {}).title || id} blocking ${e.target.checked ? "on" : "off"}.`, "ok");
    });
    const priv = $("shPriv");
    if (priv) priv.addEventListener("change", async e => {
      const row = e.target.closest("[data-sh]"); if (!row) return;
      const id = row.getAttribute("data-sh").replace(/^priv:/, "");
      const ok = await setPrivacy(id, e.target.checked);
      if (!ok && root.say) root.say("The browser refused that change.", "error");
    });
    const harden = $("shHardenBtn"); if (harden) harden.addEventListener("click", applyRecommended);
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if ("adblockEnabled" in changes || "blockPopupsOnly" in changes || "adblockCategories" in changes || "proxyEnabled" in changes) refresh();
      });
    } catch (_) {}
  }

  async function refresh() {
    await Promise.all([readCore(), readPrivacy()]);
    renderCats(); renderPriv(); renderScore();
  }

  /* ---------------------------------------------------------- password tools */
  const COMMON = ["password", "passw0rd", "qwerty", "letmein", "welcome", "admin", "login", "iloveyou", "monkey", "dragon",
    "football", "abc123", "123456", "111111", "000000", "changeme", "secret", "master", "sunshine", "princess"];

  function estimate(pw) {
    if (!pw) return { bits: 0, label: "", level: "none", notes: [] };
    let pool = 0;
    if (/[a-z]/.test(pw)) pool += 26;
    if (/[A-Z]/.test(pw)) pool += 26;
    if (/\d/.test(pw)) pool += 10;
    if (/[^A-Za-z0-9]/.test(pw)) pool += 33;
    let bits = pw.length * Math.log2(Math.max(pool, 2));
    const notes = [];
    const lower = pw.toLowerCase();
    if (COMMON.some(w => lower.includes(w))) { bits *= 0.4; notes.push("contains a very common word"); }
    if (/(.)\1{2,}/.test(pw)) { bits *= 0.8; notes.push("repeated characters"); }
    if (/(0123|1234|2345|3456|4567|5678|6789|abcd|bcde|cdef|qwer|asdf|zxcv)/i.test(pw)) { bits *= 0.75; notes.push("keyboard or number sequence"); }
    if (/^[a-z]+\d{1,4}$/i.test(pw)) { bits *= 0.8; notes.push("word followed by digits"); }
    if (pw.length < 10) notes.push("short — aim for 14+ characters");
    bits = Math.max(0, Math.round(bits));
    let label, level;
    if (bits < 28) { label = "Very weak"; level = "bad"; }
    else if (bits < 40) { label = "Weak"; level = "warn"; }
    else if (bits < 60) { label = "Fair"; level = "fair"; }
    else if (bits < 80) { label = "Strong"; level = "ok"; }
    else { label = "Excellent"; level = "good"; }
    return { bits, label, level, notes };
  }

  function renderMeter() {
    const input = $("breachPassword"); const bar = $("pwMeterBar"); const text = $("pwMeterText"); if (!input || !bar || !text) return;
    const r = estimate(input.value);
    bar.style.width = r.level === "none" ? "0%" : Math.min(100, Math.round(r.bits / 100 * 100)) + "%";
    bar.setAttribute("data-level", r.level);
    text.textContent = r.level === "none"
      ? "Type a password to see its strength. Nothing is sent anywhere while you type."
      : `${r.label} · about ${r.bits} bits` + (r.notes.length ? ` · ${r.notes.join(", ")}` : "");
  }

  function generate(len, symbols, avoidAmbiguous) {
    let lower = "abcdefghijkmnopqrstuvwxyz", upper = "ABCDEFGHJKLMNPQRSTUVWXYZ", digits = "23456789", sym = "!@#$%^&*-_=+?";
    if (!avoidAmbiguous) { lower += "l"; upper += "IO"; digits += "01"; }
    const sets = [lower, upper, digits]; if (symbols) sets.push(sym);
    const all = sets.join("");
    const rnd = max => { // unbiased random int in [0, max)
      const lim = Math.floor(0x100000000 / max) * max; const buf = new Uint32Array(1);
      do { crypto.getRandomValues(buf); } while (buf[0] >= lim);
      return buf[0] % max;
    };
    const out = sets.map(s => s[rnd(s.length)]); // guarantee one of each class
    while (out.length < len) out.push(all[rnd(all.length)]);
    for (let i = out.length - 1; i > 0; i--) { const j = rnd(i + 1); [out[i], out[j]] = [out[j], out[i]]; }
    return out.join("");
  }

  function bindPasswordTools() {
    const pw = $("breachPassword");
    if (pw) pw.addEventListener("input", renderMeter);
    const show = $("pwShowBtn");
    if (show && pw) show.addEventListener("click", () => {
      const reveal = pw.type === "password"; pw.type = reveal ? "text" : "password"; show.textContent = reveal ? "Hide" : "Show";
    });
    const len = $("pwGenLen"), lenOut = $("pwGenLenOut");
    const sync = () => { if (len && lenOut) lenOut.textContent = len.value; };
    if (len) len.addEventListener("input", sync); sync();
    const gen = () => {
      const out = $("pwGenOut"); if (!out) return;
      out.value = generate(+(len ? len.value : 20) || 20, !!($("pwGenSymbols") || {}).checked, !!($("pwGenAmbig") || {}).checked);
    };
    const genBtn = $("pwGenBtn"); if (genBtn) genBtn.addEventListener("click", gen);
    const copy = $("pwGenCopy");
    if (copy) copy.addEventListener("click", async () => {
      const out = $("pwGenOut"); if (!out || !out.value) { gen(); }
      try { await navigator.clipboard.writeText($("pwGenOut").value); if (root.say) root.say("Password copied.", "ok"); }
      catch (_) { if (root.say) root.say("Could not copy — select the text and copy manually.", "error"); }
    });
    const check = $("pwGenCheck");
    if (check) check.addEventListener("click", () => {
      const out = $("pwGenOut"); if (!out || !out.value) gen();
      if (pw) { pw.value = $("pwGenOut").value; renderMeter(); }
      const btn = $("pwnedPassBtn"); if (btn) btn.click();
    });
    renderMeter();
  }

  /* ------------------------------------------------------------------- init */
  async function init() {
    if (!doc) return;
    bind();
    bindPasswordTools();
    await refresh();
  }

  const SecurityHub = { init, refresh, estimate, generate, computeScore, CATEGORIES, PRIVACY };
  if (typeof module !== "undefined" && module.exports) module.exports = SecurityHub;
  else root.SecurityHub = SecurityHub;
})(typeof window !== "undefined" ? window : globalThis);
