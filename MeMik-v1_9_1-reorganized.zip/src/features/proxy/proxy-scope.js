// Shared helpers for proxy rotation (scoped or global).
// Loaded by background.js (importScripts) and popup.html (<script>).
(function (root) {
  "use strict";

  function normalizeOrigin(raw) {
    const text = String(raw || "").trim();
    if (!text) return null;
    try {
      const u = new URL(text.includes("://") ? text : "https://" + text);
      if (!/^https?:$/.test(u.protocol)) return null;
      if (u.username || u.password) return null;
      return u.origin;
    } catch (_) {
      return null;
    }
  }

  function hostnameOf(raw) {
    const origin = normalizeOrigin(raw);
    if (!origin) return null;
    try { return new URL(origin).hostname.toLowerCase(); } catch (_) { return null; }
  }

  function extractDomain(raw) {
    let host = hostnameOf(raw) || String(raw || "").trim().toLowerCase();
    if (!host) return null;
    try {
      if (host.includes("://")) host = new URL(host).hostname.toLowerCase();
    } catch (_) {}
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":")) return host;
    const parts = host.split(".");
    if (parts.length <= 2) return host;
    const secondLast = parts[parts.length - 2];
    if (["co", "com", "org", "net", "gov", "edu", "ac"].includes(secondLast) && parts.length > 2) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }

  function directiveFor(proxy) {
    if (!proxy) return "DIRECT";
    if (proxy.scheme === "socks5") return `SOCKS5 ${proxy.host}:${proxy.port}; SOCKS ${proxy.host}:${proxy.port}`;
    if (proxy.scheme === "https") return `HTTPS ${proxy.host}:${proxy.port}; PROXY ${proxy.host}:${proxy.port}`;
    if (proxy.scheme === "socks4") return `SOCKS ${proxy.host}:${proxy.port}`;
    return `PROXY ${proxy.host}:${proxy.port}`;
  }

  /**
   * PAC: if globalMode, all non-local traffic goes through the proxy.
   * Otherwise only hostname (+ subdomains) uses the proxy.
   * SOCKS5 is preferred for remote DNS (helps when local DNS is censored).
   */
  function buildPacScript(hostname, proxy, globalMode, directHosts) {
    const directive = JSON.stringify(directiveFor(proxy));
    const direct = JSON.stringify(Array.isArray(directHosts) ? directHosts.map(h => String(h).toLowerCase()) : []);
    const head = [
      "function FindProxyForURL(url, host) {",
      "  host = (host || '').toLowerCase();",
      `  var direct = ${direct};`,
      "  for (var i = 0; i < direct.length; i++) { if (host === direct[i]) return 'DIRECT'; }",
      "  if (host === 'localhost' || host === '127.0.0.1' || host === '[::1]' || host === '::1') return 'DIRECT';",
      "  if (isPlainHostName(host)) return 'DIRECT';"
    ];
    if (globalMode) {
      return head.concat([`  return ${directive};`, "}"]).join("\n");
    }
    const rawList = (Array.isArray(hostname) ? hostname : [hostname])
      .map(h => String(h || "").toLowerCase().trim())
      .filter(Boolean);
    const hostSet = new Set();
    rawList.forEach(h => {
      hostSet.add(h);
      const dom = extractDomain(h);
      if (dom) hostSet.add(dom);
    });
    const targets = JSON.stringify(Array.from(hostSet));
    return head.concat([
      `  var targets = ${targets};`,
      "  if (!targets.length) return 'DIRECT';",
      "  for (var i = 0; i < targets.length; i++) {",
      "    var t = targets[i];",
      '    if (host === t || host.slice(-(t.length + 1)) === "." + t) {',
      `      return ${directive};`,
      "    }",
      "  }",
      '  return "DIRECT";',
      "}"
    ]).join("\n");
  }

  // PAC that sends each probe hostname ("lane") through its own proxy so several servers can be
  // tested at the same time. No DIRECT fallback inside a lane: a dead proxy must fail, not leak.
  function buildLanePac(laneMap, fallback, directHosts) {
    const direct = JSON.stringify((directHosts || []).map(h => String(h).toLowerCase()));
    return [
      "function FindProxyForURL(url, host) {",
      "  host = (host || '').toLowerCase();",
      `  var direct = ${direct};`,
      "  for (var i = 0; i < direct.length; i++) { if (host === direct[i]) return 'DIRECT'; }",
      `  var lanes = ${JSON.stringify(laneMap)};`,
      "  if (Object.prototype.hasOwnProperty.call(lanes, host)) return lanes[host];",
      "  if (host === 'localhost' || host === '127.0.0.1' || host === '[::1]' || isPlainHostName(host)) return 'DIRECT';",
      `  return ${JSON.stringify(fallback || "DIRECT")};`,
      "}"
    ].join("\n");
  }

  root.ProxyScope = { normalizeOrigin, hostnameOf, extractDomain, buildPacScript, directiveFor, buildLanePac };
  if (typeof module !== "undefined") module.exports = root.ProxyScope;
})(globalThis);
