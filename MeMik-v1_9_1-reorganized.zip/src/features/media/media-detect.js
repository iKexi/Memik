/**
 * content/media-detect.js — finds playable media on the page the user has open.
 * Injected declaratively on every page (manifest content_scripts) and also on demand
 * by background/media.js if it has not run yet. Replies to a `mediaDetect` runtime
 * message with video/audio/HLS URLs found in the DOM; never downloads anything itself.
 */
(function () {
  "use strict";
  if (window.__memikMediaDetect) return;
  window.__memikMediaDetect = true;

  function absUrl(u) { try { return new URL(u, location.href).href; } catch (_) { return ""; } }
  function sniffType(url, el) {
    const u = (url || "").toLowerCase();
    if (/\.m3u8(\?|$)/.test(u)) return "hls";
    if (/\.mpd(\?|$)/.test(u)) return "dash";
    if (/\.(mp3|m4a|aac|ogg|wav)(\?|$)/.test(u)) return "audio";
    if (/\.(mp4|webm|mkv|mov|ts|m4s|flv)(\?|$)/.test(u)) return "video";
    if (el && el.tagName === "AUDIO") return "audio";
    if (el && el.tagName === "VIDEO") return "video";
    return "video";
  }

  /* ---------------- Playback Speed Management ---------------- */
  let currentSpeed = 1;
  let speedControlEnabled = true;
  let isApplying = false;

  function enforceSpeed(el) {
    if (!el || !(el instanceof HTMLMediaElement)) return;
    if (isApplying) return;
    isApplying = true;
    try {
      if (!speedControlEnabled) {
        if (el.playbackRate !== 1) el.playbackRate = 1;
      } else {
        const targetRate = Math.min(4, Math.max(0.25, Number(currentSpeed) || 1));
        if (Math.abs(el.playbackRate - targetRate) > 0.01) {
          el.playbackRate = targetRate;
        }
      }
    } catch (_) {}
    finally { isApplying = false; }
  }

  function enforceAll() {
    try {
      document.querySelectorAll("video, audio").forEach(enforceSpeed);
    } catch (_) {}
  }

  // Load initial settings and synchronize
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get({ mediaSpeed: 1, mediaSpeedEnabled: true }, res => {
      if (res) {
        if (res.mediaSpeed != null) currentSpeed = Math.min(4, Math.max(0.25, Number(res.mediaSpeed) || 1));
        if (typeof res.mediaSpeedEnabled === "boolean") speedControlEnabled = res.mediaSpeedEnabled;
        enforceAll();
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      let changed = false;
      if ("mediaSpeed" in changes) {
        currentSpeed = Math.min(4, Math.max(0.25, Number(changes.mediaSpeed.newValue) || 1));
        changed = true;
      }
      if ("mediaSpeedEnabled" in changes) {
        speedControlEnabled = changes.mediaSpeedEnabled.newValue !== false;
        changed = true;
      }
      if (changed) enforceAll();
    });
  }

  // Auto-enforce during video playback
  document.addEventListener("play", e => enforceSpeed(e.target), true);
  document.addEventListener("playing", e => enforceSpeed(e.target), true);
  document.addEventListener("loadedmetadata", e => enforceSpeed(e.target), true);
  document.addEventListener("ratechange", e => {
    if (isApplying) return;
    if (speedControlEnabled && e.target instanceof HTMLMediaElement) {
      const targetRate = Math.min(4, Math.max(0.25, Number(currentSpeed) || 1));
      if (Math.abs(e.target.playbackRate - targetRate) > 0.01) {
        enforceSpeed(e.target);
      }
    }
  }, true);

  /* ---------------- Media Detection ---------------- */
  function collect() {
    const seen = new Set();
    const items = [];
    function add(url, meta) {
      const href = absUrl(url);
      if (!href || !/^https?:/i.test(href)) return;
      if (seen.has(href)) return;
      seen.add(href);
      meta = meta || {};
      items.push({
        url: href,
        type: meta.type || sniffType(href, meta.el),
        label: meta.label || href.split("/").pop().split("?")[0] || href,
        width: meta.width || 0,
        height: meta.height || 0
      });
    }

    // 1. DOM Video and Audio elements
    document.querySelectorAll("video, audio").forEach((el, i) => {
      const src = el.currentSrc || el.src;
      if (src) add(src, {
        el,
        label: el.getAttribute("title") || (el.tagName.toLowerCase() + " " + (i + 1)),
        width: el.videoWidth || 0,
        height: el.videoHeight || 0
      });
      el.querySelectorAll("source[src]").forEach(s => add(s.getAttribute("src"), { el }));
    });

    // 2. Direct media links and sources in page
    document.querySelectorAll("source[src], a[href]").forEach(el => {
      const href = el.getAttribute("src") || el.getAttribute("href") || "";
      if (/\.(mp4|webm|mkv|mov|m3u8|mpd|ts|m4s|mp3|m4a|aac|ogg|wav|flv)(\?|$)/i.test(href)) add(href, {});
    });

    // 3. Embedded Video iframes (YouTube, Vimeo, etc.)
    document.querySelectorAll("iframe[src]").forEach(fr => {
      const src = fr.getAttribute("src") || "";
      if (/youtube\.com\/embed\/|player\.vimeo\.com\/video\/|dailymotion\.com\/embed\//i.test(src)) {
        add(src, { type: "video", label: "Embedded video" });
      }
    });

    // 4. Resource timing entries (network-loaded video streams)
    try {
      if (typeof performance !== "undefined" && performance.getEntriesByType) {
        performance.getEntriesByType("resource").forEach(entry => {
          const name = entry.name || "";
          if (/\.(mp4|webm|mkv|mov|m3u8|mpd|ts|m4s|mp3|m4a|aac|ogg|wav|flv)(\?|$)/i.test(name) ||
              entry.initiatorType === "video" || entry.initiatorType === "audio") {
            add(name, {});
          }
        });
      }
    } catch (_) {}

    // 5. OpenGraph and Twitter video metadata
    document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"], meta[name="twitter:player:stream"]').forEach(m => {
      const c = m.getAttribute("content");
      if (c) add(c, { type: "video", label: "Video stream" });
    });

    return { pageUrl: location.href, title: document.title || "", items: items.slice(0, 50), at: Date.now() };
  }

  let lastSig = "";
  function publish() {
    const result = collect();
    const sig = JSON.stringify(result.items.map(i => i.url));
    if (sig === lastSig) return result;
    lastSig = sig;
    chrome.storage.local.set({ mediaDetected: result }).catch(() => {});
    return result;
  }

  function applyPlayer(opts) {
    opts = opts || {};
    if (typeof opts.enabled === "boolean") {
      speedControlEnabled = opts.enabled;
    }
    if (opts.speed != null) {
      currentSpeed = Math.min(4, Math.max(0.25, Number(opts.speed) || 1));
    }
    enforceAll();

    const videos = [...document.querySelectorAll("video")];
    if (opts.pip && videos.length) {
      const el = videos[0];
      try {
        if (document.pictureInPictureElement) document.exitPictureInPicture();
        else if (el.requestPictureInPicture) el.requestPictureInPicture();
      } catch (e) { return { ok: false, error: e.message || String(e) }; }
    }
    return { ok: true, speed: currentSpeed, enabled: speedControlEnabled };
  }

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg && msg.type === "mediaDetect") {
      try { sendResponse({ ok: true, result: publish() }); }
      catch (e) { sendResponse({ ok: false, error: e.message || String(e) }); }
      return true;
    }
    if (msg && msg.type === "mediaPlayerControl") {
      sendResponse(applyPlayer(msg.opts || {}));
      return true;
    }
  });

  const run = () => { try { publish(); enforceAll(); } catch (_) {} };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run, { once: true });
  else run();
  new MutationObserver(() => run()).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src"] });
  setInterval(run, 4000);
})();
