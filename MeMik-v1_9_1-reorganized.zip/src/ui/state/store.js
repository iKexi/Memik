/**
 * popup/state/store.js — a tiny pub/sub store for popup UI state.
 *
 * Not a framework: just a plain object you can read, patch, and subscribe to, so
 * components don't need to know about each other to react to the same state. A
 * feature module creates one with `createStore(initial)` and exports it alongside its
 * component functions; see popup/state/detective-store.js for the reference usage.
 *
 * Plain script, exposes a single global: `createStore`.
 */
(function (root) {
  "use strict";

  /**
   * @param {object} initial - the starting state. Shallow-merged on every `set`/`patch`.
   * @returns {{
   *   get: () => object,
   *   set: (next: object) => object,
   *   patch: (partial: object) => object,
   *   subscribe: (fn: (state: object, prevState: object) => void) => () => void
   * }}
   */
  function createStore(initial) {
    let state = Object.assign({}, initial);
    const subscribers = new Set();

    function notify(prev) {
      subscribers.forEach(fn => {
        try { fn(state, prev); }
        catch (e) { if (typeof Logger !== "undefined") Logger.error("store", "subscriber threw", {}, e); }
      });
    }

    return {
      get: () => state,
      /** Replace the whole state (shallow) and notify subscribers. */
      set(next) { const prev = state; state = Object.assign({}, next); notify(prev); return state; },
      /** Merge `partial` into the state and notify subscribers. */
      patch(partial) { const prev = state; state = Object.assign({}, state, partial); notify(prev); return state; },
      /** Register a listener; returns an unsubscribe function. */
      subscribe(fn) { subscribers.add(fn); return () => subscribers.delete(fn); }
    };
  }

  if (typeof module !== "undefined" && module.exports) module.exports = { createStore };
  else root.createStore = createStore;
})(typeof window !== "undefined" ? window : globalThis);
