/**
 * shared/errors.js — typed errors and a centralized wrapper for message handlers.
 *
 * Every background message handler (the extension's internal "API") should either
 * return a plain object or throw. This module normalizes whatever gets thrown into
 * a consistent shape the caller can rely on: { ok: false, error, code }.
 *
 * Plain script, exposes globals: `AppError`, `toAppError`, `wrapHandler`.
 */
(function (root) {
  "use strict";

  /** An error with a stable machine-readable `code` plus a human `message`. */
  class AppError extends Error {
    constructor(code, message, cause) {
      super(message || code);
      this.name = "AppError";
      this.code = code || "unknown";
      if (cause) this.cause = cause;
    }
  }

  const CODES = {
    bad_request: "The request was missing something required.",
    not_found: "Nothing matched that request.",
    unsupported: "This isn't something the extension can do here.",
    permission: "This needs a permission that hasn't been granted.",
    network: "A network request failed.",
    timeout: "That took too long and was stopped.",
    unknown: "Something went wrong."
  };

  /** Turn anything a handler might throw into an AppError, without ever throwing itself. */
  function toAppError(err) {
    if (err instanceof AppError) return err;
    if (err instanceof Error) {
      // DOMException (AbortError from fetch timeouts) and friends land here too.
      const code = /timeout|abort/i.test(err.name + " " + err.message) ? "timeout" : "unknown";
      return new AppError(code, err.message || String(err), err);
    }
    return new AppError("unknown", typeof err === "string" ? err : "An unexpected error occurred.", err);
  }

  /**
   * Wrap a message handler so every call is timed, logged, and its errors normalized.
   * Never throws: resolves to either the handler's own result or a shaped error object.
   * @param {string} tag - log tag, usually the module name.
   * @param {string} type - the message type, used in logs only.
   * @param {(message, sender) => Promise<any>} handler
   */
  function wrapHandler(tag, type, handler) {
    return async function wrapped(message, sender) {
      const t0 = Date.now();
      try {
        const result = await handler(message, sender);
        if (typeof Logger !== "undefined") Logger.debug(tag, `${type} ok`, { ms: Date.now() - t0 });
        return result;
      } catch (err) {
        const e = toAppError(err);
        if (typeof Logger !== "undefined") Logger.error(tag, `${type} failed`, { ms: Date.now() - t0, code: e.code }, e);
        return { ok: false, error: e.message, code: e.code };
      }
    };
  }

  const api = { AppError, CODES, toAppError, wrapHandler };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else { root.AppError = AppError; root.toAppError = toAppError; root.wrapHandler = wrapHandler; root.ErrorCodes = CODES; }
})(typeof self !== "undefined" ? self : globalThis);
