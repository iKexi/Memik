/**
 * shared/api-router.js — a small registry for the extension's internal message API.
 *
 * Background.js's chrome.runtime.onMessage listener is the extension's single entry
 * point for requests from the popup and extension pages. Most existing handlers live
 * in one big switch statement there (left as-is: 50+ cases wired deep into proxy,
 * captcha and routine logic that this pass doesn't touch — see docs/ARCHITECTURE.md
 * for why). New modules should instead self-register a handler here, so adding a
 * feature never means growing that switch:
 *
 *   ApiRouter.register(MSG.DETECTIVE_RUN, MyModule.runScan);
 *
 * background.js's switch falls through to `ApiRouter.dispatch(type, message, sender)`
 * in its `default:` case, so both mechanisms resolve through the same response path
 * and the same centralized error handling (see shared/errors.js).
 *
 * Plain script, exposes a single global: `ApiRouter`.
 */
(function (root) {
  "use strict";
  const handlers = new Map();

  /**
   * Register a handler for one or more message types.
   * @param {string|string[]} type
   * @param {(message, sender) => Promise<any>} handler
   * @param {string} [tag] - log tag; defaults to the first type.
   */
  function register(type, handler, tag) {
    const types = Array.isArray(type) ? type : [type];
    const wrapped = typeof wrapHandler === "function" ? wrapHandler(tag || types[0], types[0], handler) : handler;
    types.forEach(t => {
      if (handlers.has(t) && typeof Logger !== "undefined") Logger.warn("api-router", `overwriting an existing handler for "${t}"`);
      handlers.set(t, wrapped);
    });
  }

  function has(type) { return handlers.has(type); }

  /** Run a registered handler. Throws "unsupported" if nothing is registered for `type`. */
  async function dispatch(type, message, sender) {
    const h = handlers.get(type);
    if (!h) {
      const e = typeof AppError === "function" ? new AppError("unsupported", "Unsupported request.") : new Error("Unsupported request.");
      throw e;
    }
    return h(message, sender);
  }

  function list() { return Array.from(handlers.keys()); }

  const ApiRouter = { register, has, dispatch, list };
  if (typeof module !== "undefined" && module.exports) module.exports = ApiRouter;
  else root.ApiRouter = ApiRouter;
})(typeof self !== "undefined" ? self : globalThis);
