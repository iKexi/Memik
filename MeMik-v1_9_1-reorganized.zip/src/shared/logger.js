/**
 * shared/logger.js — tiny leveled logger used across background, content and popup.
 *
 * Plain script (no ES modules: this project has no bundler, and the MV3 service worker
 * loads files with importScripts()). Exposes a single global: `Logger`.
 *
 * Usage:
 *   Logger.debug("detective", "scan started", { tabId });
 *   Logger.error("api", "handler failed", { type: "proxyRotateNow" }, err);
 *
 * Levels below the configured minimum are no-ops (cheap to call everywhere).
 * Level is "warn" by default; call Logger.setLevel("debug") during development.
 */
(function (root) {
  "use strict";
  const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 };
  let min = LEVELS.warn;

  function fmt(tag) { return `[MeMik:${tag}]`; }

  function log(level, tag, msg, data, err) {
    if (LEVELS[level] < min) return;
    const args = [fmt(tag), msg];
    if (data !== undefined) args.push(data);
    if (err !== undefined) args.push(err);
    const fn = level === "error" ? console.error : level === "warn" ? console.warn : level === "info" ? console.info : console.debug;
    try { fn.apply(console, args); } catch (_) { /* console unavailable: never let logging throw */ }
  }

  const Logger = {
    setLevel(level) { if (LEVELS[level] != null) min = LEVELS[level]; },
    getLevel() { return Object.keys(LEVELS).find(k => LEVELS[k] === min) || "warn"; },
    debug: (tag, msg, data) => log("debug", tag, msg, data),
    info: (tag, msg, data) => log("info", tag, msg, data),
    warn: (tag, msg, data) => log("warn", tag, msg, data),
    error: (tag, msg, data, err) => log("error", tag, msg, data, err)
  };

  if (typeof module !== "undefined" && module.exports) module.exports = Logger;
  else root.Logger = Logger;
})(typeof self !== "undefined" ? self : globalThis);
