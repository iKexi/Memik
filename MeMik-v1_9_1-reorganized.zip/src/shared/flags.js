/**
 * src/shared/flags.js — Offline country flag renderer for PC & Mobile.
 * Uses local vector SVG flags with automatic graceful fallbacks.
 */
(function (root) {
  "use strict";

  const flagEmoji = cc => (cc && /^[A-Z]{2}$/i.test(cc)
    ? String.fromCodePoint(...[...cc.toUpperCase()].map(c => 0x1F1E6 + c.charCodeAt(0) - 65))
    : "🌐");

  function flagImg(cc, className) {
    const cls = className || "nv-flag-img";
    if (!cc || !/^[A-Z]{2}$/i.test(cc)) {
      return `<span class="${cls} nv-flag-fallback">🌐</span>`;
    }
    const code = cc.toUpperCase();
    const url = (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL)
      ? chrome.runtime.getURL(`assets/flags/${code.toLowerCase()}.svg`)
      : `../../assets/flags/${code.toLowerCase()}.svg`;
    return `<img class="${cls}" src="${url}" alt="${code}" width="20" height="15">`;
  }

  const MemikFlags = {
    emoji: flagEmoji,
    img: flagImg
  };

  if (typeof module !== "undefined" && module.exports) module.exports = MemikFlags;
  else root.MemikFlags = MemikFlags;
})(typeof window !== "undefined" ? window : globalThis);
