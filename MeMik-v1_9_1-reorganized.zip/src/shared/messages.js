/**
 * shared/messages.js — the extension's internal message-passing API.
 *
 * Every message a popup/extension page sends to the background service worker via
 * chrome.runtime.sendMessage has a `type` field. This file is the single source of
 * truth for those type strings so they are never typo-able at the call site, and
 * doubles as the API reference (see docs/ARCHITECTURE.md for the full picture,
 * including the separate tabs-targeted content-script protocols this file does not
 * cover — those are internal to each content script and out of scope here).
 *
 * Plain script, exposes a single global: `MSG`. Keys are SCREAMING_SNAKE_CASE;
 * values are the wire strings background.js still matches on (unchanged, for
 * backward compatibility with the existing switch).
 */
(function (root) {
  "use strict";
  const MSG = Object.freeze({
    // --- Identity & updates ---
    /** Identify the caller. Used by content scripts (allowed from web pages) to learn their tabId. */
    WHOAMI: "whoami",
    /** Check whether a newer version of the extension is available. */
    CHECK_UPDATE: "checkUpdate",
    /** Read the last known update-check result. */
    GET_UPDATE_INFO: "getUpdateInfo",
    /** Set a custom update-manifest URL (self-hosted updates). */
    SET_UPDATE_CHECK_URL: "setUpdateCheckUrl",
    // --- Routines & automation ---
    /** Create or update a saved automation routine. */
    SAVE_ROUTINE: "saveRoutine",
    /** Import routines from an exported file. */
    IMPORT_ROUTINES: "importRoutines",
    /** Run a saved routine. */
    RUN_ROUTINE: "runRoutine",
    /** Run a one-off recorded action sequence without saving it as a routine. */
    RUN_RECORDING: "runRecording",
    /** Signal the active routine run to stop. Allowed from web pages. */
    STOP_ROUTINE: "stopRoutine",
    /** Schedule a routine to run later or on a repeating clock. */
    SCHEDULE_ROUTINE: "scheduleRoutine",
    /** Cancel a scheduled run. */
    CANCEL_SCHEDULE: "cancelSchedule",
    /** Delete a saved routine. */
    DELETE_ROUTINE: "deleteRoutine",
    // --- Captcha solving ---
    CAPTCHA_SOLVE_ACTIVE_TAB: "captchaSolveActiveTab",
    CAPTCHA_STATUS: "captchaStatus",
    CAPTCHA_TRANSCRIBE: "captchaTranscribe",
    CAPTCHA_SOLVE_FROM_FRAME: "captchaSolveFromFrame",
    // --- Media detection & download ---
    MEDIA_OPEN_POPUP: "mediaOpenPopup",
    MEDIA_DETECT_ACTIVE_TAB: "mediaDetectActiveTab",
    MEDIA_DOWNLOAD: "mediaDownload",
    MEDIA_PLAYER_CONTROL: "mediaPlayerControl",
    // --- Ad / tracker blocking ---
    /** Read the ad/tracker-block allowlist. */
    ALLOWLIST_GET: "allowlistGet",
    /** Add a site to the allowlist (stop blocking on it). */
    ALLOWLIST_ADD: "allowlistAdd",
    /** Remove a site from the allowlist. */
    ALLOWLIST_REMOVE: "allowlistRemove",
    /** Clear the blocked-requests log. */
    BLOCK_LOG_CLEAR: "blockLogClear",
    /** Read the recent log of blocked requests. */
    BLOCK_LOG_GET: "blockLogGet",
    /** Check whether newer filter lists are available. */
    ADBLOCK_CHECK_UPDATE: "adblockCheckUpdate",
    /** Download and apply the latest filter lists. */
    ADBLOCK_RUN_UPDATE: "adblockRunUpdate",
    /** Persist the user's auto-update preference for filter lists. */
    ADBLOCK_AUTO_UPDATE_CHANGED: "adblockAutoUpdateChanged",
    /** Persist general ad-block settings and re-sync the declarativeNetRequest rules. */
    ADBLOCK_SETTINGS_CHANGED: "adblockSettingsChanged",
    // --- Temp mail ---
    TEMP_MAIL_GENERATE: "tempMailGenerate",
    TEMP_MAIL_SET_PROVIDER: "tempMailSetProvider",
    TEMP_MAIL_GET_STATE: "tempMailGetState",
    TEMP_MAIL_REFRESH: "tempMailRefresh",
    TEMP_MAIL_GET_MESSAGE: "tempMailGetMessage",
    TEMP_MAIL_DIAGNOSE: "tempMailDiagnose",
    TEMP_MAIL_CLOSE_READER: "tempMailCloseReader",
    TEMP_MAIL_CLEAR: "tempMailClear",
    // --- Proxy ---
    PROXY_SETTINGS_CHANGED: "proxySettingsChanged",
    PROXY_PROBE_LIST: "proxyProbeList",
    PROXY_CONNECT_WORKING: "proxyConnectWorking",
    PROXY_FETCH_FRESH: "proxyFetchFresh",
    PROXY_PROBE_ALL: "proxyProbeAll",
    CF_DNS_CHANGED: "cfDnsChanged",
    OXYLABS_SETTINGS_CHANGED: "oxylabsSettingsChanged",
    PROXY_ROTATE_NOW: "proxyRotateNow",
    PROXY_SELECT: "proxySelect",
    PROXY_EXIT_INFO: "proxyExitInfo",
    PROXY_GEOLOCATE: "proxyGeolocate",
    PROXY_DISCONNECT: "proxyDisconnect",
    PROXY_CANCEL: "proxyCancel",
    PROXY_SPEED_MODE_CHANGED: "proxySpeedModeChanged",
    PROXY_PICK_FASTEST: "proxyPickFastest",
    PROXY_SCOPE_CHANGED: "proxyScopeChanged",
    PROXY_ASSIGN_ACTIVE_TAB: "proxyAssignActiveTab",
    PROXY_ASSIGN_ACTIVE_GROUP: "proxyAssignActiveGroup",
    PROXY_REMOVE_ASSIGNED_TAB: "proxyRemoveAssignedTab",
    PROXY_REMOVE_ASSIGNED_GROUP: "proxyRemoveAssignedGroup",
    PROXY_GET_ASSIGNED: "proxyGetAssigned",
    // --- Breach / password checks ---
    /** Check an email address against a breach-notification service. */
    BREACH_CHECK_EMAIL: "breachCheckEmail",
    /** Check a password's hash prefix against the Have I Been Pwned range API (k-anonymity; the full password never leaves the device). */
    PWNED_PASSWORD_CHECK: "pwnedPasswordCheck",
    // --- Detective ---
    /** Run a Detective scan (all checks, or one category) against the active or given tab. */
    DETECTIVE_RUN: "detectiveRun",
    /** Look up the current page's IP, DNS records, CDN and every server it contacted. */
    DETECTIVE_SITE_INFO: "detectiveSiteInfo",
    /** Read the opt-in local log of visited sites and IPs. */
    DETECTIVE_VISITED_GET: "detectiveVisitedGet",
    /** Turn the visited-sites log on or off. */
    DETECTIVE_VISITED_SET: "detectiveVisitedSet",
    /** Erase the visited-sites log. */
    DETECTIVE_VISITED_CLEAR: "detectiveVisitedClear",
    /** Start a consent-gated live port test against a site the user says they own. */
    DETECTIVE_PORT_START: "detectivePortStart",
    /** Stop an in-progress port test. */
    DETECTIVE_PORT_CANCEL: "detectivePortCancel",
    /** Resolve a hostname to IP addresses via DNS-over-HTTPS. */
    DETECTIVE_LOOKUP: "detectiveLookup",
  });

  if (typeof module !== "undefined" && module.exports) module.exports = MSG;
  else root.MSG = MSG;
})(typeof self !== "undefined" ? self : globalThis);
