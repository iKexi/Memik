/**
 * shared/net.js — timeout-wrapped fetch helpers.
 *
 * Consolidated out of background/detective.js, which had its own copy of this exact
 * pattern. Not yet used by the proxy code's similar `fetchJsonTimeout` in
 * background.js: that function has call sites deep in proxy-rotation logic this pass
 * doesn't touch (see docs/ARCHITECTURE.md § "What wasn't moved, and why"). Consolidating
 * it here is a natural next step once that logic has its own test coverage.
 *
 * Plain script, exposes globals: `withTimeout`, `fetchTimeout`.
 */
(function (root) {
  "use strict";

  /** Reject `promise` with an Error(label) if it hasn't settled within `ms`. */
  function withTimeout(promise, ms, label) {
    let t;
    return Promise.race([
      promise,
      new Promise((_, rej) => { t = setTimeout(() => rej(new Error(label || "timeout")), ms); })
    ]).finally(() => clearTimeout(t));
  }

  /** fetch() that aborts after `ms` instead of hanging. */
  async function fetchTimeout(url, init, ms) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    try { return await fetch(url, Object.assign({}, init, { signal: ctl.signal })); }
    finally { clearTimeout(timer); }
  }

  const api = { withTimeout, fetchTimeout };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else Object.assign(root, api);
})(typeof self !== "undefined" ? self : globalThis);
