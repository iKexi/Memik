/**
 * shared/dom.js — small, generic DOM and formatting utilities with no business logic.
 *
 * Consolidated out of popup.js, where several of these existed only inside the
 * Detective section even though they're fully generic (and `plural`/`esc`/`$` were
 * already shared by the rest of the popup). Load this script before any popup script
 * that uses these globals.
 *
 * Plain script, exposes globals: `$`, `esc`, `plural`, `h`, `clearEl`, `fmtAgo`,
 * `copyText`, `downloadText`.
 */
(function (root, doc) {
  "use strict";

  /** document.getElementById shorthand. */
  const $ = id => doc.getElementById(id);

  /** Escape a string for safe use inside HTML markup (not needed when building via `h`, which
   *  sets text via the DOM rather than innerHTML — kept for the few places that still build
   *  HTML strings directly). */
  const esc = value => String(value).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /** "3 finding" -> "3 findings". Always a plain English plural-s; good enough for this UI's nouns. */
  const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

  /**
   * Tiny hyperscript-style DOM builder: h("div", {class: "x", onclick: fn}, "text", childEl).
   * Attribute values of `null`/`false` are skipped; `on*` keys bind listeners instead of attributes.
   * Building nodes this way (rather than innerHTML + a template string) means user-controlled
   * text always lands via textContent, never parsed as markup.
   */
  function h(tag, attrs, ...kids) {
    const el = doc.createElement(tag);
    if (attrs) for (const k of Object.keys(attrs)) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === "class") el.className = v;
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    const add = kid => {
      if (kid == null || kid === false) return;
      if (Array.isArray(kid)) return kid.forEach(add);
      el.appendChild(kid.nodeType ? kid : doc.createTextNode(String(kid)));
    };
    kids.forEach(add);
    return el;
  }

  /** Remove all children/text from an element and return it, for reuse in a chain. */
  const clearEl = el => { if (el) el.textContent = ""; return el; };

  /** "3 min ago" style relative time from a Date.now()-style timestamp. */
  function fmtAgo(ts) {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return "just now";
    if (s < 3600) return `${Math.floor(s / 60)} min ago`;
    if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
    return `${Math.floor(s / 86400)} d ago`;
  }

  /**
   * Copy text to the clipboard, falling back to a hidden textarea + execCommand for
   * contexts where the async Clipboard API isn't available. Never throws.
   * @param {string} text
   * @param {(msg: string, kind?: string, seconds?: number) => void} [notify] - e.g. this popup's `say()`.
   * @param {string} [okMsg]
   */
  async function copyText(text, notify, okMsg) {
    const announce = (msg, kind, secs) => { if (typeof notify === "function") notify(msg, kind, secs); };
    try {
      await navigator.clipboard.writeText(text);
      announce(okMsg || "Copied.", "ok", 3);
    } catch (_) {
      try {
        const ta = h("textarea", { style: "position:fixed;opacity:0" });
        ta.value = text; doc.body.appendChild(ta); ta.select();
        doc.execCommand("copy"); ta.remove();
        announce(okMsg || "Copied.", "ok", 3);
      } catch (e) {
        if (typeof Logger !== "undefined") Logger.warn("dom", "copyText failed", {}, e);
        announce("Could not copy.", "error");
      }
    }
  }

  /** Trigger a browser download of `text` as a file named `name`. */
  function downloadText(name, text, type) {
    const url = URL.createObjectURL(new Blob([text], { type: type || "text/plain" }));
    const a = h("a", { href: url, download: name });
    doc.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  const api = { $, esc, plural, h, clearEl, fmtAgo, copyText, downloadText };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else Object.assign(root, api);
})(typeof window !== "undefined" ? window : globalThis, typeof document !== "undefined" ? document : {});
