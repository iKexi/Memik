/**
 * shared/config.js — environment configuration, separated from business logic.
 *
 * Holds the external endpoints, storage keys, timeouts and limits that code elsewhere
 * previously had as inline magic numbers/strings. Change behaviour by editing here,
 * not by hunting through handler bodies.
 *
 * This pass populates it from Detective (the module fully migrated in this refactor)
 * plus the handful of extension-wide values already centralized. Other modules
 * (proxy, captcha, adblock, temp-mail) keep their existing inline constants for now —
 * migrating those is a separate, lower-risk-when-done-gradually pass; see
 * docs/ARCHITECTURE.md § "What wasn't moved, and why".
 *
 * Plain script, exposes a single global: `CONFIG`.
 */
(function (root) {
  "use strict";

  const CONFIG = Object.freeze({
    detective: Object.freeze({
      // DNS-over-HTTPS resolvers, tried in order.
      dohResolvers: Object.freeze([
        "https://cloudflare-dns.com/dns-query",
        "https://dns.google/resolve"
      ]),
      // Passive public port/vuln database for an IP (Shodan InternetDB).
      internetDbUrl: "https://internetdb.shodan.io/",
      securityTxtPath: "/.well-known/security.txt",
      timeouts: Object.freeze({
        contentScanMs: 9000,
        headFallbackMs: 7000,
        dohMs: 4500,
        internetDbMs: 6000,
        securityTxtMs: 4000,
        portProbeMs: 3000,
        portBaselineMs: 2500,
        proxyStatusCacheMs: 30000
      }),
      limits: Object.freeze({
        maxTabsTracked: 60,
        maxConnectionsPerTab: 200,
        maxVisitedEntries: 500,
        maxCustomPorts: 60,
        maxPortRangeSpan: 50,
        portScanLanes: 6
      }),
      storageKeys: Object.freeze({
        uiPrefs: "detUi",
        logVisitsEnabled: "detLogVisits",
        visitedList: "detVisited",
        portScanState: "detPortScan",
        mainFramePrefix: "detMain:",
        connectionsPrefix: "detConn:"
      })
    }),

    // Shared across the popup UI generally.
    ui: Object.freeze({
      storageKeys: Object.freeze({
        detectiveDisplayPrefs: "detUi",
        theme: "uiTheme",
        accent: "uiAccent"
      }),
      copyToastMs: 3000
    })
  });

  if (typeof module !== "undefined" && module.exports) module.exports = CONFIG;
  else root.CONFIG = CONFIG;
})(typeof self !== "undefined" ? self : globalThis);
