// Run: node tests/security-hub-test.js
const assert = require("assert");
const fs = require("fs");
global.chrome = {};
const Hub = require("../src/features/privacy/security-hub.js");

// strength meter
assert.strictEqual(Hub.estimate("").level, "none");
assert.ok(["bad", "warn"].includes(Hub.estimate("password1").level), "common word must score low");
assert.ok(Hub.estimate("correct-Horse-battery-9-Staple!").bits >= 80);
assert.ok(Hub.estimate("aaaaaaaaaaaa").bits < Hub.estimate("aZ3$kQ9!mW2#").bits);

// generator: length, classes, no look-alikes when requested
for (let i = 0; i < 200; i++) {
  const p = Hub.generate(24, true, true);
  assert.strictEqual(p.length, 24);
  assert.ok(/[a-z]/.test(p) && /[A-Z]/.test(p) && /\d/.test(p) && /[^A-Za-z0-9]/.test(p));
  assert.ok(!/[0O1lI]/.test(p), "look-alikes must be excluded: " + p);
}
assert.ok(!/[^A-Za-z0-9]/.test(Hub.generate(30, false, false)));

// platform-ads ruleset: valid shape, unique ids, only non-main-frame blocking, key domains present
const rules = JSON.parse(fs.readFileSync(__dirname + "/../config/rulesets/platform-ads.json", "utf8"));
const ids = new Set(rules.map(r => r.id));
assert.strictEqual(ids.size, rules.length);
const domains = rules.flatMap(r => r.condition.requestDomains || []);
for (const d of ["google-analytics.com", "px.ads.linkedin.com", "ads.tiktok.com", "ads.pinterest.com", "ads.yahoo.com", "ads.youtube.com", "adx.ads.oppomobile.com"])
  assert.ok(domains.includes(d), "missing " + d);
for (const r of rules) {
  assert.strictEqual(r.action.type, "block");
  assert.ok(!r.condition.resourceTypes.includes("main_frame"), "must never block page loads");
}
// must not block whole first-party sites
for (const d of ["linkedin.com", "tiktok.com", "pinterest.com", "yahoo.com", "youtube.com", "google.com"])
  assert.ok(!domains.includes(d), "too broad: " + d);

// manifest + background registration
const manifest = JSON.parse(fs.readFileSync(__dirname + "/../manifest.json", "utf8"));
assert.ok(manifest.declarative_net_request.rule_resources.some(r => r.id === "platform-ads"));
assert.ok(/"platform-ads"/.test(fs.readFileSync(__dirname + "/../src/core/background/service-worker.js", "utf8")));
console.log("security-hub tests passed");
