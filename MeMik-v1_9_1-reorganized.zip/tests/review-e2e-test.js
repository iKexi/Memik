const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');

console.log('--- Starting Comprehensive E2E & Review Verification ---');

// 1. Verify OxyLabs Third-Party Purge
{
  const bgCode = fs.readFileSync(path.join(root, 'src/core/background/service-worker.js'), 'utf8');
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');
  const popupHtml = fs.readFileSync(path.join(root, 'src/ui/popup.html'), 'utf8');

  assert(!bgCode.includes('unblock.oxylabs.io'), 'unblock.oxylabs.io must not appear in background.js');
  assert(!popupCode.includes('unblock.oxylabs.io'), 'unblock.oxylabs.io must not appear in popup.js');
  assert(!popupHtml.includes('unblock.oxylabs.io'), 'unblock.oxylabs.io must not appear in popup.html');
  assert(!popupHtml.includes('Oxylabs Web Unblocker'), 'Oxylabs Web Unblocker must not appear in popup.html');
  console.log('✓ Check 1 Passed: OxyLabs domain and provider name thoroughly purged');
}

// 2. Verify TempMail.lol Purge
{
  const tmCode = fs.readFileSync(path.join(root, 'src/features/temp-mail/temp-mail.js'), 'utf8');
  const allowlistCode = fs.readFileSync(path.join(root, 'src/core/background/allowlist.js'), 'utf8');

  assert(!tmCode.includes('tempmail.lol'), 'tempmail.lol must not appear in temp-mail.js');
  assert(!tmCode.includes('tempmaillol'), 'tempmaillol must not appear in temp-mail.js');
  assert(!allowlistCode.includes('tempmail.lol'), 'tempmail.lol must not appear in allowlist.js');
  console.log('✓ Check 2 Passed: TempMail.lol thoroughly purged from services, allowlist and internals');
}

// 3. Verify HTML markup and SVG icons
{
  const popupHtml = fs.readFileSync(path.join(root, 'src/ui/popup.html'), 'utf8');

  // Ping row directly below IP
  assert(popupHtml.includes('id="nvPingRow"'), 'nvPingRow must exist in popup.html');
  assert(popupHtml.includes('id="nvPing" class="nv-ping nv-ping-pill"'), 'nvPing must have nv-ping-pill class');

  // Fast-Forward icon on nvSwapBtn
  const nvSwapMatch = popupHtml.match(/id="nvSwapBtn"[\s\S]*?<\/button>/);
  assert(nvSwapMatch, 'nvSwapBtn must exist');
  assert(nvSwapMatch[0].includes('polygon points="13 19 22 12 13 5 13 19"'), 'nvSwapBtn must have Fast-Forward polygon icon');

  // Fast-Forward icon on proxySwitchNowBtn
  const proxySwitchMatch = popupHtml.match(/id="proxySwitchNowBtn"[\s\S]*?<\/button>/);
  assert(proxySwitchMatch, 'proxySwitchNowBtn must exist');
  assert(proxySwitchMatch[0].includes('polygon points="13 19 22 12 13 5 13 19"'), 'proxySwitchNowBtn must have Fast-Forward polygon icon');

  // Refresh icon on proxyFetchBtn
  const proxyFetchMatch = popupHtml.match(/id="proxyFetchBtn"[\s\S]*?<\/button>/);
  assert(proxyFetchMatch, 'proxyFetchBtn must exist');
  assert(proxyFetchMatch[0].includes('stroke-linecap="round"'), 'proxyFetchBtn must have standard refresh icon');

  // Record icon on proxyProbeBtn
  const proxyProbeMatch = popupHtml.match(/id="proxyProbeBtn"[\s\S]*?<\/button>/);
  assert(proxyProbeMatch, 'proxyProbeBtn must exist');
  assert(proxyProbeMatch[0].includes('<circle cx="12" cy="12" r="8"/>') || proxyProbeMatch[0].includes('<circle'), 'proxyProbeBtn must have circle glyph');

  // Import icon on importBtn (arrow pointing down into a tray; export uses the up arrow)
  const importMatch = popupHtml.match(/id="importBtn"[\s\S]*?<\/button>/);
  assert(importMatch, 'importBtn must exist');
  assert(importMatch[0].includes('M12 4v11M7 10l5 5 5-5'), 'importBtn must have import (down-arrow) icon');
  const exportMatch = popupHtml.match(/id="exportBtn"[\s\S]*?<\/button>/);
  assert(exportMatch && exportMatch[0].includes('M12 15V4M7 9l5-5 5 5'), 'exportBtn must have export (up-arrow) icon');

  // Plus icon on proxyAddBtn and allowAddBtn
  const proxyAddMatch = popupHtml.match(/id="proxyAddBtn"[\s\S]*?<\/button>/);
  assert(proxyAddMatch[0].includes('line x1="12" y1="5" x2="12" y2="19"'), 'proxyAddBtn must have plus icon');
  const allowAddMatch = popupHtml.match(/id="allowAddBtn"[\s\S]*?<\/button>/);
  assert(allowAddMatch[0].includes('line x1="12" y1="5" x2="12" y2="19"'), 'allowAddBtn must have plus icon');

  // Preview heading and themePreview banner
  assert(popupHtml.includes('<div class="menu-section-title">Preview</div>'), 'Preview heading must exist');
  assert(popupHtml.includes('id="themePreview"'), 'themePreview element must exist');
  assert(!popupHtml.includes('id="swatches"'), 'Accent swatches must be removed');

  // Proxy scope elements
  assert(popupHtml.includes('id="proxyScopePanel"'), 'proxyScopePanel must exist');
  assert(popupHtml.includes('id="assignCurTabBtn"'), 'assignCurTabBtn must exist');
  assert(popupHtml.includes('id="assignCurGroupBtn"'), 'assignCurGroupBtn must exist');
  assert(popupHtml.includes('id="proxyAssignedList"'), 'proxyAssignedList must exist');

  // Block popups only checkbox
  assert(popupHtml.includes('id="blockPopupsOnly"'), 'blockPopupsOnly switch must exist');

  console.log('✓ Check 3 Passed: HTML UI markup, IDs, and control icons verified');
}

// 4. Verify CSS rules
{
  const css = fs.readFileSync(path.join(root, 'src/ui/popup.css'), 'utf8');

  // Glass theme tokens
  assert(css.includes('html[data-theme="glass"]'), 'Glass theme selector must exist');
  assert(css.includes('--rim-highlight'), 'Glass rim-highlight token must exist');
  assert(css.includes('--shadow-layered'), 'Glass shadow-layered token must exist');

  // Light theme rules (untouched and actual light theme)
  assert(css.includes('html[data-theme="light"]'), 'Light theme selector must exist');
  assert(css.includes('color-scheme: light;'), 'color-scheme: light must exist');

  // Dark theme preview banner rules
  assert(css.includes('html[data-theme="dark"] .theme-preview') || css.includes('.theme-preview[data-theme-preview="dark"]'), 'Dark theme preview banner styles must exist');

  // Ping row and pill
  assert(css.includes('.nv-ping-row'), '.nv-ping-row CSS rule must exist');
  assert(css.includes('.nv-ping-pill'), '.nv-ping-pill CSS rule must exist');

  // Container styling for Favourites and Recently Used
  assert(css.includes('.home-menu .menu-section'), '.home-menu .menu-section CSS rule must exist');
  assert(css.includes('.home-menu .app-drawer'), '.home-menu .app-drawer CSS rule must exist');

  // Direct Connect button
  assert(css.includes('.px-connect-btn'), '.px-connect-btn CSS rule must exist');

  console.log('✓ Check 4 Passed: CSS themes, glass tokens, preview banner, and layout rules verified');
}

// 5. Verify IPC Message Handling logic in background.js
{
  const bgCode = fs.readFileSync(path.join(root, 'src/core/background/service-worker.js'), 'utf8');

  // proxyScopeChanged handles mode or scope
  assert(bgCode.includes('(message.mode || message.scope) === "tabs"'), 'proxyScopeChanged must check message.mode or message.scope');

  // proxyRemoveAssignedTab handles id or tabId
  assert(bgCode.includes('message.id ?? message.tabId'), 'proxyRemoveAssignedTab must check message.id or message.tabId');

  // proxyRemoveAssignedGroup handles id or groupId
  assert(bgCode.includes('message.id ?? message.groupId'), 'proxyRemoveAssignedGroup must check message.id or message.groupId');

  // proxyGetAssigned returns both tabs & assignedTabs, groups & assignedGroups
  assert(bgCode.includes('assignedTabs: tabDetails'), 'proxyGetAssigned must return assignedTabs');
  assert(bgCode.includes('assignedGroups: groupDetails'), 'proxyGetAssigned must return assignedGroups');

  // Auto-IP rotation safeguard
  assert(bgCode.includes('isAuto'), 'rotateProxy must distinguish auto-rotation');
  assert(bgCode.includes('No verified working proxy available. Retaining current IP.'), 'Auto-rotation must retain IP when no verified proxy available');

  // Dead proxy cleanup debounced and deferred
  assert(bgCode.includes('deadCleanupTimer'), 'deadCleanupTimer must be used for debounced cleanup');
  assert(bgCode.includes('!scanCancel && dead > 0'), 'Dead proxy cleanup must verify !scanCancel');

  console.log('✓ Check 5 Passed: Service worker IPC contract, auto-rotation safeguards, and dead proxy cleanup verified');
}

// 6. Verify popup.js navigation and scoping
{
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  // goBack direct to main page from theme
  assert(popupCode.includes('cur === "theme"') && popupCode.includes('openSheet(false)'), 'goBack must close sheet when cur === theme');
  assert(popupCode.includes('state.navStack = [];'), 'goBack must clear navStack when leaving theme');

  // Tab assignment panel references proxyScopePanel
  assert(popupCode.includes('$("proxyScopePanel")'), 'popup.js must target proxyScopePanel');

  // theme titles
  assert(popupCode.includes('Liquid Glass'), 'Theme labels must include Liquid Glass');
  assert(!popupCode.includes('Glass (Coastal)'), 'Legacy Coastal labels must be removed');

  console.log('✓ Check 6 Passed: Popup navigation, theme labels, and scope panel logic verified');
}

console.log('\n========================================');
console.log('ALL E2E & REVIEW VERIFICATION CHECKS PASSED!');
console.log('========================================');
