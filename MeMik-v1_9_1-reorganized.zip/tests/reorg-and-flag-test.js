const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");

console.log("--- Starting Reorganization & User Fixes Verification ---");

// 1. Manifest structure verification
const manifestPath = path.join(root, "manifest.json");
assert(fs.existsSync(manifestPath), "manifest.json must exist at root");
const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));

// Check entry points
assert.strictEqual(manifest.action.default_popup, "src/ui/popup.html");
assert(fs.existsSync(path.join(root, manifest.action.default_popup)), "popup.html must exist at src/ui/popup.html");

assert.strictEqual(manifest.background.service_worker, "src/core/background/service-worker.js");
assert(fs.existsSync(path.join(root, manifest.background.service_worker)), "service-worker.js must exist at src/core/background/service-worker.js");

// Check content scripts
for (const cs of manifest.content_scripts) {
  for (const jsFile of cs.js) {
    assert(fs.existsSync(path.join(root, jsFile)), `Content script ${jsFile} must exist`);
  }
}

// Check DNR rulesets
assert.strictEqual(manifest.declarative_net_request.rule_resources.length, 14);
for (const rr of manifest.declarative_net_request.rule_resources) {
  assert(fs.existsSync(path.join(root, rr.path)), `Rule resource ${rr.path} must exist`);
}
console.log("✓ Check 1 Passed: Manifest V3 paths, content scripts, and rule resources verified");

// 2. Offline SVG flags check
const flagsDir = path.join(root, "assets/flags");
assert(fs.existsSync(flagsDir), "assets/flags directory must exist");
const flagFiles = fs.readdirSync(flagsDir);
assert(flagFiles.length >= 190, `assets/flags must contain country flags (found ${flagFiles.length})`);
assert(fs.existsSync(path.join(flagsDir, "us.svg")), "us.svg must exist");
assert(fs.existsSync(path.join(flagsDir, "gb.svg")), "gb.svg must exist");
assert(fs.existsSync(path.join(flagsDir, "de.svg")), "de.svg must exist");
assert(fs.existsSync(path.join(flagsDir, "in.svg")), "in.svg must exist");

const flagsHelper = require(path.join(root, "src/shared/flags.js"));
const usHtml = flagsHelper.img("US");
assert(usHtml.includes("assets/flags/us.svg"), "img('US') must link to us.svg");
assert(usHtml.includes('class="nv-flag-img"'), "img('US') must have nv-flag-img class");
console.log("✓ Check 2 Passed: 198 offline SVG country flags and flag helper verified");

// 3. Detective arrows check
const cssContent = fs.readFileSync(path.join(root, "src/ui/popup.css"), "utf8");
assert(cssContent.includes(".det-theme > summary::after, .det-tool > summary::after { content: none !important; display: none !important; }"), "Detective arrows must be removed from summary::after");
console.log("✓ Check 3 Passed: Detective bottom-right arrows removed");

// 4. Quick connect & Connected state logic check
const popupJsContent = fs.readFileSync(path.join(root, "src/ui/popup.js"), "utf8");
assert(popupJsContent.includes("const on = !!state.proxyEnabled;"), "popup.js must evaluate on based directly on proxyEnabled");
assert(popupJsContent.includes('if ("proxyScopeMode" in changes) state.proxyScopeMode = changes.proxyScopeMode.newValue || "global";'), "storage.onChanged must sync proxyScopeMode");
assert(popupJsContent.includes('state.proxyScopeMode = data.proxyScopeMode || (data.proxyGlobalMode ? "global" : "tabs");'), "init() must restore proxyScopeMode");
assert(popupJsContent.includes("cb.classList.add(\"hidden\");"), "Quick connect button must be hidden when proxy is connected");
console.log("✓ Check 4 Passed: Connected state display and Quick connect hiding verified");

// 5. Proxy Google speed capability check
const swContent = fs.readFileSync(path.join(root, "src/core/background/service-worker.js"), "utf8");
assert(swContent.includes("https://www.google.com/generate_204"), "service-worker.js must probe https://www.google.com/generate_204");
assert(swContent.includes("getDirectGoogleLatency"), "service-worker.js must benchmark against direct Google latency");
console.log("✓ Check 5 Passed: Google.com speed capability verification confirmed");

console.log("\n========================================");
console.log("ALL REORGANIZATION & FIX CHECKS PASSED!");
console.log("========================================");
