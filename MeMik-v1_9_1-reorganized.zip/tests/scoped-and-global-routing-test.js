const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const { extractDomain, buildPacScript, directiveFor } = require('../src/features/proxy/proxy-scope.js');

console.log('--- Testing Comprehensive IP Routing & Failover Scenarios ---');

// 1. Test extractDomain
{
  assert.strictEqual(extractDomain('www.whatismyipaddress.com'), 'whatismyipaddress.com');
  assert.strictEqual(extractDomain('ipv4.whatismyipaddress.com'), 'whatismyipaddress.com');
  assert.strictEqual(extractDomain('whatismyipaddress.com'), 'whatismyipaddress.com');
  assert.strictEqual(extractDomain('sub.domain.co.uk'), 'domain.co.uk');
  assert.strictEqual(extractDomain('1.1.1.1'), '1.1.1.1');
  assert.strictEqual(extractDomain('localhost'), 'localhost');
  assert.strictEqual(extractDomain('https://api.ipify.org/json'), 'ipify.org');
  console.log('✓ extractDomain correctly isolates apex domains and IP literals');
}

// 2. PAC execution in VM for scoped tab routing
{
  const proxy = { scheme: 'http', host: '95.217.20.10', port: 8080 };
  const pacCode = buildPacScript(['www.whatismyipaddress.com'], proxy, false, ['ipwho.is']);

  const sandbox = {};
  vm.createContext(sandbox);
  // PAC environment provides isPlainHostName
  sandbox.isPlainHostName = (h) => !h.includes('.');
  vm.runInContext(pacCode, sandbox);

  // Exact page
  assert.strictEqual(sandbox.FindProxyForURL('https://www.whatismyipaddress.com/', 'www.whatismyipaddress.com'), 'PROXY 95.217.20.10:8080');
  // Root domain
  assert.strictEqual(sandbox.FindProxyForURL('https://whatismyipaddress.com/', 'whatismyipaddress.com'), 'PROXY 95.217.20.10:8080');
  // Subdomain API called by the page to show user IP (the critical fix)
  assert.strictEqual(sandbox.FindProxyForURL('https://ipv4.whatismyipaddress.com/api', 'ipv4.whatismyipaddress.com'), 'PROXY 95.217.20.10:8080');
  // Third-party unassigned site goes DIRECT
  assert.strictEqual(sandbox.FindProxyForURL('https://google.com/', 'google.com'), 'DIRECT');
  // Plain host goes DIRECT
  assert.strictEqual(sandbox.FindProxyForURL('http://intranet/', 'intranet'), 'DIRECT');
  // Direct exemption host
  assert.strictEqual(sandbox.FindProxyForURL('https://ipwho.is/1.2.3.4', 'ipwho.is'), 'DIRECT');
  console.log('✓ Scoped PAC routes website, root domain, and IP API subdomains while leaving other tabs DIRECT');
}

// 3. PAC execution in VM for global routing
{
  const proxy = { scheme: 'socks5', host: '10.0.0.1', port: 1080 };
  const pacCode = buildPacScript(null, proxy, true, ['ipwho.is']);

  const sandbox = {};
  vm.createContext(sandbox);
  sandbox.isPlainHostName = (h) => !h.includes('.');
  vm.runInContext(pacCode, sandbox);

  assert.strictEqual(sandbox.FindProxyForURL('https://google.com/', 'google.com'), 'SOCKS5 10.0.0.1:1080; SOCKS 10.0.0.1:1080');
  assert.strictEqual(sandbox.FindProxyForURL('https://ipwho.is/', 'ipwho.is'), 'DIRECT');
  console.log('✓ Global PAC script routes all external traffic');
}

// 4. Background and popup routing configuration logic
{
  const bgCode = fs.readFileSync(path.join(root, 'src/core/background/service-worker.js'), 'utf8');
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  // Global mode applies fixed_servers for immediate socket routing
  assert(bgCode.includes('mode: "fixed_servers"') && bgCode.includes('singleProxy: { scheme, host: proxy.host, port: Number(proxy.port) }'), 'background.js must configure fixed_servers for global browser routing');

  // Scoped mode applies pac_script
  assert(bgCode.includes('mode: "pac_script"') && bgCode.includes('ProxyScope.buildPacScript(list, proxy, false, directHosts())'), 'background.js must configure pac_script for scoped mode');

  // Cancel responsiveness: busy includes state.connecting
  assert(popupCode.includes('const busy = !!pc.running || !!state.connecting;'), 'popup.js renderProxy must treat connecting as busy for instant cancel responsiveness');

  // setUnblockEnabled respects chosen scope
  assert(popupCode.includes('const scopeMode = state.proxyScopeMode || (state.proxyGlobalMode ? "global" : "tabs");'), 'popup.js setUnblockEnabled must preserve user scopeMode');

  // failover never clears config
  assert(!bgCode.match(/async function failoverToLowestPingProxy[\s\S]*?setProxyConfig\(null\)/), 'failoverToLowestPingProxy must not clear proxy config');

  console.log('✓ Overall browser fixed_servers and cancel responsiveness verified');
}

console.log('\n========================================');
console.log('ALL ADVANCED ROUTING TESTS PASSED!');
console.log('========================================');
