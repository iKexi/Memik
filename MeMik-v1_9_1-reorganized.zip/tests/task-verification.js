const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');

console.log('--- Running Task Requirements Verification ---');

// 1. Verify Syntax Fixes
{
  const antiMain = fs.readFileSync(path.join(root, 'src/features/adblock/anti-main.js'), 'utf8');
  const captchaMain = fs.readFileSync(path.join(root, 'src/features/captcha/captcha-main.js'), 'utf8');
  const popupJs = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  assert(!antiMain.includes('catch (e) { continue; }'), 'anti-main.js must not contain catch (e) { continue; }');
  assert(!captchaMain.includes('catch (e) { continue; }'), 'captcha-main.js must not contain catch (e) { continue; }');

  // Verify popup.js syntax by compiling it in a VM script
  assert.doesNotThrow(() => {
    new vm.Script(popupJs);
  }, 'popup.js must parse cleanly without syntax errors at line 2752 or anywhere');

  console.log('✓ Task 1 Passed: Syntax errors fixed and popup.js parses cleanly');
}

// 2. Verify Overall Browser and Tab Scoping IP Routing
{
  const { buildPacScript, directiveFor } = require('../src/features/proxy/proxy-scope.js');
  const bgCode = fs.readFileSync(path.join(root, 'src/core/background/service-worker.js'), 'utf8');
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  // Directive fallbacks
  assert(directiveFor({ scheme: 'socks5', host: '1.2.3.4', port: 1080 }).includes('SOCKS5 1.2.3.4:1080; SOCKS 1.2.3.4:1080'));
  assert(directiveFor({ scheme: 'https', host: '1.2.3.4', port: 443 }).includes('HTTPS 1.2.3.4:443; PROXY 1.2.3.4:443'));
  assert(directiveFor({ scheme: 'http', host: '1.2.3.4', port: 8080 }) === 'PROXY 1.2.3.4:8080');

  // Global routing PAC
  const pacGlobal = buildPacScript(null, { scheme: 'http', host: '1.2.3.4', port: 8080 }, true, ['exempt.com']);
  assert(pacGlobal.includes('return "PROXY 1.2.3.4:8080"'));

  // Scoped routing PAC
  const pacScoped = buildPacScript(['target.com'], { scheme: 'http', host: '1.2.3.4', port: 8080 }, false, []);
  assert(pacScoped.includes('target.com'));

  // Background dynamic tab navigation and request listeners
  assert(bgCode.includes('handleTabNavigated'), 'background.js must implement handleTabNavigated');
  assert(bgCode.includes('chrome.webNavigation.onBeforeNavigate'), 'background.js must listen on webNavigation.onBeforeNavigate');
  assert(bgCode.includes('chrome.webRequest.onBeforeRequest'), 'background.js must listen on webRequest.onBeforeRequest');
  assert(bgCode.includes('chrome.tabs.onUpdated'), 'background.js must listen on tabs.onUpdated');
  assert(bgCode.includes('chrome.tabs.onRemoved'), 'background.js must handle tabs.onRemoved');

  // Tab assignment reloads tab to route immediately
  assert(bgCode.includes('chrome.tabs.reload(tab.id)'), 'proxyAssignActiveTab must reload the tab');

  // Popup.js scope sync
  assert(popupCode.includes('proxyScopeMode: scopeMode') || popupCode.includes('proxyScopeMode: "global"'), 'popup.js must sync proxyScopeMode in storage');

  console.log('✓ Task 2 Passed: IP routing for specific tab and overall browser verified');
}

// 3. Verify Cancel Button Instant Reaction
{
  const bgCode = fs.readFileSync(path.join(root, 'src/core/background/service-worker.js'), 'utf8');
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  // popup.js cancels state immediately on click
  assert(popupCode.includes('state.connecting = false;'), 'Cancel button must reset state.connecting immediately');
  assert(popupCode.includes('state.proxySpeedStatus = "Cancelled."'), 'Cancel button must set Cancelled status immediately');

  // background.js aborts controllers
  assert(bgCode.includes('activeScanAbortController'), 'background.js must manage activeScanAbortController');
  assert(bgCode.includes('scanCancel = true;'), 'background.js must set scanCancel');

  console.log('✓ Task 3 Passed: Cancel button stops actions and updates UI immediately');
}

// 4. Verify Proxy Failover (Lowest Ping, No Auto Disconnect)
{
  const bgCode = fs.readFileSync(path.join(root, 'src/core/background/service-worker.js'), 'utf8');

  assert(bgCode.includes('failoverToLowestPingProxy'), 'background.js must have failoverToLowestPingProxy');
  assert(bgCode.includes('chrome.proxy.onProxyError'), 'background.js must listen on chrome.proxy.onProxyError');
  assert(bgCode.includes('autoRotateOnce'), 'background.js must trigger failover in autoRotateOnce');
  assert(!bgCode.includes('failoverToLowestPingProxy') || !bgCode.match(/async function failoverToLowestPingProxy[\s\S]*?setProxyConfig\(null\)/), 'failoverToLowestPingProxy must NEVER clear proxy config to null');

  console.log('✓ Task 4 Passed: Failover switches to lowest ping proxy without auto-disconnecting');
}

// 5. Verify Detective Menu Restructuring
{
  const popupHtml = fs.readFileSync(path.join(root, 'src/ui/popup.html'), 'utf8');

  assert(popupHtml.includes('id="page-detective" data-page-panel="detective"'), 'page-detective must exist');
  assert(popupHtml.includes('class="page-content nv"'), 'page-detective must have class "page-content nv" matching Security');
  assert(popupHtml.includes('class="nv-hero det-hero" id="detHero"'), 'detHero must exist with nv-hero class');
  assert(popupHtml.includes('id="auditScanBtn" class="nv-connect vpn-action"'), 'auditScanBtn must have nv-connect vpn-action classes');
  assert(popupHtml.includes('>Run full scan</button>'), 'auditScanBtn must have text "Run full scan"');
  assert(popupHtml.includes('id="detScanStatus"'), 'detScanStatus must exist');
  assert(popupHtml.includes('<div class="nv-section-title">Individual checks</div>'), 'Detective must have nv-section-title Individual checks');
  assert(popupHtml.includes('<div class="nv-section-title">Network &amp; Ports</div>'), 'Detective must have nv-section-title Network & Ports');
  assert(popupHtml.includes('<div class="nv-section-title">Breach lookup</div>'), 'Detective must have nv-section-title Breach lookup');

  console.log('✓ Task 5 Passed: Detective menu restructured like Security with full scan button');
}

// 6. Verify Temp Mail Email Box & Removed "Test all providers"
{
  const popupHtml = fs.readFileSync(path.join(root, 'src/ui/popup.html'), 'utf8');
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  assert(popupHtml.includes('id="tempMailAddressInput"'), 'tempMailAddressInput must exist in popup.html');
  assert(popupHtml.includes('id="tempMailCopyBtn"'), 'tempMailCopyBtn must exist in popup.html');
  assert(!popupHtml.includes('Test all providers'), 'Test all providers must be removed from popup.html');
  assert(!popupHtml.includes('id="tempMailDiagBtn"'), 'tempMailDiagBtn must be removed from popup.html');
  assert(!popupHtml.includes('id="tempMailDiag"'), 'tempMailDiag must be removed from popup.html');

  assert(popupCode.includes('tempMailAddressInput'), 'popup.js must populate tempMailAddressInput');

  console.log('✓ Task 6 Passed: Temp Mail email box styled like password and test all providers removed');
}

// 7. Verify Automation Empty State
{
  const popupHtml = fs.readFileSync(path.join(root, 'src/ui/popup.html'), 'utf8');
  const popupCode = fs.readFileSync(path.join(root, 'src/ui/popup.js'), 'utf8');

  const phrase = 'Nothing saved yet. Record something and save it here.';
  assert(!popupHtml.includes(phrase), 'popup.html must not contain the old empty state phrase');
  assert(!popupCode.includes(phrase), 'popup.js must not contain the old empty state phrase');
  assert(popupCode.includes('Empty') && popupCode.includes('empty-faded-bold'), 'popup.js must use Empty with empty-faded-bold class');

  console.log('✓ Task 7 Passed: Automation empty state shows "Empty" in faded bold text');
}

console.log('\n========================================');
console.log('ALL TASK REQUIREMENTS VERIFIED SUCCESSFULLY!');
console.log('========================================');
