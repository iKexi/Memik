const assert = require('assert');
const tempMailModule = require('../src/features/temp-mail/temp-mail.js');
const { BUILTIN } = require('../src/core/background/allowlist.js');

// 1. Verify tempmail.lol is NOT in BUILTIN allowlist
assert(!BUILTIN.includes('tempmail.lol'), 'tempmail.lol must not be in BUILTIN allowlist');
assert(!BUILTIN.includes('api.tempmail.lol'), 'api.tempmail.lol must not be in BUILTIN allowlist');
console.log('Allowlist check passed: tempmail.lol removed');

// 2. Verify tempmail.lol is NOT in services
assert(!tempMailModule.SERVICES || !tempMailModule.SERVICES.tempmaillol, 'tempmaillol must not be in tempMail SERVICES');
assert(!tempMailModule.AUTO_ORDER || !tempMailModule.AUTO_ORDER.includes('tempmaillol'), 'tempmaillol must not be in AUTO_ORDER');
assert(!tempMailModule.HOSTS || !tempMailModule.HOSTS.some(h => h.includes('tempmail.lol')), 'tempmail.lol must not be in HOSTS');

assert(!tempMailModule._internals || !tempMailModule._internals.lolId, 'lolId must not be in _internals');
const fs = require('fs');
const code = fs.readFileSync(require.resolve('../src/features/temp-mail/temp-mail.js'), 'utf8');
assert(!code.includes('tempmail.lol'), 'temp-mail.js must not contain any reference to tempmail.lol');

console.log('TempMail services check passed: tempmaillol completely purged');
console.log('ALL TEMP-MAIL TESTS PASSED!');
