// Run: node tests/toolkit-test.js
const assert = require("assert");
global.window = undefined;
const T = require("../src/features/detective/ui/toolkit-view.js");
const b64u = o => Buffer.from(JSON.stringify(o)).toString("base64url");
const crypto = require("crypto");
const sign = (h, p, secret) => { const d = b64u(h) + "." + b64u(p); return d + "." + crypto.createHmac("sha256", secret).update(d).digest("base64url"); };

(async () => {
  // codecs round-trip, including non-ASCII
  const s = "héllo wörld ✓ <b>&</b>";
  for (const [e, d] of [["b64enc", "b64dec"], ["urlenc", "urldec"], ["hexenc", "hexdec"], ["htmlenc", "htmldec"]])
    assert.strictEqual(await T.transform(d, await T.transform(e, s)), s, e);
  assert.strictEqual(await T.transform("sha256", "abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  await assert.rejects(() => T.transform("b64dec", "***"), /Base64/);
  await assert.rejects(() => T.transform("hexdec", "xyz"), /hex/i);

  // JWT: weak secret + missing exp are caught
  const weak = sign({ alg: "HS256", typ: "JWT" }, { sub: "1" }, "secret");
  const r = await T.inspectJwt(weak);
  assert.ok(r.findings.some(f => f.level === "critical" && /secret/.test(f.title)), "weak secret");
  assert.ok(r.findings.some(f => /No expiry/.test(f.title)));
  // strong secret: not flagged; valid exp ok
  const exp = Math.floor(Date.now() / 1000) + 3600;
  const strong = sign({ alg: "HS256" }, { sub: "1", iss: "x", aud: "y", exp }, "k9$Vq!2zLw8#Rt5@Xn0p");
  const r2 = await T.inspectJwt(strong);
  assert.ok(!r2.findings.some(f => f.level === "critical"));
  assert.ok(r2.findings.some(f => f.level === "ok"));
  // alg none + key injection header
  const none = b64u({ alg: "none", jku: "http://evil" }) + "." + b64u({ sub: "1" }) + ".";
  const r3 = await T.inspectJwt(none);
  assert.ok(r3.findings.some(f => f.level === "critical" && /none/.test(f.title)));
  assert.ok(r3.findings.some(f => /jku/.test(f.title)));
  // garbage rejected
  await assert.rejects(() => T.inspectJwt("not a token"), /JWT/);
  console.log("toolkit tests passed");
})().catch(e => { console.error(e); process.exit(1); });
