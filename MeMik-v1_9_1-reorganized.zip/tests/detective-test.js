/* Unit tests for the Detective engine and scanner helpers. Run: node tests/detective-test.js */
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const D = require("../src/features/detective/background/engine.js");

let passed = 0;
const t = (name, fn) => { try { fn(); passed++; } catch (e) { console.error("FAIL:", name, "\n  ", e.message); process.exitCode = 1; } };

/* ---------- scoring ---------- */
t("clean report scores 100 / A", () => {
  const s = D.scoreFindings([D.mk("csp", "x", "pass", "confirmed", "ok")]);
  assert.strictEqual(s.score, 100); assert.strictEqual(s.grade, "A");
});
t("severity and confidence weight the score", () => {
  const high = D.scoreFindings([D.mk("headers", "a", "high", "confirmed", "t")]).score;
  const highReview = D.scoreFindings([D.mk("headers", "a", "high", "review", "t")]).score;
  assert.strictEqual(high, 88); assert.ok(highReview > high);
});
t("one category cannot drain more than 40 points", () => {
  const many = Array.from({ length: 20 }, (_, i) => D.mk("xss", "x" + i, "high", "confirmed", "t"));
  assert.strictEqual(D.scoreFindings(many).score, 60);
});
t("info findings never cost points", () => {
  assert.strictEqual(D.scoreFindings([D.mk("tech", "i", "info", "confirmed", "t")]).score, 100);
});
t("verdict wording follows severity", () => {
  assert.match(D.verdictFor({ critical: 1, high: 0, medium: 0, low: 0 }, "all"), /Needs attention now/);
  assert.match(D.verdictFor({ critical: 0, high: 0, medium: 2, low: 0 }, "all"), /Mostly good/);
  assert.match(D.verdictFor({ critical: 0, high: 0, medium: 0, low: 0 }, "all"), /Excellent/);
});

/* ---------- CSP ---------- */
const ids = l => l.map(f => f.id);
t("missing CSP is reported", () => assert.ok(ids(D.analyzeCsp("", "", "")).includes("csp-missing")));
t("report-only CSP is not treated as protection", () => assert.ok(ids(D.analyzeCsp("", "default-src 'self'", "")).includes("csp-report-only")));
t("unsafe-inline flagged, but not when a nonce is present", () => {
  assert.ok(ids(D.analyzeCsp("script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'", "", "")).includes("csp-unsafe-inline"));
  assert.ok(!ids(D.analyzeCsp("script-src 'nonce-abc' 'unsafe-inline'; object-src 'none'; base-uri 'self'", "", "")).includes("csp-unsafe-inline"));
});
t("wildcard script-src flagged; strict-dynamic exempts https:", () => {
  assert.ok(ids(D.analyzeCsp("script-src *; object-src 'none'; base-uri 'self'", "", "")).includes("csp-wildcard"));
  assert.ok(!ids(D.analyzeCsp("script-src 'nonce-a' 'strict-dynamic' https:; object-src 'none'; base-uri 'none'", "", "")).includes("csp-wildcard"));
});
t("strong CSP passes", () => assert.deepStrictEqual(ids(D.analyzeCsp("default-src 'self'; object-src 'none'; base-uri 'self'", "", "")), ["csp-pass"]));
t("default-src alone covers script-src", () => assert.ok(!ids(D.analyzeCsp("default-src 'self'; object-src 'none'; base-uri 'self'", "", "")).includes("csp-no-script-policy")));

/* ---------- cookies ---------- */
t("session cookie without Secure/HttpOnly flagged on https", () => {
  const r = ids(D.analyzeCookies(["sessionid=abc; Path=/"], true, []));
  assert.ok(r.includes("cookie-secure-session") && r.includes("cookie-httponly") && r.includes("cookie-samesite"));
});
t("well-formed cookie passes", () => assert.deepStrictEqual(ids(D.analyzeCookies(["sid=abc; Secure; HttpOnly; SameSite=Lax; Path=/"], true, [])), ["cookie-pass"]));
t("Secure is not demanded on http pages", () => assert.ok(!ids(D.analyzeCookies(["sid=a; HttpOnly; SameSite=Lax"], false, [])).includes("cookie-secure-session")));
t("CSRF cookies may be readable by JS", () => assert.ok(!ids(D.analyzeCookies(["csrftoken=a; Secure; SameSite=Lax"], true, [])).includes("cookie-httponly")));
t("SameSite=None needs Secure", () => assert.ok(ids(D.analyzeCookies(["x=1; SameSite=None"], true, [])).includes("cookie-none-secure")));
t("__Host- prefix rules enforced", () => assert.ok(ids(D.analyzeCookies(["__Host-a=1; Secure; Path=/x"], true, [])).includes("cookie-prefix")));
t("JS-readable session cookie names are flagged, values never needed", () => assert.ok(ids(D.analyzeCookies([], true, ["PHPSESSID"])).includes("cookie-js-readable")));

/* ---------- headers ---------- */
t("headers: bare response gets the expected findings", () => {
  const r = ids(D.analyzeHeaders({}, true, {}));
  for (const id of ["hsts-missing", "clickjack-missing", "nosniff-missing", "referrer-missing"]) assert.ok(r.includes(id), id);
});
t("headers: hardened response passes", () => {
  const r = D.analyzeHeaders({ "strict-transport-security": "max-age=63072000; includeSubDomains", "x-frame-options": "DENY", "x-content-type-options": "nosniff", "referrer-policy": "no-referrer", "permissions-policy": "camera=()", "cross-origin-opener-policy": "same-origin" }, true, {});
  assert.ok(r.every(f => f.level === "pass"), JSON.stringify(r.filter(f => f.level !== "pass")));
});
t("headers: CSP frame-ancestors satisfies clickjacking", () => assert.ok(ids(D.analyzeHeaders({ "content-security-policy": "frame-ancestors 'self'" }, true, {})).includes("clickjack-pass")));
t("headers: HSTS skipped for http pages", () => assert.ok(!ids(D.analyzeHeaders({}, false, {})).some(i => i.startsWith("hsts"))));
t("headers: short HSTS flagged", () => assert.ok(ids(D.analyzeHeaders({ "strict-transport-security": "max-age=300" }, true, {})).includes("hsts-short")));
t("headers: version leaks and CORS misconfig", () => {
  const r = ids(D.analyzeHeaders({ server: "Apache/2.4.49", "x-powered-by": "PHP/7.4", "access-control-allow-origin": "*", "access-control-allow-credentials": "true" }, true, {}));
  assert.ok(r.includes("leak-versions") && r.includes("cors-wild-creds"));
});
t("headers: plain 'nginx' server name is not a leak", () => assert.ok(!ids(D.analyzeHeaders({ server: "nginx" }, true, {})).includes("leak-versions")));
t("headers: normHeaders keeps Set-Cookie separate", () => {
  const n = D.normHeaders([{ name: "Set-Cookie", value: "a=1" }, { name: "set-cookie", value: "b=2" }, { name: "Server", value: "x" }]);
  assert.strictEqual(n.setCookies.length, 2); assert.strictEqual(n.map.server, "x");
});

/* ---------- report assembly ---------- */
const dom = { url: "https://example.com/", findings: [D.mk("xss", "xss-sinks", "low", "review", "s"), D.mk("mixed", "mixed-pass", "pass", "confirmed", "m")], facts: { cookieNames: [] }, tech: [], errors: [] };
t("report: mode filters categories", () => {
  const r = D.buildReport({ mode: "mixed", dom, net: { headers: {}, setCookies: [], cookiesKnown: true, source: "browser" } });
  assert.ok(r.findings.every(f => f.cat === "mixed"));
  assert.strictEqual(r.notes.length, 0);
});
t("report: 'all' includes every category and a score", () => {
  const r = D.buildReport({ mode: "all", dom, net: { headers: {}, setCookies: [], cookiesKnown: true, source: "browser" } });
  assert.ok(r.findings.some(f => f.cat === "headers") && r.findings.some(f => f.cat === "xss"));
  assert.ok(r.score < 100 && /^[A-F]$/.test(r.grade) && r.top.length);
});
t("report: missing headers degrade gracefully", () => {
  const r = D.buildReport({ mode: "all", dom, net: null });
  assert.ok(r.ok && r.notes.some(n => /headers could not be read/i.test(n)));
  assert.ok(!r.findings.some(f => f.id === "csp-missing"));
});
t("report: non-network modes add no header warnings", () => {
  const r = D.buildReport({ mode: "xss", dom, net: null, netRequested: false });
  assert.strictEqual(r.notes.length, 0);
});
t("report: head-sourced headers explain themselves", () => {
  const r = D.buildReport({ mode: "headers", dom, net: { headers: {}, setCookies: [], cookiesKnown: false, source: "head" } });
  assert.ok(r.notes.some(n => /separate request/i.test(n)));
});

/* ---------- targets, ports ---------- */
t("cleanTarget accepts hosts and URLs, rejects junk", () => {
  assert.strictEqual(D.cleanTarget("https://Example.com:8443/a?b"), "example.com");
  assert.strictEqual(D.cleanTarget("1.2.3.4"), "1.2.3.4");
  assert.strictEqual(D.cleanTarget("localhost"), "localhost");
  for (const bad of ["", "a b", "user@host.com", "exa mple.com", "-bad-.com", "999.1.1.1", "x".repeat(300)]) assert.strictEqual(D.cleanTarget(bad), "", bad);
});
t("isPrivateIp", () => {
  for (const ip of ["10.0.0.1", "192.168.1.5", "172.16.0.1", "127.0.0.1", "169.254.1.1", "::1", "fd00::1"]) assert.ok(D.isPrivateIp(ip), ip);
  for (const ip of ["8.8.8.8", "172.32.0.1", "1.1.1.1"]) assert.ok(!D.isPrivateIp(ip), ip);
});
t("parsePortList handles ranges, junk and limits", () => {
  assert.deepStrictEqual(D.parsePortList("80, 443 8080-8082 abc 70000 0"), [80, 443, 8080, 8081, 8082]);
  assert.strictEqual(D.parsePortList("1-65535").length, 0);       // range too wide
  assert.strictEqual(D.parsePortList("1000-1050,2000-2050", 60).length, 60);
});
t("classifyProbe: browser-blocked ports are never called closed", () => assert.strictEqual(D.classifyProbe(22, { ok: false, ms: 5 }, { closedMs: 50 }).status, "blocked"));
t("classifyProbe: HTTP answer = open", () => assert.strictEqual(D.classifyProbe(8080, { ok: true, ms: 40 }, { closedMs: 50 }).status, "open"));
t("classifyProbe: timing separates closed from possibly-open", () => {
  assert.strictEqual(D.classifyProbe(3306, { ok: false, ms: 55 }, { closedMs: 50 }).status, "closed");
  assert.strictEqual(D.classifyProbe(3306, { ok: false, ms: 130 }, { closedMs: 50 }).status, "possibly-open");
});
t("classifyProbe: timeouts are filtered; fast LANs give low confidence", () => {
  assert.strictEqual(D.classifyProbe(3306, { ok: false, ms: 3000, timedOut: true }, { allTimedOut: true }).status, "filtered");
  assert.strictEqual(D.classifyProbe(3306, { ok: false, ms: 3 }, { closedMs: 2 }).status, "no-web-service");
});
t("portFinding rates databases critical and web ports info", () => {
  assert.strictEqual(D.portFinding(3306, "open", false).level, "critical");
  assert.strictEqual(D.portFinding(443, "open", false).level, "info");
  assert.strictEqual(D.portFinding(3306, "closed", false).level, "pass");
  assert.strictEqual(D.portFinding(3306, "closed", true).level, "critical");   // public scan saw it open
});
t("summarizePortScan wording", () => {
  const ok = D.summarizePortScan([{ port: 443, status: "open", level: "info" }, { port: 22, status: "closed", level: "pass" }]);
  assert.strictEqual(ok.tone, "ok");
  const bad = D.summarizePortScan([{ port: 6379, status: "open", level: "critical" }]);
  assert.strictEqual(bad.tone, "bad"); assert.deepStrictEqual(bad.risky, [6379]);
});

/* ---------- scanner helpers (loaded in a sandbox) ---------- */
const sandbox = { __MEMIK_TEST__: {}, chrome: { runtime: { onMessage: { addListener() {} } } }, URL, URLSearchParams, console };
sandbox.window = sandbox; sandbox.globalThis = sandbox; sandbox.location = new URL("https://example.com/");
sandbox.document = {}; sandbox.performance = { getEntriesByType: () => [] }; sandbox.NodeFilter = { SHOW_COMMENT: 128 };
vm.runInNewContext(fs.readFileSync(path.join(__dirname, "../src/features/detective/content/page-scanner.js"), "utf8"), sandbox);
const S = sandbox.__MEMIK_TEST__.scanner;

t("scanner: etld1", () => {
  assert.strictEqual(S.etld1("cdn.example.com"), "example.com");
  assert.strictEqual(S.etld1("www.example.co.uk"), "example.co.uk");
  assert.strictEqual(S.etld1("1.2.3.4"), "1.2.3.4");
});
t("scanner: known-vulnerable library ranges", () => {
  assert.strictEqual(S.libIssues("https://code.jquery.com/jquery-3.4.1.min.js")[0].name, "jQuery");
  assert.strictEqual(S.libIssues("https://code.jquery.com/jquery-3.7.1.min.js").length, 0);
  assert.strictEqual(S.libIssues("https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.js").length, 1);
  assert.strictEqual(S.libIssues("https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.js").length, 0);
  assert.strictEqual(S.libIssues("https://cdn.jsdelivr.net/npm/lodash@4.17.21/lodash.min.js").length, 0);
  assert.strictEqual(S.libIssues("https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js")[0].name, "AngularJS");
});
t("scanner: DB errors need real error signatures (no false alarm on prose)", () => {
  assert.ok(S.findDbError("You have an error in your SQL syntax; check the manual"));
  assert.ok(S.findDbError("ORA-00933: SQL command not properly ended"));
  assert.strictEqual(S.findDbError("Learn SQL syntax and how to write a SELECT statement"), "");
});
t("scanner: debug pages", () => {
  assert.ok(S.findDebugPage("Traceback (most recent call last):\n  File"));
  assert.ok(S.findDebugPage("Whitelabel Error Page"));
  assert.strictEqual(S.findDebugPage("Welcome to our blog"), "");
});
t("scanner: secrets are masked, never echoed", () => {
  const r = S.findSecrets("var k='AKIAABCDEFGHIJKLMNOP';");
  assert.strictEqual(r[0].name, "AWS access key ID"); assert.ok(!r[0].preview.includes("ABCDEFGHIJKLMNOP"));
  assert.strictEqual(S.findSecrets("nothing here").length, 0);
});
t("scanner: DOM-XSS source+sink detection", () => {
  assert.ok(S.scanScriptText("el.innerHTML = location.hash.slice(1)").flow);
  assert.ok(!S.scanScriptText("el.textContent = location.hash").flow);
  assert.ok(S.scanScriptText("document.write(x)").sink && !S.scanScriptText("document.write(x)").source);
});
t("scanner: redirect params", () => {
  assert.strictEqual(S.paramRedirects("?next=https://evil.com&page=2")[0].key, "next");
  assert.strictEqual(S.paramRedirects("?next=/home").length, 0);
  assert.ok(S.paramRedirects("?foo=//evil.com")[0].named === false);
});

console.log(`${passed} detective tests passed` + (process.exitCode ? " (with failures)" : ""));
