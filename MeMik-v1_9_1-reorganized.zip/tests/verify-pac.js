const { buildPacScript } = require('../src/features/proxy/proxy-scope.js');
const vm = require('vm');
const assert = require('assert');

// Mock proxy object
const proxyObj = { scheme: 'socks5', host: '5.6.7.8', port: 1080 };
const httpProxy = { scheme: 'http', host: '1.2.3.4', port: 8080 };

// Test 1: Global proxy
const pac1 = buildPacScript(null, httpProxy, true, ['direct.com']);
assert(pac1.includes('PROXY 1.2.3.4:8080'));
console.log('Test 1 Passed: Global PAC script generated');

// Test 2: Scoped array of hostnames
const pac2 = buildPacScript(['example.com', 'test.org'], proxyObj, false, ['direct.com']);
assert(pac2.includes('example.com') && pac2.includes('test.org'));

// Evaluate in VM
const ctx = {};
vm.createContext(ctx);
ctx.shExpMatch = (url, pattern) => pattern === '*' || url.includes(pattern.replace(/\*/g, ''));
ctx.dnsDomainIs = (host, domain) => host === domain || host.endsWith('.' + domain);
ctx.isInNet = () => false;
ctx.isPlainHostName = (host) => !host.includes('.');

vm.runInContext(pac2, ctx);
const routeMatch = ctx.FindProxyForURL('http://example.com/page', 'example.com');
assert(routeMatch.includes('SOCKS5 5.6.7.8:1080'), `Expected SOCKS5 proxy, got: ${routeMatch}`);

const routeSubmatch = ctx.FindProxyForURL('http://sub.example.com/page', 'sub.example.com');
assert(routeSubmatch.includes('SOCKS5 5.6.7.8:1080'), `Expected SOCKS5 proxy for subdomain, got: ${routeSubmatch}`);

const routeDirect = ctx.FindProxyForURL('http://google.com/search', 'google.com');
assert.strictEqual(routeDirect, 'DIRECT', `Expected DIRECT for unassigned host, got: ${routeDirect}`);

const routeExempt = ctx.FindProxyForURL('http://direct.com/api', 'direct.com');
assert.strictEqual(routeExempt, 'DIRECT', `Expected DIRECT for directHosts, got: ${routeExempt}`);

console.log('Test 2 Passed: Scoped PAC routing evaluation');

// Test 3: Empty host array
const pac3 = buildPacScript([], httpProxy, false, []);
vm.runInContext(pac3, ctx);
const routeEmpty = ctx.FindProxyForURL('http://example.com', 'example.com');
assert.strictEqual(routeEmpty, 'DIRECT');
console.log('Test 3 Passed: Empty scope defaults to DIRECT');

// Test 4: Single string hostname
const pac4 = buildPacScript('mysite.org', httpProxy, false, []);
vm.runInContext(pac4, ctx);
assert(ctx.FindProxyForURL('http://mysite.org/a', 'mysite.org').includes('PROXY 1.2.3.4:8080'));
assert.strictEqual(ctx.FindProxyForURL('http://other.org/a', 'other.org'), 'DIRECT');
console.log('Test 4 Passed: Single string hostname PAC');

console.log('ALL PAC TESTS PASSED SUCCESSFULLY!');
