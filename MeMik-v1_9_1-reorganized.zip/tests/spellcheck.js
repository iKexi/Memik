const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');

function extractStrings(file) {
  const content = fs.readFileSync(path.join(root, file), 'utf8');
  // extract string literals
  const matches = content.match(/"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|`([^`\\]*(?:\\.[^`\\]*)*)`/g) || [];
  return matches.map(s => s.slice(1, -1)).filter(s => s.length > 5 && s.includes(' '));
}

const jsStrings = [
  ...extractStrings('src/ui/popup.js'),
  ...extractStrings('src/core/background/service-worker.js')
];
const set = Array.from(new Set(jsStrings));
set.sort();
console.log('Total extracted string phrases:', set.length);
// Check for specific grammar / spelling quirks
for (const s of set) {
  if (/mathc|chaning|gramat|occured|untill|seperate|definate|recieve|wierd|succesful/i.test(s)) {
    console.log('SUSPECT:', s);
  }
}
